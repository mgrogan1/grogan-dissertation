%% This script loads the survival functions and their derivatives needed 
%% for the two strain time since infection model with an SITRS framework. 
%% We will first have to choose the type of survival function we want for 
%% each given scenario, then fit parameters to those survival functions 
%% (all parameterts are loaded in separate file)
%% The order in which we compute each integral equation:
%% Is, Ir, Ts, Tr, Rs, Rr, Sh, Ms, Mr, Sv

% format long

%% Survival Functions:
% inputs: Survival_Func(distribution, mean, shape, time_point)
% distributions: 'exponential', 'gamma', 'gamma_fractional', 'weibull', 
% 'gompertz', 'log-logistic'

% surviving in Is by not recovering
P_Is = @(x) Survival_Func(PIs_distr,PIs_mean,PIs_shape,x);

% surviving in Is by not receiving treatment
P_IsTs = @(x) Survival_Func(PIsTs_distr,PIsTs_mean,PIsTs_shape,x); 

% surviving in Ir by not recovering
P_Ir = @(x) Survival_Func(PIr_distr,PIr_mean,PIr_shape,x); 

% surviving in Ir by not receiving treatment
P_IrTr = @(x) Survival_Func(PIrTr_distr,PIrTr_mean,PIrTr_shape,x); 

% surviving in Ts by not recovering
P_Ts = @(x) Survival_Func(PTs_distr,PTs_mean,PTs_shape,x); 

% surviving in Tr by not recovering
P_Tr = @(x) Survival_Func(PTr_distr,PTr_mean,PTr_shape,x); 

% surviving in Rs by not losing immunity
P_Rs = @(x) Survival_Func(PRs_distr,PRs_mean,PRs_shape,x);

% surviving in Rr by not losing immunity
P_Rr = @(x) Survival_Func(PRr_distr,PRr_mean,PRr_shape,x);

% surviving by not dying naturally - humans
P_ND = @(x) Survival_Func(PND_distr,PND_mean,PND_shape,x);

% surviving by not dying from s-disease
P_DDs = @(x) Survival_Func(PDDs_distr,PDDs_mean,PDDs_shape,x); 

% surviving by not dying from r-disease
P_DDr = @(x) Survival_Func(PDDr_distr,PDDr_mean,PDDr_shape,x); 

% surviving by not dying naturally - vectors
P_V = @(x) Survival_Func(PV_distr,PV_mean,PV_shape,x); 

%% Calculate derivatives of survival functions with symbol x
% inputs: Survival_Func_Deriv(distribution, mean, shape, time_point)
% distributions: 'exponential', 'gamma', 'gamma_fractional', 'weibull', 
% 'gompertz', 'log-logistic'

% multiply by negative to get leaving Is by recovering
dP_Is = @(x) Survival_Func_Deriv(PIs_distr,PIs_mean,PIs_shape,x);

% multiply by negative to get leaving Is by receiving treatment
dP_IsTs = @(x) Survival_Func_Deriv(PIsTs_distr,PIsTs_mean,PIsTs_shape,x);

% multiply by negative to get leaving Ir by recovering
dP_Ir = @(x) Survival_Func_Deriv(PIr_distr,PIr_mean,PIr_shape,x);

% multiply by negative to get leaving Ir by receiving treatment
dP_IrTr = @(x) Survival_Func_Deriv(PIrTr_distr,PIrTr_mean,PIrTr_shape,x);

% multiply by negative to get leaving Ts by recovering
dP_Ts = @(x) Survival_Func_Deriv(PTs_distr,PTs_mean,PTs_shape,x);

% multiply by negative to get leaving Tr by recovering
dP_Tr = @(x) Survival_Func_Deriv(PTr_distr,PTr_mean,PTr_shape,x);

% multiply by negative to get leaving Rs by waining immunity
dP_Rs = @(x) Survival_Func_Deriv(PRs_distr,PRs_mean,PRs_shape,x);

% multiply by negative to get leaving Rr by waining immunity
dP_Rr = @(x) Survival_Func_Deriv(PRr_distr,PRr_mean,PRr_shape,x);

% % multiply by negative to get dying naturally - humans
dP_ND = @(x) Survival_Func_Deriv(PND_distr,PND_mean,PND_shape,x);

% % multiply by negative to get dying from s-disease
dP_DDs = @(x) Survival_Func_Deriv(PDDs_distr,PDDs_mean,PDDs_shape,x);

% % multiply by negative to get dying from r-disease
dP_DDr = @(x) Survival_Func_Deriv(PDDr_distr,PDDr_mean,PDDr_shape,x);

% surviving by not dying naturally - vectors
dP_V = @(x) Survival_Func_Deriv(PV_distr,PV_mean,PV_shape,x); 

%% Evaluate Survival Functions and derivatives at all needed timepoints
% output vector = arrayfun(function, input vector)

Eval_PIs = arrayfun(P_Is, tspan);
Eval_PIsTs = arrayfun(P_IsTs, tspan);
Eval_PIr = arrayfun(P_Ir, tspan);
Eval_PIrTr = arrayfun(P_IrTr, tspan);
Eval_PTs = arrayfun(P_Ts, tspan);
Eval_PTr = arrayfun(P_Tr, tspan);
Eval_PRs = arrayfun(P_Rs, tspan);
Eval_PRr = arrayfun(P_Rr, tspan);
Eval_PND = arrayfun(P_ND, tspan);
Eval_PDDs = arrayfun(P_DDs, tspan);
Eval_PDDr = arrayfun(P_DDr, tspan);
Eval_PV = arrayfun(P_V, tspan);

%build negative coefficient into derivative of survival function

neg_Eval_dPIs = -arrayfun(dP_Is, tspan);
neg_Eval_dPIsTs = -arrayfun(dP_IsTs, tspan);
neg_Eval_dPIr = -arrayfun(dP_Ir, tspan);
neg_Eval_dPIrTr = -arrayfun(dP_IrTr, tspan);
neg_Eval_dPTs = -arrayfun(dP_Ts, tspan);
neg_Eval_dPTr = -arrayfun(dP_Tr, tspan);
neg_Eval_dPRs = -arrayfun(dP_Rs, tspan);
neg_Eval_dPRr = -arrayfun(dP_Rr, tspan);
neg_Eval_dPV = -arrayfun(dP_V, tspan);

%% Multiply related survival functions

% Sh block, for all models
PND = Eval_PND;

% Is block, for SIsTsRs, SIsTsRsS models
PIs_PIsTs_PND_PDDs = Eval_PIs.*Eval_PIsTs.*Eval_PND.*Eval_PDDs; 
dPIs_PIsTs_PND_PDDs = neg_Eval_dPIs.*Eval_PIsTs.*Eval_PND.*Eval_PDDs; 
PIs_dPIsTs_PND_PDDs = Eval_PIs.*neg_Eval_dPIsTs.*Eval_PND.*Eval_PDDs; 

% Ir block, for SIsTsRs, SIsTsRsS models
PIr_PIrTr_PND_PDDr = Eval_PIr.*Eval_PIrTr.*Eval_PND.*Eval_PDDr; 
dPIr_PIrTr_PND_PDDr = neg_Eval_dPIr.*Eval_PIrTr.*Eval_PND.*Eval_PDDr; 
PIr_dPIrTr_PND_PDDr = Eval_PIr.*neg_Eval_dPIrTr.*Eval_PND.*Eval_PDDr; 

% Ts block, for SIsTsR, SIsTsRS models
PTs_PND_PDDs = Eval_PTs.*Eval_PND.*Eval_PDDs; 
dPTs_PND_PDDs = neg_Eval_dPTs.*Eval_PND.*Eval_PDDs; 

% Tr block, for SIsTsTrR, SIsTsTrRS models
PTr_PND_PDDr = Eval_PTr.*Eval_PND.*Eval_PDDr; 
dPTr_PND_PDDr = neg_Eval_dPTr.*Eval_PND.*Eval_PDDr; 

% Rs block, for SIsRS, SIsTRS models 
PRs_PND = Eval_PRs.*Eval_PND;
dPRs_PND = neg_Eval_dPRs.*Eval_PND;

% Rr block, for SIsIrRsRrS, SIsIrTsTrRsRrS models 
PRr_PND = Eval_PRr.*Eval_PND;
dPRr_PND = neg_Eval_dPRr.*Eval_PND;

% Sv, Ms, Mr blocks, for all models
PV = Eval_PV;

%% Multiply by relevant initial populations 

% Sh block initials, for all models
Sh0_PND = Sh0*PND;

% Is block initials, for SIsTsR, SIsTsRS models
Is0_PIs_PIsTs_PND_PDDs = Is0*PIs_PIsTs_PND_PDDs;
Is0_dPIs_PIsTs_PND_PDDs = Is0*dPIs_PIsTs_PND_PDDs;
Is0_PIs_dPIsTs_PND_PDDs = Is0*PIs_dPIsTs_PND_PDDs;

% Ir block initials, for SIsTsR, SIsTsRS models
Ir0_PIr_PIrTr_PND_PDDr = Ir0*PIr_PIrTr_PND_PDDr;
Ir0_dPIr_PIrTr_PND_PDDr = Ir0*dPIr_PIrTr_PND_PDDr;
Ir0_PIr_dPIrTr_PND_PDDr = Ir0*PIr_dPIrTr_PND_PDDr;

% Ts block initials, for SIsTsR, SIsTsRS models
Ts0_PTs_PND_PDDs = Ts0*PTs_PND_PDDs;
Ts0_dPTs_PND_PDDs = Ts0*dPTs_PND_PDDs;

% Tr block initials, for SIsTsR, SIsTsRS models
Tr0_PTr_PND_PDDr = Tr0*PTr_PND_PDDr;
Tr0_dPTr_PND_PDDr = Tr0*dPTr_PND_PDDr;

% Rs block initials, for SIsRS, SIsTRS models 
Rs0_PRs_PND = Rs0*PRs_PND;
Rs0_dPRs_PND = Rs0*dPRs_PND;

% Rr block initials, for SIsRS, SIsTRS models 
Rr0_PRr_PND = Rr0*PRr_PND;
Rr0_dPRr_PND = Rr0*dPRr_PND;

% Sv block initials, for all models
Sv0_PV = Sv0*PV;

% Ms block initials, for all models
Ms0_PV = Ms0*PV;

% Mr block initials, for all models
Mr0_PV = Mr0*PV;
