function p = Survival_Func(distribution, mean, shape, t)

if strcmp(distribution,'exponential')
    
    p = exp(-mean*t);
    
elseif strcmp(distribution,'gamma')
    
    sum_terms= zeros(1,shape);
    
    for i = 1:shape
        sum_terms(i) = ((shape*mean*t)^(i-1))/factorial(i-1);
    end
    
    p = exp(-shape*mean*t)*sum(sum_terms);
    
elseif strcmp(distribution,'gamma_fractional')
    
    %returns the cdf of the gamma distribution with the shape parameters in a and scale parameters in b, evaluated at the values in x.
    
    scale = 1/(mean*shape);
    % p = gamcdf(t,shape,scale,'upper'); 
    p = 1 - gamcdf(t,shape,scale); 
    
elseif strcmp(distribution,'weibull')
    %
    %   This is keeping with the above scheme- mean is really 1/mean
    
    p =exp(-(t*mean)^shape);
    
elseif strcmp(distribution,'gompertz')
    %
    %   We are replacing scale with mean
    %   % shape is theta/alpha, mean is alpha
    
    p = exp(-shape*(exp(mean*t)-1));
    
elseif strcmp(distribution,'log-logistic')
    %
    % we will pass in standdard deviation in as shape
    
    stdd = shape;
    p = (1/4)*stdd^2*((sech(stdd*(t-mean)/2)).^2)*(tanh(stdd*(t-mean)/2));
    
end


end
