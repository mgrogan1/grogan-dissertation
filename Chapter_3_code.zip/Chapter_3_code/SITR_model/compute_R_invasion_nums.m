%% This script loads data computes the reproduction numbers 
%% and the invastions numbers for both the sensitive and resistant
%% strains. 


%% calculate mean residence times 
% (only need infectious classes Is, Ts, Ms, Ir, Tr, Mr)

% Is
Q_Is = PIs_PIsTs_PND_PDDs;
D_Is = trapz(tspan, Q_Is);

% Ts
Q_Ts = PTs_PND_PDDs;
D_Ts = trapz(tspan, Q_Ts);

% Ir
Q_Ir = PIr_PIrTr_PND_PDDr;
D_Ir = trapz(tspan, Q_Ir);

% Tr
Q_Tr = PTr_PND_PDDr;
D_Tr = trapz(tspan, Q_Tr);

% Ms
Q_Ms = PV;
D_Ms = trapz(tspan, Q_Ms);

% Mr
Q_Mr = PV;
D_Mr = trapz(tspan, Q_Mr);


%% calculate probabilities
% (only need infectious to infectious classes Is -> Ts, Ir-> Tr)

% IsTs
dQ_IsTs = PIs_dPIsTs_PND_PDDs;
T_IsTs = trapz(tspan, dQ_IsTs);

% IrTr
dQ_IrTr = PIr_dPIrTr_PND_PDDr;
T_IrTr = trapz(tspan, dQ_IrTr);


%% calculate reproduction numbers 

% R_s^2 (sensitive strain reproduction num, squared)
Rs2 = betaV*(D_Is + psiS*T_IsTs*D_Ts)...
    *betaH*(LambdaV0*muH)/(LambdaH0*muV)*D_Ms;

% R_r^2 (resistant strain reproduction num, squared)
Rr2 = kappaV*betaV*(D_Ir + psiR*T_IrTr*D_Tr)...
    *kappaH*betaH*(LambdaV0*muH)/(LambdaH0*muV)*D_Mr;


%% calculate invasion numbers 

% R_s^r (sensitive invading resistant strain num, squared)
Rsr2 = betaV*(Svt(end)/Nvt(end))*(D_Is + psiS*T_IsTs*D_Ts)...
    *betaH*(Sht(end)/Nht(end))*(Nvt(end)/Nht(end))*D_Ms;

% R_r^s (resistant invading sensitive strain num, squared)
Rrs2 = kappaV*betaV*(Svt(end)/Nvt(end))*(D_Ir + psiR*T_IrTr*D_Tr)...
    *kappaH*betaH*((Sht(end) + Ist(end) + Tst(end) + Rst(end))/Nht(end))...
    *(Nvt(end)/Nht(end))*D_Mr;

