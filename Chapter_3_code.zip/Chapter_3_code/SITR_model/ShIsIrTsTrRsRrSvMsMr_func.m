function ShIsIrTsTrRsRrSvMsMr_func_val = ShIsIrTsTrRsRrSvMsMr_func(t,ShIsIrTsTrRsRrSvMsMrt,par)
%ShIsIrTsTrRsRrSvMsMrt = column vector = [Sh Is Ir Ts Tr Rs Rr Sv Ms Mr]'

% pull parameters
a = par.a;
alphaS = par.alphaS;
alphaR = par.alphaR;
betaH = par.betaH;
betaV = par.betaV;
kappaH = par.kappaH;
kappaV = par.kappaV;
psiS = par.psiS;
psiR = par.psiR;
%phi = par.phi;
deltaS = par.deltaS;
deltaR = par.deltaR;
gammaS = par.gammaS;
gammaR = par.gammaR;
muH = par.muH;
muV = par.muV;
omegaS = par.omegaS;
omegaR = par.omegaR;
LambdaH = par.LambdaH0;
LambdaV = par.LambdaV0;

% pull variables
Sh = ShIsIrTsTrRsRrSvMsMrt(1);
Is = ShIsIrTsTrRsRrSvMsMrt(2);
Ir = ShIsIrTsTrRsRrSvMsMrt(3);
Ts = ShIsIrTsTrRsRrSvMsMrt(4);
Tr = ShIsIrTsTrRsRrSvMsMrt(5);
Rs = ShIsIrTsTrRsRrSvMsMrt(6);
Rr = ShIsIrTsTrRsRrSvMsMrt(7);
Nh = Sh + Is + Ir + Ts + Tr + Rs + Rr;
Sv = ShIsIrTsTrRsRrSvMsMrt(8);
Ms = ShIsIrTsTrRsRrSvMsMrt(9);
Mr = ShIsIrTsTrRsRrSvMsMrt(10);
Nv = Sv + Ms + Mr;

%transmission functions
lambdaS = betaH*Ms/Nh; %s-human
lambdaR = kappaH*betaH*Mr/Nh; %r-human
upsilonS = betaV*(Is+psiS*Ts)/Nh; %s-vector
upsilonR = kappaV*betaV*(Ir+psiR*Tr)/Nh; %r-vector

%birth functions (if desired)
%LambdaH = muH*Nh + deltaS*(Is+Ts) + deltaR*(Ir+Tr);
%LambdaV = muV*Nv;

%dSh = birth - s-infection to Is - r-infection to Ir - natural death +
%susceptibility from Rs and Rr
dSh = LambdaH - (lambdaS + lambdaR)*Sh - muH*Sh + omegaS*Rs + omegaR*Rr;

%dIs = s-infection from S - r-infection to Ir - recovery to Rs -
%treatment to Ts -natural death - disease death
dIs = lambdaS*Sh - lambdaR*Is - (gammaS + a + muH + deltaS)*Is;

%dIr = r-infection from S + r-infection from Is,Ts,Rs - recovery to Rr -
%treatment to Tr -natural death - disease death
dIr = lambdaR*(Sh + Is + Ts + Rs) - (gammaR + a + muH + deltaR)*Ir;

%dTs = treatment from Is - r-infection to Ir - recovery to Rs - natural
%death - disease death
dTs = a*Is - lambdaR*Ts - (alphaS + muH + deltaS)*Ts;

%dTr = treatment from Ir - recovery to Rr - natural
%death - disease death
dTr = a*Ir - (alphaR + muH + deltaR)*Tr;

%dRs = recovery from Is + recovery from Ts - r-infection to Ir -
%susceptibility to S - natural death
dRs = gammaS*Is + alphaS*Ts - lambdaR*Rs - (omegaS + muH)*Rs;

%dRr = recovery from Ir + recovery from Tr -
%susceptibility to S - natural death
dRr = gammaR*Ir + alphaR*Tr - (omegaR + muH)*Rr;

%dSv = birth - s-infection to Ms - r-infection to Mr - natural death
%dSv = LambdaV - (upsilonS + upsilonR)*Sv - muV*Sv;
dSv = LambdaV - (upsilonS + upsilonR)*Sv - muV*Sv;

%dMs = s-infection from Sv - natural death
dMs = upsilonS*Sv - muV*Ms;

%dMr = r-infection from Sv - natural death 
dMr = upsilonR*Sv - muV*Mr;

%% ouput storage (column vector)
ShIsIrTsTrRsRrSvMsMr_func_val(:,1) = [dSh dIs dIr dTs dTr dRs dRr dSv dMs dMr]';
 
end
