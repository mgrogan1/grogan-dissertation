function integral_val = integral_func(index, integrand, uspan, du)

    %integrate 
    %trapz for timepoints up to t_j, left rectangle for t_j to t_j+1
    integral_val = trapz(uspan, integrand) + integrand(index)*du;

end
