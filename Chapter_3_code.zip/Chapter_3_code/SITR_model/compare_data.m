

% Ist1 = load('Data/2strain_dt_-1_tf_100_EE_IT3', 'Ist');
% 
% 
% Ist1_test = Ist1.Ist;
% 
% Ist2 = load('Data/2strain_dt_-1_tf_100_EE_IR3', 'Ist');
% 
% 
% Ist2_test = Ist2.Ist;
% 
% Ist_diff = Ist1_test - Ist2_test;


%% load data into structure (infectrous classes)

TR3 = load('Data/2strain_dt_-2_tf_10_SSE_TR3', 'Ist','Irt','Tst','Trt');
IT3 = load('Data/2strain_dt_-2_tf_10_SSE_IT3', 'Ist','Irt','Tst','Trt');
IR3 = load('Data/2strain_dt_-2_tf_10_SSE_IR3', 'Ist','Irt','Tst','Trt');
IR3_TR3 = load('Data/2strain_dt_-2_tf_10_SSE_IR3_TR3', 'Ist','Irt','Tst','Trt');
GAMMA3 = load('Data/2strain_dt_-2_tf_10_SSE_GAMMA3', 'Ist','Irt','Tst','Trt');
EXP = load('Data/2strain_dt_-2_tf_10_SSE_EXP', 'Ist','Irt','Tst','Trt');

%% call data from structure

% TR3
Ist_TR3 = TR3.Ist;
Irt_TR3 = TR3.Irt;
Tst_TR3 = TR3.Tst;
Trt_TR3 = TR3.Trt;

% IT3
Ist_IT3 = IT3.Ist;
Irt_IT3 = IT3.Irt;
Tst_IT3 = IT3.Tst;
Trt_IT3 = IT3.Trt;

% IR3
Ist_IR3 = IR3.Ist;
Irt_IR3 = IR3.Irt;
Tst_IR3 = IR3.Tst;
Trt_IR3 = IR3.Trt;

% IR3_TR3
Ist_IR3_TR3 = IR3_TR3.Ist;
Irt_IR3_TR3 = IR3_TR3.Irt;
Tst_IR3_TR3 = IR3_TR3.Tst;
Trt_IR3_TR3 = IR3_TR3.Trt;

% GAMMA3
Ist_GAMMA3 = GAMMA3.Ist;
Irt_GAMMA3 = GAMMA3.Irt;
Tst_GAMMA3 = GAMMA3.Tst;
Trt_GAMMA3 = GAMMA3.Trt;

% EXP
Ist_EXP = EXP.Ist;
Irt_EXP = EXP.Irt;
Tst_EXP = EXP.Tst;
Trt_EXP = EXP.Trt;

%% compare all equilibrium values with EXP
% TR3
Ist_TR3_diff = Ist_EXP - Ist_TR3;
Irt_TR3_diff = Irt_EXP - Irt_TR3;
Tst_TR3_diff = Tst_EXP - Tst_TR3;
Trt_TR3_diff = Trt_EXP - Trt_TR3;

% IT3
Ist_IT3_diff = Ist_EXP - Ist_IT3;
Irt_IT3_diff = Irt_EXP - Irt_IT3;
Tst_IT3_diff = Tst_EXP - Tst_IT3;
Trt_IT3_diff = Trt_EXP - Trt_IT3;

% IR3
Ist_IR3_diff = Ist_EXP - Ist_IR3;
Irt_IR3_diff = Irt_EXP - Irt_IR3;
Tst_IR3_diff = Tst_EXP - Tst_IR3;
Trt_IR3_diff = Trt_EXP - Trt_IR3;

% IR3_TR3
Ist_IR3_TR3_diff = Ist_EXP - Ist_IR3_TR3;
Irt_IR3_TR3_diff = Irt_EXP - Irt_IR3_TR3;
Tst_IR3_TR3_diff = Tst_EXP - Tst_IR3_TR3;
Trt_IR3_TR3_diff = Trt_EXP - Trt_IR3_TR3;

% GAMMA3
Ist_GAMMA3_diff = Ist_EXP - Ist_GAMMA3;
Irt_GAMMA3_diff = Irt_EXP - Irt_GAMMA3;
Tst_GAMMA3_diff = Tst_EXP - Tst_GAMMA3;
Trt_GAMMA3_diff = Trt_EXP - Trt_GAMMA3;

%% EXP - compare this one with ODE??
% Ist_EXP = EXP.Ist;
% Irt_EXP = EXP.Irt;
% Tst_EXP = EXP.Tst;
% Trt_EXP = EXP.Trt;

%% plot everything 

% TR3
figure(1)
hold on
plot(Ist_TR3_diff)
plot(Irt_TR3_diff)
plot(Tst_TR3_diff)
plot(Trt_TR3_diff)
legend('Ist','Irt','Tst','Trt')

% IT3
figure(2)
hold on
plot(Ist_IT3_diff)
plot(Irt_IT3_diff)
plot(Tst_IT3_diff)
plot(Trt_IT3_diff)
legend('Ist','Irt','Tst','Trt')

% IR3
figure(3)
hold on
plot(Ist_IR3_diff)
plot(Irt_IR3_diff)
plot(Tst_IR3_diff)
plot(Trt_IR3_diff)
legend('Ist','Irt','Tst','Trt')

% IR3_TR3
figure(4)
hold on
plot(Ist_IR3_TR3_diff)
plot(Irt_IR3_TR3_diff)
plot(Tst_IR3_TR3_diff)
plot(Trt_IR3_TR3_diff)
legend('Ist','Irt','Tst','Trt')

% GAMMA3
figure(5)
hold on
plot(Ist_GAMMA3_diff)
plot(Irt_GAMMA3_diff)
plot(Tst_GAMMA3_diff)
plot(Trt_GAMMA3_diff)
legend('Ist','Irt','Tst','Trt')




