%% This script loads data from simulations and computes the reproduction 
%% numbers and the invastions numbers for both the sensitive and resistant
%% strains. 

clear 
close all

%% load reproduction numbers from data

% data types
equilibria = {'DFE', 'SSE', 'SSE_R', 'RSE', 'RSE_S'};
distr = {'EXP', 'IT3', 'IR3', 'TR3', 'IR3_TR3', 'GAMMA3','WEIBULL3'};
distr_tex = {'EXP', 'IT3', 'IR3', 'TR3', 'IR3 + TR3', 'GAMMA3', 'WEIBULL3'};

%strcat('sensitive', num2str(i), num2str(j));

% initialize matrices that store rep. and inv. numbers
Rs2_all = zeros(length(equilibria), length(distr));
%Rs2_legend = {};

Rr2_all = zeros(length(equilibria), length(distr));
%Rr2_legend = {};

Rsr2_all = zeros(length(equilibria), length(distr));
%Rsr2_legend = {};

Rrs2_all = zeros(length(equilibria), length(distr));
%Rrs2_legend = {};

% store all reproduction numbers
for i = 1:length(equilibria) 
    for j = 1:length(distr)
        
        data_name_tmp = ['Data/test3_2strain_dt_-2_tf_10_', equilibria{i}, '_', distr{j}];
        data_tmp = load(data_name_tmp, 'Rs2', 'Rr2', 'Rsr2', 'Rrs2');
        
        Rs2_all(i,j) = data_tmp.Rs2;
        Rs2_legend(i,j) = {[equilibria{i}, '_', distr{j}]};

        Rr2_all(i,j) = data_tmp.Rr2;
        Rr2_legend(i,j) = {[equilibria{i}, '_', distr{j}]};
        
        Rsr2_all(i,j) = data_tmp.Rsr2;
        Rsr2_legend(i,j) = {[equilibria{i}, '_', distr{j}]};
        
        Rrs2_all(i,j) = data_tmp.Rrs2;
        Rrs2_legend(i,j) = {[equilibria{i}, '_', distr{j}]};
        
    end
end


%% plot

% create color scheme for barplots 

distribution_cols = colormap(parula(length(Rs2_all)));

% plot Rs2 data
figure(1)
b_Rs2 = bar(Rs2_all);%bar(Rs2_all);
% b_Rs2 = bar(Rs2_all(1,:));%bar(Rs2_all);
% b_Rs2.FaceColor = 'flat';
% b_Rs2.CData = repmat(distribution_cols, length(equilibria), 1);

for k = 1:length(Rs2_all)
    b_Rs2(k).FaceColor = 'flat';
    b_Rs2(k).CData = repmat(distribution_cols(k,:), length(equilibria), 1);
end
title('$R_s^2$', 'interpreter', 'latex','FontSize',20)
set(gca,'XTickLabel', equilibria)
legend(distr_tex, 'Location','northwest')

% plot Rr2 data
figure(2)
b_Rr2 = bar(Rr2_all);
for k = 1:length(Rr2_all)
    b_Rr2(k).FaceColor = 'flat';
    b_Rr2(k).CData = repmat(distribution_cols(k,:), length(equilibria), 1);
end
title('$R_r^2$', 'interpreter', 'latex','FontSize',20)
set(gca,'XTickLabel', equilibria)
legend(distr_tex, 'Location','northwest')

% plot Rsr2 data
figure(3)
b_Rsr2 = bar(Rsr2_all);
for k = 1:length(Rsr2_all)
    b_Rsr2(k).FaceColor = 'flat';
    b_Rsr2(k).CData = repmat(distribution_cols(k,:), length(equilibria), 1);
end
title('$\left(R_s^r\right)^2$', 'interpreter', 'latex','FontSize',20)
set(gca,'XTickLabel', equilibria)
legend(distr_tex, 'Location','northwest')

% plot Rrs2 data
figure(4)
b_Rrs2 = bar(Rrs2_all);
for k = 1:length(Rrs2_all)
    b_Rrs2(k).FaceColor = 'flat';
    b_Rrs2(k).CData = repmat(distribution_cols(k,:), length(equilibria), 1);
end
title('$\left(R_r^s\right)^2$', 'interpreter', 'latex','FontSize',20)
set(gca,'XTickLabel', equilibria)
legend(distr_tex, 'Location','northwest')

figure(5)
b_Rs2 = bar(Rs2_all(1,:));
b_Rs2.FaceColor = 'flat';
for k = 1:length(Rs2_all)
    b_Rs2.CData(k,:) = distribution_cols(k,:);
end
title('$R_s^2$', 'interpreter', 'latex','FontSize',20)
set(gca,'XTickLabel', distr_tex)
set(gca,'XTickLabel', distr_tex,'FontSize',20)
xtickangle(45)

figure(6)
b_Rr2 = bar(Rr2_all(1,:));
b_Rr2.FaceColor = 'flat';
for k = 1:length(Rr2_all)
    b_Rr2.CData(k,:) = distribution_cols(k,:);
end
title('$R_r^2$', 'interpreter', 'latex','FontSize',20)
set(gca,'XTickLabel', distr_tex)
set(gca,'XTickLabel', distr_tex,'FontSize',20)
xtickangle(45)

figure(7)
b_Rsr2 = bar(Rsr2_all(4,:));
b_Rsr2.FaceColor = 'flat';
for k = 1:length(Rr2_all)
    b_Rsr2.CData(k,:) = distribution_cols(k,:);
end
title('$(R_s^r)^2$', 'interpreter', 'latex','FontSize',20)
set(gca,'XTickLabel', distr_tex,'FontSize',20)
xtickangle(45)

figure(8)
b_Rrs2 = bar(Rrs2_all(2,:));
b_Rrs2.FaceColor = 'flat';
for k = 1:length(Rr2_all)
    b_Rrs2.CData(k,:) = distribution_cols(k,:);
end
title('$(R_r^s)^2$', 'interpreter', 'latex')
set(gca,'XTickLabel', distr_tex,'FontSize',20)
xtickangle(45)

%% names
name = 'reproduction_invasion_nums';

%data name
dataname = strcat(name,'.mat');

%figure names
fignameRs2all = strcat(name,'_Rs2_all','.fig');
fignameRs2all_JPG = strcat(name,'_Rs2_all','.jpg');

fignameRr2all = strcat(name,'_Rr2_all','.fig');
fignameRr2all_JPG = strcat(name,'_Rr2_all','.jpg');

fignameRsr2all = strcat(name,'_Rsr2_all','.fig');
fignameRsr2all_JPG = strcat(name,'_Rsr2_all','.jpg');

fignameRrs2all = strcat(name,'_Rrs2_all','.fig');
fignameRrs2all_JPG = strcat(name,'_Rrs2_all','.jpg');

fignameRs2DFE = strcat(name,'_Rs2_DFE','.fig');
fignameRs2DFE_JPG = strcat(name,'_Rs2_DFE','.jpg');

fignameRr2DFE = strcat(name,'_Rr2_DFE','.fig');
fignameRr2DFE_JPG = strcat(name,'_Rr2_DFE','.jpg');

fignameRsr2RSE = strcat(name,'_Rsr2_RSE','.fig');
fignameRsr2RSE_JPG = strcat(name,'_Rsr2_RSE','.jpg');

fignameRrs2SSE = strcat(name,'_Rrs2_SSE','.fig');
fignameRrs2SSE_JPG = strcat(name,'_Rrs2_SSE','.jpg');

%% save data

save([pwd strcat('/Data/',dataname)]);



%save figures in .fig and .jpg 
savefig(figure(1), [pwd strcat('/FiguresFIG/',fignameRs2all)]);
saveas(figure(1), [pwd strcat('/FiguresJPG/',fignameRs2all_JPG)]);

savefig(figure(2), [pwd strcat('/FiguresFIG/',fignameRr2all)]);
saveas(figure(2), [pwd strcat('/FiguresJPG/',fignameRr2all_JPG)]);

savefig(figure(3), [pwd strcat('/FiguresFIG/',fignameRsr2all)]);
saveas(figure(3), [pwd strcat('/FiguresJPG/',fignameRsr2all_JPG)]);

savefig(figure(4), [pwd strcat('/FiguresFIG/',fignameRrs2all)]);
saveas(figure(4), [pwd strcat('/FiguresJPG/',fignameRrs2all_JPG)]);

savefig(figure(5), [pwd strcat('/FiguresFIG/',fignameRs2DFE)]);
saveas(figure(5), [pwd strcat('/FiguresJPG/',fignameRs2DFE_JPG)]);

savefig(figure(6), [pwd strcat('/FiguresFIG/',fignameRr2DFE)]);
saveas(figure(6), [pwd strcat('/FiguresJPG/',fignameRr2DFE_JPG)]);

savefig(figure(7), [pwd strcat('/FiguresFIG/',fignameRsr2RSE)]);
saveas(figure(7), [pwd strcat('/FiguresJPG/',fignameRsr2RSE_JPG)]);

savefig(figure(8), [pwd strcat('/FiguresFIG/',fignameRrs2SSE)]);
saveas(figure(8), [pwd strcat('/FiguresJPG/',fignameRrs2SSE_JPG)]);


% legend(distr_tex, 'Location','northwest')
% 
% figure(2)
% b_Rr2 = bar(Rr2_all);
% % b_Rr2.FaceColor = 'flat';
% % for k = 1:length(Rr2_all)
% %     b_Rr2.CData(k,:) = distribution_cols(k,:);
% % end
% title('$R_r^2$', 'interpreter', 'latex','FontSize',20)
% set(gca,'XTickLabel',equilibria)
% legend(distr_tex, 'Location','northwest')
% 
% figure(3)
% b_Rsr2 = bar(Rsr2_all);
% % b_Rsr2.FaceColor = 'flat';
% % for k = 1:length(Rsr2_all)
% %     b_Rsr2.CData(k,:) = distribution_cols(k,:);
% % end
% title('$\left(R_s^r\right)^2$', 'interpreter', 'latex','FontSize',20)
% set(gca,'XTickLabel',equilibria)
% legend(distr_tex, 'Location','northwest')
% 
% figure(4)
% b_Rrs2 = bar(Rrs2_all);
% % b_Rrs2.FaceColor = 'flat';
% % for k = 1:length(Rrs2_all)
% %     b_Rrs2.CData(k,:) = distribution_cols(k,:);
% % end
% title('$\left(R_r^s\right)^2$', 'interpreter', 'latex','FontSize',20)
% set(gca,'XTickLabel',equilibria)
% legend(distr_tex, 'Location','northwest')
