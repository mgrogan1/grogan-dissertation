%% plot survival function pdfs.
% call Survival_Func.m to grab functions.

clear
close all

mean_vec = [1/100, 1/75, 1/50, 1/25, 1/15, 1/10, 1/5];%linspace(0.01, 0.1, 6);%[0, 0.001, 0.2, 0.4, 0.8, 1, 10];
scale_vec = 1./mean_vec;
shape_vec = [1, 2, 3, 4, 6, 8, 10];
tmin = 0;
tmax = 200;

figure(1)

subplot(1,3,1)
hold on
for i = 1:length(mean_vec)
    
    mean = mean_vec(i); %scale
    scale = 1/mean;
    
    P_EXP = @(x) exp(-mean*x);
    
    fplot(P_EXP, [tmin tmax], 'linewidth',2)
    mean_label_EXP(i) = {sprintf('mean = %g',scale)};
end
title(sprintf('Exponential'),'fontsize',20)
xlabel('time (days)', 'fontsize',15)
ylabel('survival probability', 'fontsize',15)
legend(mean_label_EXP, 'Location','northeast', 'fontsize',15);


%figure(2)
subplot(1,3,2)
hold on
for j = 1:length(shape_vec)
    
    shape = shape_vec(j);
    mean = 1/100; %scale
    scale = 1/(mean*shape); 
    
    P_GAMMA = @(x) 1 - gamcdf(x,shape,scale);
    
    fplot(P_GAMMA, [tmin tmax], 'linewidth',2)
    shape_label_GAMMA(j) = {sprintf('shape = %g',shape)};
    %legend(strcat('shape = ',shape_vec(j)), 'Location','northwest')
end
title(sprintf('Gamma (mean = %g)',1/mean),'fontsize',20)
xlabel('time (days)', 'fontsize',15)
%ylabel('survival probability', 'fontsize',15)
legend(shape_label_GAMMA, 'Location','northeast', 'fontsize',15);


%figure(3)
subplot(1,3,3)
hold on
for j = 1:length(shape_vec)
    
    shape = shape_vec(j);
    mean = 1/100; %scale 
    
    P_WEIBULL_distr = makedist('Weibull','a',1/mean,'b',shape);
    P_WEIBULL = @(x) 1-cdf(P_WEIBULL_distr,x);
   
    fplot(P_WEIBULL, [tmin tmax], 'linewidth',2)
    shape_label_WEIBULL(j) = {sprintf('shape = %g',shape)};
    
end
title(sprintf('Weibull (mean = %g)',1/mean),'fontsize',20)
xlabel('time (days)', 'fontsize',15)
%ylabel('survival probability', 'fontsize',15)
legend(shape_label_WEIBULL, 'Location','northeast', 'fontsize',15);

% figure(4)
% hold on
% 
% for j = 1:length(shape_vec)
%     
%     shape = shape_vec(j);
%     mean = 1/100; %scale 
%     
%     P_GOMPERTZ = @(x) exp(-shape*(exp(mean*x)-1));
%    
%     fplot(P_GOMPERTZ, [tmin tmax], 'linewidth',2)
%     shape_label_GOMPERTZ(j) = {sprintf('shape = %g',shape)};
%     
% end
% title(sprintf('Gompertz Survival Function (mean = %g)',1/mean),'fontsize',20)
% xlabel('time (days)', 'fontsize',15)
% %ylabel('survival probability', 'fontsize',15)
% legend(shape_label_GOMPERTZ, 'Location','northeast', 'fontsize',15);


