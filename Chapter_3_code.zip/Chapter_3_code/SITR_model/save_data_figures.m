%% save data and figures

%% names

%data name
dataname = strcat(name,'.mat');

%figure name - humans
fignameH = strcat(name,'_H','.fig');
fignameH_JPG = strcat(name,'_H','.jpg');

%figure name - vectors
fignameV = strcat(name,'_V','.fig');
fignameV_JPG = strcat(name,'_V','.jpg');

%% save data

save([pwd strcat('/Data/',dataname)]);

%% save human figures 

%save figures in .fig and .jpg - humans 
savefig(figure(1), [pwd strcat('/FiguresFIG/',fignameH)]);
saveas(figure(1), [pwd strcat('/FiguresJPG/',fignameH_JPG)]);

%% save vector figures 

%save figures in .fig and .jpg - vectors
savefig(figure(2), [pwd strcat('/FiguresFIG/',fignameV)]);
saveas(figure(2), [pwd strcat('/FiguresJPG/',fignameV_JPG)]);


