
%tic %start timer

%Sv'Ms'Mr'Sh'Is'Ir'Tsk'Trk'Rs'Rr'

%format long
%close all
%clear all
%clc

% load data
%load('Data/fullmodel_dt_-1_tf_300_integral_exp.mat');

% choose tf
interesting_t = t(1:length(tspan));

% choose colormap
colors=colormap(cool(15));

% combinedHUMANS = [    Sht;    Ist;    Irt;    Tst;    Trt;    Rst;    Rrt;
%                       z(:,1); z(:,2); z(:,3); z(:,4); z(:,5); z(:,6); z(:,7)];
% combinedVECTORS = [   Svt;    Mst;    Mrt;
%                       z(:,8); z(:,9); z(:,10)];

% Humans
Susceptible_H = [   Sht,    z(:,1)  ];
Infected_H = [   Ist,    Irt,    z(:,2),     z(:,3)   ]; 
Treated_H = [   Tst,    Trt,    z(:,4),     z(:,5)   ]; 
Recovered_H = [   Rst,    Rrt,    z(:,6),     z(:,7)   ]; 

% Vectors
Susceptible_V = [   Svt,    z(:,8)  ];
Infected_V = [   Mst,    Mrt,    z(:,9),     z(:,10)   ]; 

% options for switch are 'ode', 'integral_all_exp'

switch 'integral_all_exp'
    
    case 'ode'
        
        %% 'NON-Infectious_H_ode' 
        
        subplot(2,2,1)
        hold on
        
        %susceptibles
        p(1) = plot(interesting_t,z(1:length(interesting_t),1),'linewidth',2);
        p(1).Color=colors(2,:);
        
        %s-strain recovered
        p(2) = plot(interesting_t,z(1:length(interesting_t),6),'linewidth',2);
        p(2).Color=colors(12,:);
        
        %r-strain recovered 
        p(3) = plot(interesting_t,z(1:length(interesting_t),7),'--','linewidth',2);
        p(3).Color=colors(14,:);
        
        %legend & labels
        legend('susceptible', 's-recovered', 'r-recovered','fontsize',10, 'Location','southeast')
        title(sprintf('Non-Infectious Humans (ODE)'),'fontsize',12)
        xlabel('time','fontsize',10)
        ylabel('population size','fontsize', 10)
    
        %% 'Infectious_H_ode' 
        
        subplot(2,2,2)
        hold on
        
        %s-strain
        p(4) = plot(interesting_t,z(1:length(interesting_t),2),'linewidth',2);
        p(4).Color=colors(2,:);
        
        %r-strain
        p(5) = plot(interesting_t,z(1:length(interesting_t),3),'--','linewidth',2);
        p(5).Color=colors(4,:);
        
        %s-strain
        p(6) = plot(interesting_t,z(1:length(interesting_t),4),'linewidth',2);
        p(6).Color=colors(12,:);
        
        %r-strain
        p(7) = plot(interesting_t,z(1:length(interesting_t),5),'--','linewidth',2);
        p(7).Color=colors(14,:);
        
        %legend & labels
        legend('s-infected', 'r-infected', 's-treated', 'r-treated','fontsize',10)
        title(sprintf('Infectious Humans (ODE)'),'fontsize',12)
        xlabel('time','fontsize',10)
        ylabel('population size','fontsize', 10)
        
        %% 'NON-Infectious_V_ode' 
        
        subplot(2,2,3)
        hold on
        
        %susceptibles
        p(8) = plot(interesting_t,z(1:length(interesting_t),8),'linewidth',2);
        p(8).Color=colors(4,:);
        
        %legend & labels
        legend('susceptible','fontsize',10,'Location','southeast')
        title(sprintf('Non-Infectious Vectors (ODE)'),'fontsize',12)
        xlabel('time','fontsize',10)
        ylabel('population size','fontsize', 10)
        
        %% 'Infectious_V_ode' 
        
        subplot(2,2,4)
        hold on
        
        %s-strain
        p(9) = plot(interesting_t,z(1:length(interesting_t),9),'linewidth',2);
        p(9).Color=colors(2,:);
        
        %r-strain
        p(10) = plot(interesting_t,z(1:length(interesting_t),10),'--','linewidth',2);
        p(10).Color=colors(14,:);    
        
        %legend & labels
        legend('s-infected', 'r-infected','fontsize',10)
        title(sprintf('Infectious Vectors (ODE)'),'fontsize',12)
        xlabel('time','fontsize',10)
        ylabel('population size','fontsize', 10)
        
        
        %% names

        %data name
        dataname_ode = strcat(name, '_ode', '.mat');

        %figure name 
        figname_ode = strcat(name,'_ode','.fig');
        figname_ode_JPG = strcat(name,'_ode','.jpg');

        %% save data
        
        save([pwd strcat('/Data/',dataname_ode)]);

        %% save figures 
        
        %save figures in .fig and .jpg 
        savefig(figure(1), [pwd strcat('/FiguresFIG/',figname_ode)]);
        saveas(figure(1), [pwd strcat('/FiguresJPG/',figname_ode_JPG)]);
        
    case 'integral_all_exp'
        
        %% 'NON-Infectious_H_integral_all_exp' 
        
        subplot(2,2,1)
        hold on
        
        %susceptibles
        p(1) = plot(interesting_t,Susceptible_H(1:length(interesting_t),1),'linewidth',2);
        p(1).Color=colors(2,:);
        
        %s-strain recovered
        p(2) = plot(interesting_t,Recovered_H(1:length(interesting_t),1),'linewidth',2);
        p(2).Color=colors(12,:);
        
        %r-strain recovered 
        p(3) = plot(interesting_t,Recovered_H(1:length(interesting_t),2),'--','linewidth',2);
        p(3).Color=colors(14,:);
        
        %legend & labels
        legend('susceptible', 's-recovered', 'r-recovered','fontsize',10, 'Location','southeast')
        title(sprintf('Non-Infectious Humans (integral all exp)'),'fontsize',12)
        xlabel('time','fontsize',10)
        ylabel('population size','fontsize', 10)
    
        %% 'Infectious_H_integral_all_exp' 
        
        subplot(2,2,2)
        hold on
        
        %s-strain
        p(4) = plot(interesting_t,Infected_H(1:length(interesting_t),1),'linewidth',2);
        p(4).Color=colors(2,:);
        
        %r-strain
        p(5) = plot(interesting_t,Infected_H(1:length(interesting_t),2),'--','linewidth',2);
        p(5).Color=colors(4,:);
        
        %s-strain
        p(6) = plot(interesting_t,Treated_H(1:length(interesting_t),1),'linewidth',2);
        p(6).Color=colors(12,:);
        
        %r-strain
        p(7) = plot(interesting_t,Treated_H(1:length(interesting_t),2),'--','linewidth',2);
        p(7).Color=colors(14,:);
        
        %legend & labels
        legend('s-infected', 'r-infected', 's-treated', 'r-treated','fontsize',10)
        title(sprintf('Infectious Humans (integral all exp)'),'fontsize',12)
        xlabel('time','fontsize',10)
        ylabel('population size','fontsize', 10)
        
        %% 'NON-Infectious_V_integral_all_exp' 
        
        subplot(2,2,3)
        hold on
        
        %susceptibles
        p(8) = plot(interesting_t,Susceptible_V(1:length(interesting_t),1),'linewidth',2);
        p(8).Color=colors(4,:);
        
        %legend & labels
        legend('susceptible','fontsize',10,'Location','southeast')
        title(sprintf('Non-Infectious Vectors (integral all exp)'),'fontsize',12)
        xlabel('time','fontsize',10)
        ylabel('population size','fontsize', 10)
        
        %% 'Infectious_V_ode_integral_all_exp' 
        
        subplot(2,2,4)
        hold on
        
        %s-strain
        p(9) = plot(interesting_t,Infected_V(1:length(interesting_t),1),'linewidth',2);
        p(9).Color=colors(2,:);
        
        %r-strain
        p(10) = plot(interesting_t,Infected_V(1:length(interesting_t),2),'--','linewidth',2);
        p(10).Color=colors(14,:);    
        
        %legend & labels
        legend('s-infected', 'r-infected','fontsize',10)
        title(sprintf('Infectious Vectors (integral all exp)'),'fontsize',12)
        xlabel('time','fontsize',10)
        ylabel('population size','fontsize', 10)
        
        
        %% names

        %data name
        dataname_integral_exp = strcat(name, '_integral_exp', '.mat');

        %figure name 
        figname_integral_exp = strcat(name,'_integral_exp','.fig');
        figname_integral_exp_JPG = strcat(name,'_integral_exp','.jpg');

        %% save data
        
        save([pwd strcat('/Data/',dataname_integral_exp)]);

        %% save figures 
        
        %save figures in .fig and .jpg 
        savefig(figure(1), [pwd strcat('/FiguresFIG/',figname_integral_exp)]);
        saveas(figure(1), [pwd strcat('/FiguresJPG/',figname_integral_exp_JPG)]);
        

end

%toc %stop timer