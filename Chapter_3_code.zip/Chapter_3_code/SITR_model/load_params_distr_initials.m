%% define initial conditions

switch strain
    
    case '1'
        
        switch equilibrium
            
            case 'DFE'
                
                Nh0 = 35e6;     %Sh0 + Is0 + Ir0 + Ts0 + Tr0 + Rs0 + Rr0;
                Nv0 = 3*Nh0;    %5*Nh0;
                
                Sh0 = 0.80*Nh0;  %high EE = 0.35*Nh0;      %low DFE = 0.8*Nh0;     %0.605*Nh0; 53% + 7.5% of Nh from paper;   %1000;
                Is0 = 0.10*Nh0;  %high EE = 0.25*Nh0;      %low DFE = 0.1*Nh0;     %0.16*Nh0; 10% + 5% + 1% of Nh from paper; %40
                Ir0 = 0;         %10;
                Ts0 = 0;
                Tr0 = 0;
                Rs0 = 0.10*Nh0;  %high EE = 0.4*Nh0;       %high EE = 0.1*Nh0;     %0.3*Nh0; % 30% of Nh from paper
                Rr0 = 0;
                
                Sv0 = 0.8*Nv0;  %0.9*Nv0;
                Ms0 = 0.2*Nv0;  %0.07*Nv0;
                Mr0 = 0;        %0.03*Nv0;
                
                ShIsIrTsTrRsRrSvMsMr0 = [Sh0, Is0, Ir0, Ts0, Tr0, Rs0, Rr0, Sv0, Ms0, Mr0];
                
                
                %% Parameters
                
                a = 0.05/tc;                   %baseline = 0.05, range = (0.01 juvenile,0.05 adult), treatment/onset of symptoms rate, P_IsT
                alphaS = (1/5)/tc;               % = baseline treated recovery rate, P_TsR (P_Ts), (1/3, 1/10)
                alphaR = (1/10)/tc;              % = high baseline treated recovery rate, P_TrR (P_Tr), (1/3, 1/10)
                betaH = 0.02/tc;   %high EE = 0.1251;      %low DFE = 0.02     %transmission rate, %0.1251 = low baseline, high baseline=0.5561, range =(0.18, 0.9)
                betaV = 0.01/tc;   %high EE = 0.0313;      %low DFE = 0.01;    %low baseline=0.313, high baseline=0.0927, range =(0.03, 0.2)
                kappaH = 0.6;               %low baseline=0.6, high baseline=0.6, range=(0,1)
                kappaV = 0.4;               %low baseline=0.6, high baseline=0.6, range=(0,1)
                deltaS = (0.4/(1000*365))/tc;    %=baseline, range = (0.3/(1000*365), 0.6/(1000*365)), human disease-induced death rate, P_DDs
                deltaR = 0;                 %2*deltaS; %2 times more likely to die of resistant strain
                gammaS = (1/33)/tc;%sigma               %1/40; %recovery rate (?), (1/365, 1/28), baseline = 1/33
                gammaR = (1/60)/tc;%sigma               %recovery rate (?), P_IrR (P_Ir)
                psiS = 0.6;                 %scaled transmission for Ts individuals infecting mosquitos
                psiR = 0.6;                 %scaled transmission for Tr individuals infecting mosquitos
                %phi = 1;                    %scaled transmission for Ts individuals being infected by Mr mosquitos 
                muH = (4.43e-5)/tc;              %= baseline, range = (4.25,4.791)*10^(-5), human natural death rate, P_ND
                muV = (1/14)/tc;                 %= baseline, range = (1/21, 1/7)
                omegaS = (1/28)/tc;              %1/28;%1/370; %loss of immunity rate, P_IsS, P_RsS %1/328
                omegaR = (1/400)/tc;             %loss of immunity rate, P_IrS, P_RrS
                LambdaH0 = muH*Nh0;         %1.55e3;%3.55e3;%muH*Nh0;%3.55; %baseline value = 3.55e3, value range = (2.24*10^3, 5.08*10^3)
                %LambdaV0 = 1*(LambdaH0/muH)/muV; %high baseline = 3*Nh/muV, low baseline =1*Nh/muV, range = (1-10)*Nh/muV
                %LambdaV0 = 200*LambdaH0;
                LambdaV0 = Nv0*muV;         %1*Nh0/muV; %assume for now that we are at equilibrium
                
            case 'EE'
                
                Nh0 = 35e6;      %Sh0 + Is0 + Ir0 + Ts0 + Tr0 + Rs0 + Rr0;
                Nv0 = 3*Nh0;     %5*Nh0;
                
                Sh0 = 0.35*Nh0;  %high EE = 0.35*Nh0;      %low DFE = 0.8*Nh0;     %0.605*Nh0; 53% + 7.5% of Nh from paper;   %1000;
                Is0 = 0.25*Nh0;  %high EE = 0.25*Nh0;      %low DFE = 0.1*Nh0;     %0.16*Nh0; 10% + 5% + 1% of Nh from paper; %40
                Ir0 = 0;         %10;
                Ts0 = 0;
                Tr0 = 0;
                Rs0 = 0.40*Nh0;  %high EE = 0.40*Nh0;      %high EE = 0.1*Nh0;     %0.3*Nh0; % 30% of Nh from paper
                Rr0 = 0;
                
                Sv0 = 0.8*Nv0;  %0.9*Nv0;
                Ms0 = 0.2*Nv0;  %0.07*Nv0;
                Mr0 = 0;        %0.03*Nv0;
                ShIsIrTsTrRsRrSvMsMr0 = [Sh0, Is0, Ir0, Ts0, Tr0, Rs0, Rr0, Sv0, Ms0, Mr0];
                
                
                %% Parameters
                
                a = 0.05/tc;                   %baseline = 0.05, range = (0.01 juvenile,0.05 adult), treatment/onset of symptoms rate, P_IsT
                alphaS = (1/5)/tc;               % = baseline treated recovery rate, P_TsR (P_Ts), (1/3, 1/10)
                alphaR = (1/10)/tc;              % = high baseline treated recovery rate, P_TrR (P_Tr), (1/3, 1/10)
                betaH = 0.1251/tc;   %high EE = 0.1251;      %low DFE = 0.02     %transmission rate, %0.1251 = low baseline, high baseline=0.5561, range =(0.18, 0.9)
                betaV = 0.0313/tc;   %high EE = 0.0313;      %low DFE = 0.01;    %low baseline=0.313, high baseline=0.0927, range =(0.03, 0.2)
                kappaH = 0.6;               %low baseline=0.6, high baseline=0.6, range=(0,1)
                kappaV = 0.4;               %low baseline=0.6, high baseline=0.6, range=(0,1)
                deltaS = (0.4/(1000*365))/tc;    %=baseline, range = (0.3/(1000*365), 0.6/(1000*365)), human disease-induced death rate, P_DDs
                deltaR = 0;                 %2*deltaS; %2 times more likely to die of resistant strain
                gammaS = (1/33)/tc;%sigma               %1/40; %recovery rate (?), (1/365, 1/28), baseline = 1/33
                gammaR = (1/60)/tc;%sigma               %recovery rate (?), P_IrR (P_Ir)
                psiS = 0.6;                 %scaled transmission for Ts individuals
                psiR = 0.6;                 %scaled transmission for Tr individuals
                %phi = 1;                    %scaled transmission for Ts individuals being infected by Mr mosquitos
                muH = (4.43e-5)/tc;              %= baseline, range = (4.25,4.791)*10^(-5), human natural death rate, P_ND
                muV = (1/14)/tc;                 %= baseline, range = (1/21, 1/7)
                omegaS = (1/28)/tc;              %1/28;%1/370; %loss of immunity rate, P_IsS, P_RsS %1/328
                omegaR = (1/400)/tc;             %loss of immunity rate, P_IrS, P_RrS
                LambdaH0 = muH*Nh0;         %1.55e3;%3.55e3;%muH*Nh0;%3.55; %baseline value = 3.55e3, value range = (2.24*10^3, 5.08*10^3)
                %LambdaV0 = 1*(LambdaH0/muH)/muV; %high baseline = 3*Nh/muV, low baseline =1*Nh/muV, range = (1-10)*Nh/muV
                %LambdaV0 = 200*LambdaH0;
                LambdaV0 = Nv0*muV;         %1*Nh0/muV; %assume for now that we are at equilibrium
                
            case 'AIM2020_params'
                
                Nh0 = 35e6;      %Sh0 + Is0 + Ir0 + Ts0 + Tr0 + Rs0 + Rr0;
                Nv0 = 3*Nh0;     %5*Nh0;
                
                Sh0 = 0.35*Nh0;  %high EE = 0.35*Nh0;      %low DFE = 0.8*Nh0;     %0.605*Nh0; 53% + 7.5% of Nh from paper;   %1000;
                Is0 = 0.25*Nh0;  %high EE = 0.25*Nh0;      %low DFE = 0.1*Nh0;     %0.16*Nh0; 10% + 5% + 1% of Nh from paper; %40
                Ir0 = 0;         %10;
                Ts0 = 0;
                Tr0 = 0;
                Rs0 = 0.40*Nh0;  %high EE = 0.40*Nh0;      %high EE = 0.1*Nh0;     %0.3*Nh0; % 30% of Nh from paper
                Rr0 = 0;
                
                Sv0 = 0.8*Nv0;  %0.9*Nv0;
                Ms0 = 0.2*Nv0;  %0.07*Nv0;
                Mr0 = 0;        %0.03*Nv0;
                ShIsIrTsTrRsRrSvMsMr0 = [Sh0, Is0, Ir0, Ts0, Tr0, Rs0, Rr0, Sv0, Ms0, Mr0];
                
                
                %% Parameters
                
                a = (1/13.1)/tc;                 %baseline = 0.05, range = (0.01 juvenile,0.05 adult), treatment/onset of symptoms rate, P_IsT
                alphaS = 0.1382/tc;            % = baseline treated recovery rate, P_TsR (P_Ts), (1/3, 1/10)
                alphaR = (1/10)/tc;              % = high baseline treated recovery rate, P_TrR (P_Tr), (1/3, 1/10)
                betaH = 0.1251/tc;   %high EE = 0.1251;      %low DFE = 0.02     %transmission rate, %0.1251 = low baseline, high baseline=0.5561, range =(0.18, 0.9)
                betaV = 0.0313/tc;   %high EE = 0.0313;      %low DFE = 0.01;    %low baseline=0.313, high baseline=0.0927, range =(0.03, 0.2)
                kappaH = 0.6;               %low baseline=0.6, high baseline=0.6, range=(0,1)
                kappaV = 0.4;               %low baseline=0.6, high baseline=0.6, range=(0,1)
                deltaS = (0.4/(1000*365))/tc;    %=baseline, range = (0.3/(1000*365), 0.6/(1000*365)), human disease-induced death rate, P_DDs
                deltaR = 0;                 %2*deltaS; %2 times more likely to die of resistant strain
                gammaS = (1/200)/tc;%sigma              %1/40; %recovery rate (?), (1/365, 1/28), baseline = 1/33
                gammaR = (1/60)/tc;%sigma               %recovery rate (?), P_IrR (P_Ir)
                psiS = 0.6;                 %scaled transmission for Ts individuals
                psiR = 0.6;                 %scaled transmission for Tr individuals
                %phi = 1;                    %scaled transmission for Ts individuals being infected by Mr mosquitos
                muH = (4.43e-5)/tc;              %= baseline, range = (4.25,4.791)*10^(-5), human natural death rate, P_ND
                muV = (1/14)/tc;                 %= baseline, range = (1/21, 1/7)
                omegaS = (1/28)/tc;              %1/28;%1/370; %loss of immunity rate, P_IsS, P_RsS %1/328
                omegaR = (1/400)/tc;             %loss of immunity rate, P_IrS, P_RrS
                LambdaH0 = muH*Nh0;         %1.55e3;%3.55e3;%muH*Nh0;%3.55; %baseline value = 3.55e3, value range = (2.24*10^3, 5.08*10^3)
                %LambdaV0 = 1*(LambdaH0/muH)/muV; %high baseline = 3*Nh/muV, low baseline =1*Nh/muV, range = (1-10)*Nh/muV
                %LambdaV0 = 200*LambdaH0;
                LambdaV0 = Nv0*muV;         %1*Nh0/muV; %assume for now that we are at equilibrium
                
        end
        
    case '2'
        
        switch equilibrium
            
            case 'DFE'
                
                Nh0 = 35e6;     %Sh0 + Is0 + Ir0 + Ts0 + Tr0 + Rs0 + Rr0;
                Nv0 = 3*Nh0;    %5*Nh0;
                
                Sh0 = 0.70*Nh0;  %high EE = 0.35*Nh0;      %low DFE = 0.8*Nh0;     %0.605*Nh0; 53% + 7.5% of Nh from paper;   %1000;
                Is0 = 0.10*Nh0;  %high EE = 0.25*Nh0;      %low DFE = 0.1*Nh0;     %0.16*Nh0; 10% + 5% + 1% of Nh from paper; %40
                Ir0 = 0.05*Nh0;  %10;
                Ts0 = 0;
                Tr0 = 0;
                Rs0 = 0.10*Nh0;  %high EE = 0.40*Nh0;      %low DFE = 0.1*Nh0;     %0.3*Nh0; % 30% of Nh from paper
                Rr0 = 0.05*Nh0;
                
                Sv0 = 0.90*Nv0;     %0.9*Nv0;
                Ms0 = 0.07*Nv0;     %0.07*Nv0;
                Mr0 = 0.03*Nv0;     %0.03*Nv0;
                
                ShIsIrTsTrRsRrSvMsMr0 = [Sh0, Is0, Ir0, Ts0, Tr0, Rs0, Rr0, Sv0, Ms0, Mr0];
                 
                
                %% Parameters
                
                a = 0.05/tc;                   %baseline = 0.05, range = (0.01 juvenile,0.05 adult), treatment/onset of symptoms rate, P_IsT
                alphaS = (1/5)/tc;               % = baseline treated recovery rate, P_TsR (P_Ts), (1/3, 1/10)
                alphaR = (1/10)/tc;              % = high baseline treated recovery rate, P_TrR (P_Tr), (1/3, 1/10)
                betaH = 1.1*(0.1251)/tc;   %high EE = 0.1251;      %low DFE = 0.02     %transmission rate, %0.1251 = low baseline, high baseline=0.5561, range =(0.18, 0.9)
                betaV = 1.1*(0.0313)/tc;   %high EE = 0.0313;      %low DFE = 0.01;    %low baseline=0.313, high baseline=0.0927, range =(0.03, 0.2)
                kappaH = 0.6;               %low baseline=0.6, high baseline=0.6, range=(0,1)
                kappaV = 0.4;               %low baseline=0.6, high baseline=0.6, range=(0,1)
                deltaS = (0.4/(1000*365))/tc;    %=baseline, range = (0.3/(1000*365), 0.6/(1000*365)), human disease-induced death rate, P_DDs
                deltaR = 2*deltaS;                 %2*deltaS; %2 times more likely to die of resistant strain
                gammaS = 6*(1/33)/tc;%sigma               %1/40; %recovery rate (?), (1/365, 1/28), baseline = 1/33
                gammaR = 6*(1/60)/tc;%sigma               %recovery rate (?), P_IrR (P_Ir)
                psiS = 0.6;                 %scaled transmission for Ts individuals
                psiR = 0.6;                 %scaled transmission for Tr individuals
                %phi = 1;                    %scaled transmission for Ts individuals being infected by Mr mosquitos
                muH = (4.43e-5)/tc;              %= baseline, range = (4.25,4.791)*10^(-5), human natural death rate, P_ND
                muV = (1/14)/tc;                %= baseline, range = (1/21, 1/7)
                omegaS = (1/28)/tc;              %1/28;%1/370; %loss of immunity rate, P_IsS, P_RsS %1/328
                omegaR = (1/28)/tc;             %loss of immunity rate, P_IrS, P_RrS
                LambdaH0 = muH*Nh0;         %1.55e3;%3.55e3;%muH*Nh0;%3.55; %baseline value = 3.55e3, value range = (2.24*10^3, 5.08*10^3)
                %LambdaV0 = 1*(LambdaH0/muH)/muV; %high baseline = 3*Nh/muV, low baseline =1*Nh/muV, range = (1-10)*Nh/muV
                %LambdaV0 = 200*LambdaH0;
                LambdaV0 = Nv0*muV;         %1*Nh0/muV; %assume for now that we are at equilibrium
                
            case 'EE'
                
                Nh0 = 35e6;     %Sh0 + Is0 + Ir0 + Ts0 + Tr0 + Rs0 + Rr0;
                Nv0 = 3*Nh0;    %5*Nh0;
                
                Sh0 = 0.35*Nh0;  %high EE = 0.35*Nh0;      %low DFE = 0.8*Nh0;     %0.605*Nh0; 53% + 7.5% of Nh from paper;   %1000;
                Is0 = 0.25*Nh0;  %high EE = 0.25*Nh0;      %low DFE = 0.1*Nh0;     %0.16*Nh0; 10% + 5% + 1% of Nh from paper; %40
                Ir0 = 0.15*Nh0;  %10;
                Ts0 = 0;
                Tr0 = 0;
                Rs0 = 0.15*Nh0;  %high EE = 0.40*Nh0;      %low DFE = 0.1*Nh0;     %0.3*Nh0; % 30% of Nh from paper
                Rr0 = 0.10*Nh0;
                
                Sv0 = 0.70*Nv0;     %0.9*Nv0;
                Ms0 = 0.20*Nv0;     %0.07*Nv0;
                Mr0 = 0.10*Nv0;     %0.03*Nv0;
                
                ShIsIrTsTrRsRrSvMsMr0 = [Sh0, Is0, Ir0, Ts0, Tr0, Rs0, Rr0, Sv0, Ms0, Mr0];
                
                
                %% Parameters
                
                a = 0.05/tc;                   %baseline = 0.05, range = (0.01 juvenile,0.05 adult), treatment/onset of symptoms rate, P_IsT
                alphaS = (1/5)/tc;               % = baseline treated recovery rate, P_TsR (P_Ts), (1/3, 1/10)
                alphaR = (1/10)/tc;              % = high baseline treated recovery rate, P_TrR (P_Tr), (1/3, 1/10)
                betaH = 0.1251/tc;   %high EE = 0.1251;      %low DFE = 0.02     %transmission rate, %0.1251 = low baseline, high baseline=0.5561, range =(0.18, 0.9)
                betaV = 0.0313/tc;   %high EE = 0.0313;      %low DFE = 0.01;    %low baseline=0.313, high baseline=0.0927, range =(0.03, 0.2)
                kappaH = 0.6;               %low baseline=0.6, high baseline=0.6, range=(0,1)
                kappaV = 0.4;               %low baseline=0.6, high baseline=0.6, range=(0,1)
                deltaS = (0.4/(1000*365))/tc;    %=baseline, range = (0.3/(1000*365), 0.6/(1000*365)), human disease-induced death rate, P_DDs
                deltaR = 0;                 %2*deltaS; %2 times more likely to die of resistant strain
                gammaS = (1/33)/tc; %sigma              %1/40; %recovery rate (?), (1/365, 1/28), baseline = 1/33
                gammaR = (1/60)/tc; %sigma             %recovery rate (?), P_IrR (P_Ir)
                psiS = 0.6;                 %scaled transmission for Ts individuals
                psiR = 0.6;                 %scaled transmission for Tr individuals
                %phi = 1;                    %scaled transmission for Ts individuals being infected by Mr mosquitos
                muH = (4.43e-5)/tc;              %= baseline, range = (4.25,4.791)*10^(-5), human natural death rate, P_ND
                muV = (1/14)/tc;                 %= baseline, range = (1/21, 1/7)
                omegaS = (1/28)/tc;              %1/28;%1/370; %loss of immunity rate, P_IsS, P_RsS %1/328
                omegaR = (1/400)/tc;             %loss of immunity rate, P_IrS, P_RrS
                LambdaH0 = muH*Nh0;         %1.55e3;%3.55e3;%muH*Nh0;%3.55; %baseline value = 3.55e3, value range = (2.24*10^3, 5.08*10^3)
                %LambdaV0 = 1*(LambdaH0/muH)/muV; %high baseline = 3*Nh/muV, low baseline =1*Nh/muV, range = (1-10)*Nh/muV
                %LambdaV0 = 200*LambdaH0;
                LambdaV0 = Nv0*muV;         %1*Nh0/muV; %assume for now that we are at equilibrium
                
            case 'SSE'
                
                Nh0 = 35e6;     %Sh0 + Is0 + Ir0 + Ts0 + Tr0 + Rs0 + Rr0;
                Nv0 = 3*Nh0;    %5*Nh0;
                
                Sh0 = 0.80*Nh0;  %high EE = 0.35*Nh0;      %low DFE = 0.8*Nh0;     %0.605*Nh0; 53% + 7.5% of Nh from paper;   %1000;
                Is0 = 0.15*Nh0;  %high EE = 0.25*Nh0;      %low DFE = 0.1*Nh0;     %0.16*Nh0; 10% + 5% + 1% of Nh from paper; %40
                Ir0 = 0; % 0.10*Nh0;  %10;
                Ts0 = 0;
                Tr0 = 0;
                Rs0 = 0.05*Nh0;  %high EE = 0.40*Nh0;      %low DFE = 0.1*Nh0;     %0.3*Nh0; % 30% of Nh from paper
                Rr0 = 0; % 0.10*Nh0;
                
                Sv0 = 0.90*Nv0;     %0.9*Nv0;
                Ms0 = 0.10*Nv0;     %0.07*Nv0;
                Mr0 = 0; % 0.10*Nv0;     %0.03*Nv0;
                
                ShIsIrTsTrRsRrSvMsMr0 = [Sh0, Is0, Ir0, Ts0, Tr0, Rs0, Rr0, Sv0, Ms0, Mr0];
                
                
                %% Parameters
                a = (0.05)/tc;                   %baseline = 0.05, range = (0.01 juvenile,0.05 adult), treatment/onset of symptoms rate, P_IsT
                alphaS = (1/5)/tc;               % = baseline treated recovery rate, P_TsR (P_Ts), (1/3, 1/10)
                alphaR = (1/10)/tc;              % = high baseline treated recovery rate, P_TrR (P_Tr), (1/3, 1/10)
                betaH = 1*(0.1251)/tc;   %high EE = 0.1251;      %low DFE = 0.02     %transmission rate, %0.1251 = low baseline, high baseline=0.5561, range =(0.18, 0.9)
                betaV = 1*(0.0313)/tc;   %high EE = 0.0313;      %low DFE = 0.01;    %low baseline=0.313, high baseline=0.0927, range =(0.03, 0.2)
                kappaH = (0.6);               %low baseline=0.6, high baseline=0.6, range=(0,1)
                kappaV = (0.4);               %low baseline=0.6, high baseline=0.6, range=(0,1)
                deltaS = (0.4/(1000*365))/tc;    %=baseline, range = (0.3/(1000*365), 0.6/(1000*365)), human disease-induced death rate, P_DDs
                deltaR = (2*deltaS);                 %2*deltaS; %2 times more likely to die of resistant strain
                gammaS = (1/33)/tc;%sigma               %1/40; %recovery rate (?), (1/365, 1/28), baseline = 1/33
                gammaR = (1/60)/tc;%sigma               %recovery rate (?), P_IrR (P_Ir)
                psiS = (0.6);                 %scaled transmission for Ts individuals
                psiR = (0.6);                 %scaled transmission for Tr individuals
                %phi = 1;                    %scaled transmission for Ts individuals being infected by Mr mosquitos
                muH = (4.43e-5)/tc;              %= baseline, range = (4.25,4.791)*10^(-5), human natural death rate, P_ND
                muV = (1/14)/tc;                 %= baseline, range = (1/21, 1/7)
                omegaS = (1/28)/tc;              %1/28;%1/370; %loss of immunity rate, P_IsS, P_RsS %1/328
                omegaR = (1/28)/tc;             %1/400; loss of immunity rate, P_IrS, P_RrS
                LambdaH0 = (muH*Nh0);         %1.55e3;%3.55e3;%muH*Nh0;%3.55; %baseline value = 3.55e3, value range = (2.24*10^3, 5.08*10^3)
                %LambdaV0 = 1*(LambdaH0/muH)/muV; %high baseline = 3*Nh/muV, low baseline =1*Nh/muV, range = (1-10)*Nh/muV
                %LambdaV0 = 200*LambdaH0;
                LambdaV0 = (Nv0*muV);         %1*Nh0/muV; %assume for now that we are at equilibrium
               
            case 'RSE'
                
                Nh0 = 35e6;     %Sh0 + Is0 + Ir0 + Ts0 + Tr0 + Rs0 + Rr0;
                Nv0 = 3*Nh0;    %5*Nh0;
                
                Sh0 = 0.80*Nh0;  %high EE = 0.35*Nh0;      %low DFE = 0.8*Nh0;     %0.605*Nh0; 53% + 7.5% of Nh from paper;   %1000;
                Is0 = 0; %0.15*Nh0;  %high EE = 0.25*Nh0;      %low DFE = 0.1*Nh0;     %0.16*Nh0; 10% + 5% + 1% of Nh from paper; %40
                Ir0 = 0.15*Nh0;  %10;
                Ts0 = 0;
                Tr0 = 0;
                Rs0 = 0; %0.15*Nh0;  %high EE = 0.40*Nh0;      %low DFE = 0.1*Nh0;     %0.3*Nh0; % 30% of Nh from paper
                Rr0 = 0.05*Nh0;
                
                Sv0 = 0.90*Nv0;     %0.9*Nv0;
                Ms0 = 0; %0.15*Nv0;     %0.07*Nv0;
                Mr0 = 0.10*Nv0;     %0.03*Nv0;
                
                ShIsIrTsTrRsRrSvMsMr0 = [Sh0, Is0, Ir0, Ts0, Tr0, Rs0, Rr0, Sv0, Ms0, Mr0];
                
                
                %% Parameters
                a = (0.05)/tc;                   %baseline = 0.05, range = (0.01 juvenile,0.05 adult), treatment/onset of symptoms rate, P_IsT
                alphaS = (1/5)/tc;               % = baseline treated recovery rate, P_TsR (P_Ts), (1/3, 1/10)
                alphaR = (1/10)/tc;              % = high baseline treated recovery rate, P_TrR (P_Tr), (1/3, 1/10)
                betaH = 1.25*(0.1251)/tc;   %high EE = 0.1251;      %low DFE = 0.02     %transmission rate, %0.1251 = low baseline, high baseline=0.5561, range =(0.18, 0.9)
                betaV = 1.25*(0.0313)/tc;   %high EE = 0.0313;      %low DFE = 0.01;    %low baseline=0.313, high baseline=0.0927, range =(0.03, 0.2)
                kappaH = (0.7); %1; %(0.6);               %low baseline=0.6, high baseline=0.6, range=(0,1)
                kappaV = (0.4); %1; %(0.4);               %low baseline=0.6, high baseline=0.6, range=(0,1)
                deltaS = (0.4/(1000*365))/tc;    %=baseline, range = (0.3/(1000*365), 0.6/(1000*365)), human disease-induced death rate, P_DDs
                deltaR = (2*deltaS);                 %2*deltaS; %2 times more likely to die of resistant strain
                gammaS = (1/33)/tc;%sigma               %1/40; %recovery rate (?), (1/365, 1/28), baseline = 1/33
                gammaR = (1/60)/tc;%sigma               %recovery rate (?), P_IrR (P_Ir)
                psiS = (0.6);                 %scaled transmission for Ts individuals
                psiR = (0.6);                 %scaled transmission for Tr individuals
                %phi = 1;                    %scaled transmission for Ts individuals being infected by Mr mosquitos
                muH = (4.43e-5)/tc;              %= baseline, range = (4.25,4.791)*10^(-5), human natural death rate, P_ND
                muV = (1/14)/tc;                 %= baseline, range = (1/21, 1/7)
                omegaS = (1/28)/tc;              %1/28;%1/370; %loss of immunity rate, P_IsS, P_RsS %1/328
                omegaR = (1/28)/tc;             %1/400; loss of immunity rate, P_IrS, P_RrS
                LambdaH0 = (muH*Nh0);         %1.55e3;%3.55e3;%muH*Nh0;%3.55; %baseline value = 3.55e3, value range = (2.24*10^3, 5.08*10^3)
                %LambdaV0 = 1*(LambdaH0/muH)/muV; %high baseline = 3*Nh/muV, low baseline =1*Nh/muV, range = (1-10)*Nh/muV
                %LambdaV0 = 200*LambdaH0;
                LambdaV0 = (Nv0*muV);         %1*Nh0/muV; %assume for now that we are at equilibrium

            case 'SSE_R'
                
                Nh0 = 35e6;     %Sh0 + Is0 + Ir0 + Ts0 + Tr0 + Rs0 + Rr0;
                Nv0 = 3*Nh0;    %5*Nh0;
                
                Sh0 = 0.70*Nh0;  %high EE = 0.35*Nh0;      %low DFE = 0.8*Nh0;     %0.605*Nh0; 53% + 7.5% of Nh from paper;   %1000;
                Is0 = 0.13*Nh0;  %high EE = 0.25*Nh0;      %low DFE = 0.1*Nh0;     %0.16*Nh0; 10% + 5% + 1% of Nh from paper; %40
                Ir0 = 0.07*Nh0;  %10;
                Ts0 = 0;
                Tr0 = 0;
                Rs0 = 0.07*Nh0;  %high EE = 0.40*Nh0;      %low DFE = 0.1*Nh0;     %0.3*Nh0; % 30% of Nh from paper
                Rr0 = 0.03*Nh0;
                
                Sv0 = 0.90*Nv0;     %0.9*Nv0;
                Ms0 = 0.07*Nv0;     %0.07*Nv0;
                Mr0 = 0.03*Nv0;     %0.03*Nv0;
                
                ShIsIrTsTrRsRrSvMsMr0 = [Sh0, Is0, Ir0, Ts0, Tr0, Rs0, Rr0, Sv0, Ms0, Mr0];
                
                
                %% Parameters
                a = (0.05)/tc;                   %baseline = 0.05, range = (0.01 juvenile,0.05 adult), treatment/onset of symptoms rate, P_IsT
                alphaS = (1/5)/tc;               % = baseline treated recovery rate, P_TsR (P_Ts), (1/3, 1/10)
                alphaR = (1/10)/tc;              % = high baseline treated recovery rate, P_TrR (P_Tr), (1/3, 1/10)
                betaH = 1*(0.1251)/tc;   %high EE = 0.1251;      %low DFE = 0.02     %transmission rate, %0.1251 = low baseline, high baseline=0.5561, range =(0.18, 0.9)
                betaV = 1*(0.0313)/tc;   %high EE = 0.0313;      %low DFE = 0.01;    %low baseline=0.313, high baseline=0.0927, range =(0.03, 0.2)
                kappaH = (0.6);               %low baseline=0.6, high baseline=0.6, range=(0,1)
                kappaV = (0.4);               %low baseline=0.6, high baseline=0.6, range=(0,1)
                deltaS = (0.4/(1000*365))/tc;    %=baseline, range = (0.3/(1000*365), 0.6/(1000*365)), human disease-induced death rate, P_DDs
                deltaR = (2*deltaS);                 %2*deltaS; %2 times more likely to die of resistant strain
                gammaS = (1/33)/tc;%sigma               %1/40; %recovery rate (?), (1/365, 1/28), baseline = 1/33
                gammaR = (1/60)/tc;%sigma               %recovery rate (?), P_IrR (P_Ir)
                psiS = (0.6);                 %scaled transmission for Ts individuals
                psiR = (0.6);                 %scaled transmission for Tr individuals
                %phi = 1;                    %scaled transmission for Ts individuals being infected by Mr mosquitos
                muH = (4.43e-5)/tc;              %= baseline, range = (4.25,4.791)*10^(-5), human natural death rate, P_ND
                muV = (1/14)/tc;                 %= baseline, range = (1/21, 1/7)
                omegaS = (1/28)/tc;              %1/28;%1/370; %loss of immunity rate, P_IsS, P_RsS %1/328
                omegaR = (1/28)/tc;             %1/400; loss of immunity rate, P_IrS, P_RrS
                LambdaH0 = (muH*Nh0);         %1.55e3;%3.55e3;%muH*Nh0;%3.55; %baseline value = 3.55e3, value range = (2.24*10^3, 5.08*10^3)
                %LambdaV0 = 1*(LambdaH0/muH)/muV; %high baseline = 3*Nh/muV, low baseline =1*Nh/muV, range = (1-10)*Nh/muV
                %LambdaV0 = 200*LambdaH0;
                LambdaV0 = (Nv0*muV);         %1*Nh0/muV; %assume for now that we are at equilibrium

                      
            case 'RSE_S'
                
                Nh0 = 35e6;     %Sh0 + Is0 + Ir0 + Ts0 + Tr0 + Rs0 + Rr0;
                Nv0 = 3*Nh0;    %5*Nh0;
                
                Sh0 = 0.70*Nh0;  %high EE = 0.35*Nh0;      %low DFE = 0.8*Nh0;     %0.605*Nh0; 53% + 7.5% of Nh from paper;   %1000;
                Is0 = 0.13*Nh0;  %high EE = 0.25*Nh0;      %low DFE = 0.1*Nh0;     %0.16*Nh0; 10% + 5% + 1% of Nh from paper; %40
                Ir0 = 0.07*Nh0;  %10;
                Ts0 = 0;
                Tr0 = 0;
                Rs0 = 0.07*Nh0;  %high EE = 0.40*Nh0;      %low DFE = 0.1*Nh0;     %0.3*Nh0; % 30% of Nh from paper
                Rr0 = 0.03*Nh0;
                
                Sv0 = 0.90*Nv0;     %0.9*Nv0;
                Ms0 = 0.07*Nv0;     %0.07*Nv0;
                Mr0 = 0.03*Nv0;     %0.03*Nv0;
                
                ShIsIrTsTrRsRrSvMsMr0 = [Sh0, Is0, Ir0, Ts0, Tr0, Rs0, Rr0, Sv0, Ms0, Mr0];
                
                
                %% Parameters
                a = (0.05)/tc;                   %baseline = 0.05, range = (0.01 juvenile,0.05 adult), treatment/onset of symptoms rate, P_IsT
                alphaS = (1/5)/tc;               % = baseline treated recovery rate, P_TsR (P_Ts), (1/3, 1/10)
                alphaR = (1/10)/tc;              % = high baseline treated recovery rate, P_TrR (P_Tr), (1/3, 1/10)
                betaH = 1.25*(0.1251)/tc;   %high EE = 0.1251;      %low DFE = 0.02     %transmission rate, %0.1251 = low baseline, high baseline=0.5561, range =(0.18, 0.9)
                betaV = 1.25*(0.0313)/tc;   %high EE = 0.0313;      %low DFE = 0.01;    %low baseline=0.313, high baseline=0.0927, range =(0.03, 0.2)
                kappaH = (0.7); %1; %(0.6);               %low baseline=0.6, high baseline=0.6, range=(0,1)
                kappaV = (0.4); %1; %(0.4);               %low baseline=0.6, high baseline=0.6, range=(0,1)
                deltaS = (0.4/(1000*365))/tc;    %=baseline, range = (0.3/(1000*365), 0.6/(1000*365)), human disease-induced death rate, P_DDs
                deltaR = (2*deltaS);                 %2*deltaS; %2 times more likely to die of resistant strain
                gammaS = (1/33)/tc;%sigma               %1/40; %recovery rate (?), (1/365, 1/28), baseline = 1/33
                gammaR = (1/60)/tc;%sigma               %recovery rate (?), P_IrR (P_Ir)
                psiS = (0.6);                 %scaled transmission for Ts individuals
                psiR = (0.6);                 %scaled transmission for Tr individuals
                %phi = 1;                    %scaled transmission for Ts individuals being infected by Mr mosquitos
                muH = (4.43e-5)/tc;              %= baseline, range = (4.25,4.791)*10^(-5), human natural death rate, P_ND
                muV = (1/14)/tc;                 %= baseline, range = (1/21, 1/7)
                omegaS = (1/28)/tc;              %1/28;%1/370; %loss of immunity rate, P_IsS, P_RsS %1/328
                omegaR = (1/28)/tc;             %1/400; loss of immunity rate, P_IrS, P_RrS
                LambdaH0 = (muH*Nh0);         %1.55e3;%3.55e3;%muH*Nh0;%3.55; %baseline value = 3.55e3, value range = (2.24*10^3, 5.08*10^3)
                %LambdaV0 = 1*(LambdaH0/muH)/muV; %high baseline = 3*Nh/muV, low baseline =1*Nh/muV, range = (1-10)*Nh/muV
                %LambdaV0 = 200*LambdaH0;
                LambdaV0 = (Nv0*muV);         %1*Nh0/muV; %assume for now that we are at equilibrium
            
            
            
            case 'coexistence'
                
                Nh0 = 35e6;     %Sh0 + Is0 + Ir0 + Ts0 + Tr0 + Rs0 + Rr0;
                Nv0 = 3*Nh0;    %5*Nh0;
                
                Sh0 = 0.70*Nh0;  %high EE = 0.35*Nh0;      %low DFE = 0.8*Nh0;     %0.605*Nh0; 53% + 7.5% of Nh from paper;   %1000;
                Is0 = 0.10*Nh0;  %high EE = 0.25*Nh0;      %low DFE = 0.1*Nh0;     %0.16*Nh0; 10% + 5% + 1% of Nh from paper; %40
                Ir0 = 0.05*Nh0;  %10;
                Ts0 = 0;
                Tr0 = 0;
                Rs0 = 0.10*Nh0;  %high EE = 0.40*Nh0;      %low DFE = 0.1*Nh0;     %0.3*Nh0; % 30% of Nh from paper
                Rr0 = 0.05*Nh0;
                
                Sv0 = 0.80*Nv0;     %0.9*Nv0;
                Ms0 = 0.10*Nv0;     %0.07*Nv0;
                Mr0 = 0.05*Nv0;     %0.03*Nv0;
                
                ShIsIrTsTrRsRrSvMsMr0 = [Sh0, Is0, Ir0, Ts0, Tr0, Rs0, Rr0, Sv0, Ms0, Mr0];
                
                
                %% Parameters
                a = (0.05)/tc;                   %baseline = 0.05, range = (0.01 juvenile,0.05 adult), treatment/onset of symptoms rate, P_IsT
                alphaS = (1/5)/tc;               % = baseline treated recovery rate, P_TsR (P_Ts), (1/3, 1/10)
                alphaR = (1/10)/tc;              % = high baseline treated recovery rate, P_TrR (P_Tr), (1/3, 1/10)
                betaH = 2*(0.1251)/tc;   %high EE = 0.1251;      %low DFE = 0.02     %transmission rate, %0.1251 = low baseline, high baseline=0.5561, range =(0.18, 0.9)
                betaV = 2*(0.0313)/tc;   %high EE = 0.0313;      %low DFE = 0.01;    %low baseline=0.313, high baseline=0.0927, range =(0.03, 0.2)
                kappaH = (0.6);               %low baseline=0.6, high baseline=0.6, range=(0,1)
                kappaV = (0.4);               %low baseline=0.6, high baseline=0.6, range=(0,1)
                deltaS = (0.4/(1000*365))/tc;    %=baseline, range = (0.3/(1000*365), 0.6/(1000*365)), human disease-induced death rate, P_DDs
                deltaR = (2*deltaS);                 %2*deltaS; %2 times more likely to die of resistant strain
                gammaS = (1/33)/tc;%sigma               %1/40; %recovery rate (?), (1/365, 1/28), baseline = 1/33
                gammaR = (1/60)/tc;%sigma               %recovery rate (?), P_IrR (P_Ir)
                psiS = (0.6);                 %scaled transmission for Ts individuals
                psiR = (0.6);                 %scaled transmission for Tr individuals
                %phi = 1;                    %scaled transmission for Ts individuals being infected by Mr mosquitos
                muH = (4.43e-5)/tc;              %= baseline, range = (4.25,4.791)*10^(-5), human natural death rate, P_ND
                muV = (1/14)/tc;                 %= baseline, range = (1/21, 1/7)
                omegaS = (1/28)/tc;              %1/28;%1/370; %loss of immunity rate, P_IsS, P_RsS %1/328
                omegaR = (1/28)/tc;             %1/400; loss of immunity rate, P_IrS, P_RrS
                LambdaH0 = (muH*Nh0);         %1.55e3;%3.55e3;%muH*Nh0;%3.55; %baseline value = 3.55e3, value range = (2.24*10^3, 5.08*10^3)
                %LambdaV0 = 1*(LambdaH0/muH)/muV; %high baseline = 3*Nh/muV, low baseline =1*Nh/muV, range = (1-10)*Nh/muV
                %LambdaV0 = 200*LambdaH0;
                LambdaV0 = (Nv0*muV);         %1*Nh0/muV; %assume for now that we are at equilibrium

            case 'test'
                
                Nh0 = 35e6;     %Sh0 + Is0 + Ir0 + Ts0 + Tr0 + Rs0 + Rr0;
                Nv0 = 3*Nh0;    %5*Nh0;
                
                Sh0 = 0.70*Nh0;  %high EE = 0.35*Nh0;      %low DFE = 0.8*Nh0;     %0.605*Nh0; 53% + 7.5% of Nh from paper;   %1000;
                Is0 = 0.13*Nh0;  %high EE = 0.25*Nh0;      %low DFE = 0.1*Nh0;     %0.16*Nh0; 10% + 5% + 1% of Nh from paper; %40
                Ir0 = 0.07*Nh0;  %10;
                Ts0 = 0;
                Tr0 = 0;
                Rs0 = 0.07*Nh0;  %high EE = 0.40*Nh0;      %low DFE = 0.1*Nh0;     %0.3*Nh0; % 30% of Nh from paper
                Rr0 = 0.03*Nh0;
                
                Sv0 = 0.90*Nv0;     %0.9*Nv0;
                Ms0 = 0.07*Nv0;     %0.07*Nv0;
                Mr0 = 0.03*Nv0;     %0.03*Nv0;
                
                ShIsIrTsTrRsRrSvMsMr0 = [Sh0, Is0, Ir0, Ts0, Tr0, Rs0, Rr0, Sv0, Ms0, Mr0];
                
                
                %% Parameters
                a = (0.05)/tc;                   %baseline = 0.05, range = (0.01 juvenile,0.05 adult), treatment/onset of symptoms rate, P_IsT
                alphaS = (1/5)/tc;               % = baseline treated recovery rate, P_TsR (P_Ts), (1/3, 1/10)
                alphaR = (1/10)/tc;              % = high baseline treated recovery rate, P_TrR (P_Tr), (1/3, 1/10)
                betaH = 1.25*(0.1251)/tc;   %high EE = 0.1251;      %low DFE = 0.02     %transmission rate, %0.1251 = low baseline, high baseline=0.5561, range =(0.18, 0.9)
                betaV = 1.25*(0.0313)/tc;   %high EE = 0.0313;      %low DFE = 0.01;    %low baseline=0.313, high baseline=0.0927, range =(0.03, 0.2)
                kappaH = (0.8); %1; %(0.6);               %low baseline=0.6, high baseline=0.6, range=(0,1)
                kappaV = (0.4); %1; %(0.4);               %low baseline=0.6, high baseline=0.6, range=(0,1)
                deltaS = (0.4/(1000*365))/tc;    %=baseline, range = (0.3/(1000*365), 0.6/(1000*365)), human disease-induced death rate, P_DDs
                deltaR = (2*deltaS);                 %2*deltaS; %2 times more likely to die of resistant strain
                gammaS = (1/33)/tc;%sigma               %1/40; %recovery rate (?), (1/365, 1/28), baseline = 1/33
                gammaR = (1/60)/tc;%sigma               %recovery rate (?), P_IrR (P_Ir)
                psiS = (0.6);                 %scaled transmission for Ts individuals
                psiR = (0.6);                 %scaled transmission for Tr individuals
                %phi = 1;                    %scaled transmission for Ts individuals being infected by Mr mosquitos
                muH = (4.43e-5)/tc;              %= baseline, range = (4.25,4.791)*10^(-5), human natural death rate, P_ND
                muV = (1/14)/tc;                 %= baseline, range = (1/21, 1/7)
                omegaS = (1/28)/tc;              %1/28;%1/370; %loss of immunity rate, P_IsS, P_RsS %1/328
                omegaR = (1/28)/tc;             %1/400; loss of immunity rate, P_IrS, P_RrS
                LambdaH0 = (muH*Nh0);         %1.55e3;%3.55e3;%muH*Nh0;%3.55; %baseline value = 3.55e3, value range = (2.24*10^3, 5.08*10^3)
                %LambdaV0 = 1*(LambdaH0/muH)/muV; %high baseline = 3*Nh/muV, low baseline =1*Nh/muV, range = (1-10)*Nh/muV
                %LambdaV0 = 200*LambdaH0;
                LambdaV0 = (Nv0*muV);         %1*Nh0/muV; %assume for now that we are at equilibrium
                
                
        end
end


%% choose distributions and shapes: 'exponential' (shape=1) or 'gamma' (shape>1, integer), 'gamma_fractional' (shape non-integer
switch distributions
    
    case 'EXP'
        
        PIs_distr = 'exponential';
        PIs_mean = gammaS;%sigma 
        PIs_shape = 1;
        
        PIsTs_distr = 'exponential';
        PIsTs_mean = a;
        PIsTs_shape = 1;
        
        PIr_distr = 'exponential';
        PIr_mean = gammaR;%sigma 
        PIr_shape = 1;
        
        PIrTr_distr = 'exponential';
        PIrTr_mean = a;
        PIrTr_shape = 1;
        
        PTs_distr = 'exponential';
        PTs_mean = alphaS;
        PTs_shape = 1;
        
        PTr_distr = 'exponential';
        PTr_mean = alphaR;
        PTr_shape = 1;
        
        PRs_distr = 'exponential';
        PRs_mean = omegaS;
        PRs_shape = 1;
        
        PRr_distr = 'exponential';
        PRr_mean = omegaR;
        PRr_shape = 1;
        
        PND_distr = 'exponential';
        PND_mean = muH;
        PND_shape = 1;
        
        PDDs_distr = 'exponential';
        PDDs_mean = deltaS;
        PDDs_shape = 1;
        
        PDDr_distr = 'exponential';
        PDDr_mean = deltaR;
        PDDr_shape = 1;
        
        PV_distr = 'exponential';
        PV_mean = muV;
        PV_shape = 1;
        
        
    case 'IT3'
        
        PIs_distr = 'exponential';
        PIs_mean = gammaS;%sigma 
        PIs_shape = 1;
        
        PIsTs_distr = 'gamma';
        PIsTs_mean = a;
        PIsTs_shape = 3;
        
        PIr_distr = 'exponential';
        PIr_mean = gammaR;%sigma 
        PIr_shape = 1;
        
        PIrTr_distr = 'gamma';
        PIrTr_mean = a;
        PIrTr_shape = 3;
        
        PTs_distr = 'exponential';
        PTs_mean = alphaS;
        PTs_shape = 1;
        
        PTr_distr = 'exponential';
        PTr_mean = alphaR;
        PTr_shape = 1;
        
        PRs_distr = 'exponential';
        PRs_mean = omegaS;
        PRs_shape = 1;
        
        PRr_distr = 'exponential';
        PRr_mean = omegaR;
        PRr_shape = 1;
        
        PND_distr = 'exponential';
        PND_mean = muH;
        PND_shape = 1;
        
        PDDs_distr = 'exponential';
        PDDs_mean = deltaS;
        PDDs_shape = 1;
        
        PDDr_distr = 'exponential';
        PDDr_mean = deltaR;
        PDDr_shape = 1;
        
        PV_distr = 'exponential';
        PV_mean = muV;
        PV_shape = 1;
        
    case 'IR3'
        
        PIs_distr = 'gamma';
        PIs_mean = gammaS;%sigma 
        PIs_shape = 3;
        
        PIsTs_distr = 'exponential';
        PIsTs_mean = a;
        PIsTs_shape = 1;
        
        PIr_distr = 'gamma';
        PIr_mean = gammaR;%sigma 
        PIr_shape = 3;
        
        PIrTr_distr = 'exponential';
        PIrTr_mean = a;
        PIrTr_shape = 1;
        
        PTs_distr = 'exponential';
        PTs_mean = alphaS;
        PTs_shape = 1;
        
        PTr_distr = 'exponential';
        PTr_mean = alphaR;
        PTr_shape = 1;
        
        PRs_distr = 'exponential';
        PRs_mean = omegaS;
        PRs_shape = 1;
        
        PRr_distr = 'exponential';
        PRr_mean = omegaR;
        PRr_shape = 1;
        
        PND_distr = 'exponential';
        PND_mean = muH;
        PND_shape = 1;
        
        PDDs_distr = 'exponential';
        PDDs_mean = deltaS;
        PDDs_shape = 1;
        
        PDDr_distr = 'exponential';
        PDDr_mean = deltaR;
        PDDr_shape = 1;
        
        PV_distr = 'exponential';
        PV_mean = muV;
        PV_shape = 1;
        
    case 'TR3'
        
        PIs_distr = 'exponential';
        PIs_mean = gammaS;%sigma 
        PIs_shape = 1;
        
        PIsTs_distr = 'exponential';
        PIsTs_mean = a;
        PIsTs_shape = 1;
        
        PIr_distr = 'exponential';
        PIr_mean = gammaR;%sigma 
        PIr_shape = 1;
        
        PIrTr_distr = 'exponential';
        PIrTr_mean = a;
        PIrTr_shape = 1;
        
        PTs_distr = 'gamma';
        PTs_mean = alphaS;
        PTs_shape = 3;
        
        PTr_distr = 'gamma';
        PTr_mean = alphaR;
        PTr_shape = 3;
        
        PRs_distr = 'exponential';
        PRs_mean = omegaS;
        PRs_shape = 1;
        
        PRr_distr = 'exponential';
        PRr_mean = omegaR;
        PRr_shape = 1;
        
        PND_distr = 'exponential';
        PND_mean = muH;
        PND_shape = 1;
        
        PDDs_distr = 'exponential';
        PDDs_mean = deltaS;
        PDDs_shape = 1;
        
        PDDr_distr = 'exponential';
        PDDr_mean = deltaR;
        PDDr_shape = 1;
        
        PV_distr = 'exponential';
        PV_mean = muV;
        PV_shape = 1;
        
    case 'IR3_TR3'
        
        PIs_distr = 'gamma';
        PIs_mean = gammaS;%sigma 
        PIs_shape = 3;
        
        PIsTs_distr = 'exponential';
        PIsTs_mean = a;
        PIsTs_shape = 1;
        
        PIr_distr = 'gamma';
        PIr_mean = gammaR;%sigma 
        PIr_shape = 3;
        
        PIrTr_distr = 'exponential';
        PIrTr_mean = a;
        PIrTr_shape = 1;
        
        PTs_distr = 'gamma';
        PTs_mean = alphaS;
        PTs_shape = 3;
        
        PTr_distr = 'gamma';
        PTr_mean = alphaR;
        PTr_shape = 3;
        
        PRs_distr = 'exponential';
        PRs_mean = omegaS;
        PRs_shape = 1;
        
        PRr_distr = 'exponential';
        PRr_mean = omegaR;
        PRr_shape = 1;
        
        PND_distr = 'exponential';
        PND_mean = muH;
        PND_shape = 1;
        
        PDDs_distr = 'exponential';
        PDDs_mean = deltaS;
        PDDs_shape = 1;
        
        PDDr_distr = 'exponential';
        PDDr_mean = deltaR;
        PDDr_shape = 1;
        
        PV_distr = 'exponential';
        PV_mean = muV;
        PV_shape = 1;
        
    case 'WEIBULL3'
        
        PIs_distr = 'weibull';
        PIs_mean = gammaS;%sigma 
        PIs_shape = 3;
        
        PIsTs_distr = 'weibull';
        PIsTs_mean = a;
        PIsTs_shape = 3;
        
        PIr_distr = 'weibull';
        PIr_mean = gammaR;%sigma 
        PIr_shape = 3;
        
        PIrTr_distr = 'weibull';
        PIrTr_mean = a;
        PIrTr_shape = 3;
        
        PTs_distr = 'weibull';
        PTs_mean = alphaS;
        PTs_shape = 3;
        
        PTr_distr = 'weibull';
        PTr_mean = alphaR;
        PTr_shape = 3;
        
        PRs_distr = 'weibull';
        PRs_mean = omegaS;
        PRs_shape = 3;
        
        PRr_distr = 'weibull';
        PRr_mean = omegaR;
        PRr_shape = 3;
        
        PND_distr = 'weibull';
        PND_mean = muH;
        PND_shape = 3;
        
        PDDs_distr = 'weibull';
        PDDs_mean = deltaS;
        PDDs_shape = 3;
        
        PDDr_distr = 'weibull';
        PDDr_mean = deltaR;
        PDDr_shape = 3;
        
        PV_distr = 'weibull';
        PV_mean = muV;
        PV_shape = 3;
        
    case 'GAMMA3'
        
        PIs_distr = 'gamma';
        PIs_mean = gammaS;%sigma 
        PIs_shape = 3;
        
        PIsTs_distr = 'gamma';
        PIsTs_mean = a;
        PIsTs_shape = 3;
        
        PIr_distr = 'gamma';
        PIr_mean = gammaR;%sigma 
        PIr_shape = 3;
        
        PIrTr_distr = 'gamma';
        PIrTr_mean = a;
        PIrTr_shape = 3;
        
        PTs_distr = 'gamma';
        PTs_mean = alphaS;
        PTs_shape = 3;
        
        PTr_distr = 'gamma';
        PTr_mean = alphaR;
        PTr_shape = 3;
        
        PRs_distr = 'gamma';
        PRs_mean = omegaS;
        PRs_shape = 3;
        
        PRr_distr = 'gamma';
        PRr_mean = omegaR;
        PRr_shape = 3;
        
        PND_distr = 'gamma';
        PND_mean = muH;
        PND_shape = 3;
        
        PDDs_distr = 'gamma';
        PDDs_mean = deltaS;
        PDDs_shape = 3;
        
        PDDr_distr = 'gamma';
        PDDr_mean = deltaR;
        PDDr_shape = 3;
        
        PV_distr = 'gamma';
        PV_mean = muV;
        PV_shape = 3;
        
    case 'AIM2019'
        
        PIs_distr = 'gamma';
        PIs_mean = gammaS;
        PIs_shape = 6;
        
        PIsTs_distr = 'gamma';
        PIsTs_mean = a;
        PIsTs_shape = 4;
        
        PIr_distr = 'exponential';
        PIr_mean = gammaR;
        PIr_shape = 1;
        
        PIrTr_distr = 'exponential';
        PIrTr_mean = a;
        PIrTr_shape = 1;
        
        PTs_distr = 'gamma';
        PTs_mean = alphaS;
        PTs_shape = 3;
        
        PTr_distr = 'exponential';
        PTr_mean = alphaR;
        PTr_shape = 1;
        
        PRs_distr = 'exponential';
        PRs_mean = omegaS;
        PRs_shape = 1;
        
        PRr_distr = 'exponential';
        PRr_mean = omegaR;
        PRr_shape = 1;
        
        PND_distr = 'exponential';
        PND_mean = muH;
        PND_shape = 1;
        
        PDDs_distr = 'exponential';
        PDDs_mean = deltaS;
        PDDs_shape = 1;
        
        PDDr_distr = 'exponential';
        PDDr_mean = deltaR;
        PDDr_shape = 1;
        
        PV_distr = 'exponential';
        PV_mean = muV;
        PV_shape = 1;
        
    case 'AIM2020'
        
        PIs_distr = 'gamma';
        PIs_mean = gammaS;%sigma 
        PIs_shape = 4;
        
        PIsTs_distr = 'gamma_fractional';
        PIsTs_mean = a;
        PIsTs_shape = 0.7;%0.7;
        
        PIr_distr = 'exponential';
        PIr_mean = gammaR;%sigma 
        PIr_shape = 1;
        
        PIrTr_distr = 'exponential';
        PIrTr_mean = a;
        PIrTr_shape = 1;
        
        PTs_distr = 'gamma_fractional';
        PTs_mean = alphaS;
        PTs_shape = 0.1987;
        
        PTr_distr = 'exponential';
        PTr_mean = alphaR;
        PTr_shape = 1;
        
        PRs_distr = 'exponential';
        PRs_mean = omegaS;
        PRs_shape = 1;
        
        PRr_distr = 'exponential';
        PRr_mean = omegaR;
        PRr_shape = 1;
        
        PND_distr = 'exponential';
        PND_mean = muH;
        PND_shape = 1;
        
        PDDs_distr = 'exponential';
        PDDs_mean = deltaS;
        PDDs_shape = 1;
        
        PDDr_distr = 'exponential';
        PDDr_mean = deltaR;
        PDDr_shape = 1;
        
        PV_distr = 'exponential';
        PV_mean = muV;
        PV_shape = 1;
end



