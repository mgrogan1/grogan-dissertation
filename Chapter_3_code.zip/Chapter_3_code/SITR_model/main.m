%% Third attempt at 2-strain SITR model with mosquito equations (SI) 
%% Infection from Is, Ts, and Rs to Ir
%% Is and Ir model equations contain a single integral
%% Ts and Tr model equations contain a double integral
%% Rs and Rr model equations contain a double and triple integral 
%% Sh model equation contains a double and triple and quadruple integral 
%% Mosquito equations are Sv, Ms, Mr with single integrals
%% Use integral_func to calculate integrals (trapz with left rectangle)

clear
close all

tic %start timer

%% define time vector

t0 = 0;
dt_exp = -2;
dt = 1*10^(dt_exp);
%dt = 0.1;
tf = t0 + 10;
tc = 1/50; %scale time to fit dynamics within desired time 
tspan = t0:dt:tf;

%% choose parameter set

% number of strains: '1', '2'
strain = '2';

% equilibrium type: 
% 'DFE' (disease-free),     'EE' (endemic), 
% 'SSE' (sensitive-strain equilibrium), 'RSE' (resistant-strain equilibrium), 
% 'SSE_R' (SSE add R, R dies out),  'RSE_S' (RSE invaded by S, coexistence)
% 'coexistence'
% 'AIM2020_params', 'test'
equilibrium = 'DFE';

% distribution type: 
% 'EXP', 
% 'IT3', 'IR3', 'TR3', 
% 'IR3_TR3', 'GAMMA3', 'WEIBULL3',
% 'AIM2019', 'AIM2020'
distributions = 'EXP';

%% 1. load parameters, distributions, initial conditions

load_params_distr_initials;

%% name data 

name = strcat('test3_density_',strain, sprintf('strain_dt_%d_tf_%d_', dt_exp,tf),...
    equilibrium,'_',distributions);
 
%% 2. Compare with ODE

compute_ODE;
%plot(t/tc, z(:,1:7))
%legend('$S_h$', '$I_s$', '$I_r$', '$T_s$', '$T_r$', '$R_s$', '$R_r$','Interpreter','latex','fontsize',15, 'Location','northeast')


%% 3. load survival func's, their deriv's, and eval's at all timepoints 

load_survival_func_2strains;

%% 4. intialize Sh, Is, Ir, Ts, Tr, Rs, Rr, Sv, Ms, Mr storage 

initialize_storage;

%% 5. calculate Sh, Is, Ir, Ts, Tr, Rs, Rr, Sv, Ms, Mr at second timepoint 
%special case for trapz (j=1)

calculate_second_timepoint;

%% 6. calculate Sh, Is, Ir, Ts, Tr, Rs, Rr, Sv, Ms, Mr at next timepoints 
% all other cases for trapz (j>1) 
% outer loop, j, calculates Sh, Is, Ir, Ts, Tr, Rs, Rr, Sv, Ms, Mr at t_j+1

calculate_other_timepoints;

%% 7. calculate reproduction and invasion numbers
% compute reproduction and invasion numbers

compute_R_invasion_nums;

%% 8. plot 

plot_data;
%plot_data_pretty_1strain
%plot_data_pretty_2strain

%% 9. save data and figure

save_data_figures;

toc % strop timer
