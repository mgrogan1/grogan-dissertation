%% calculate Sh, Is, Ir, Ts, Tr, Rs, Rr, Sv, Ms, Mr at next timepoints - all other cases for trapz (j>1) 
% outer loop, j, calculates Sh, Is, Ir, Ts, Tr, Rs, Rr, Sv, Ms, Mr at t_j+1

for j=2:length(tspan)-1
    
    % track progress of code
    if mod(j,(length(tspan)-1)/100) == 0
        disp(j/(length(tspan)-1))
    end
    
    %% birth rates (constant set in parameters, but can change here if desired)
    
    % birth rate for constant population human
    %LambdaH(j) = muH*Nht(j) + deltaS*(Ist(j) + Tst(j)) + deltaR*(Irt(j) + Trt(j));
    
    % birth rate for constant population vector
    %LambdaV(j) = muV*Nvt(j);
    
    
    %% forces of infection
    
    % nonconstant s-force of infection human
    lambdaS(j) = betaH*Mst(j)/Nht(j);
    
    % nonconstant r-force of infection humans
    lambdaR(j) = kappaH*betaH*Mrt(j)/Nht(j);
    
    % nonconstant s-force of infection vector
    upsilonS(j) = betaV*(Ist(j)+psiS*Tst(j))/Nht(j);

    % nonconstant r-force of infection vector 
    upsilonR(j) = kappaV*betaV*(Irt(j)+psiR*Trt(j))/Nht(j);
    
    %% transmission terms
    
    % s-transmission from S 
    lambdaS_Sht(j) = lambdaS(j)*Sht(j);
    
    % r-transmission from S
    lambdaR_Sht(j) = lambdaR(j)*Sht(j);
    
    % r-transmission from Is
    lambdaR_Ist(j) = lambdaR(j)*Ist(j);
    
    % r-transmission from Ts (scaled)
    lambdaR_Tst(j) = lambdaR(j)*Tst(j);
    
    % r-transmission from Rs
    lambdaR_Rst(j) = lambdaR(j)*Rst(j);
    
    % s-transmission from Sv
    upsilonS_Svt(j) = upsilonS(j)*Svt(j);

    % r-transmission from Sv
    upsilonR_Svt(j) = upsilonR(j)*Svt(j);
    
    
    %% flux terms (Sv, I, M)

    % transmission for Is, S s-infections minus r-infection
    flux_Is(j) = lambdaS_Sht(j) - lambdaR_Ist(j);
    
    % transmission for Ir, S r-infections plus Is r-infections
    flux_Ir(j) = lambdaR_Sht(j) + lambdaR_Ist(j) + lambdaR_Tst(j) + lambdaR_Rst(j);
    
    % birth - transmission for Sv
    flux_Sv(j) = LambdaV(j) - upsilonS_Svt(j) - upsilonR_Svt(j);
    
    % transmission for Ms
    flux_Ms(j) = upsilonS_Svt(j);
    
    % transmission for Mr
    flux_Mr(j) = upsilonR_Svt(j);
    
    
    %% other flux terms (Sh)
    
    % Sh flux w/out recovery terms = birth - transmission for Sh = LambdaH -
    % lambdaS*Sht - lambdaR*Sht
    flux_Sh_noR(j) = LambdaH(j) - lambdaS_Sht(j) - lambdaR_Sht(j);
    
    
    %% calculate fluxes and movements (Sh, T, R)
    
    for k = 2:j

        % calculate Is to Ts movement from 0 to u
        flux_Is_dQ_Ts(1:k) = flux_Is(1:k).*flip(PIs_dPIsTs_PND_PDDs(1:k))';
        
        % calculate Ir to Tr movement from 0 to u
        flux_Ir_dQ_Tr(1:k) = flux_Ir(1:k).*flip(PIr_dPIrTr_PND_PDDr(1:k))';

        % integrate Is to Ts movement from 0 to u
        int_flux_Is_dQ_Ts(k) = trapz(tspan(1:k), flux_Is_dQ_Ts(1:k));
        
        % integrate Ir to Tr movement from 0 to u
        int_flux_Ir_dQ_Tr(k) = trapz(tspan(1:k), flux_Ir_dQ_Tr(1:k));
        
        % calculate Is to Rs movement from 0 to u
        flux_Is_dQ_Rs(1:k) = flux_Is(1:k).*flip(dPIs_PIsTs_PND_PDDs(1:k))';
        
        % calculate Ir to Rr movement from 0 to u
        flux_Ir_dQ_Rr(1:k) = flux_Ir(1:k).*flip(dPIr_PIrTr_PND_PDDr(1:k))';

        % integrate Is to Rs movement from 0 to u
        int_flux_Is_dQ_Rs(k) = trapz(tspan(1:k), flux_Is_dQ_Rs(1:k));
        
        % integrate Ir to Rr movement from 0 to u
        int_flux_Ir_dQ_Rr(k) = trapz(tspan(1:k), flux_Ir_dQ_Rr(1:k));
        
        if k==j
            
            % flux of Ts at t_j
            flux_Ts(k) = int_flux_Is_dQ_Ts(k) + Is0_PIs_dPIsTs_PND_PDDs(k) - lambdaR_Tst(k);
            
            % flux of Tr at t_j
            flux_Tr(k) = int_flux_Ir_dQ_Tr(k) + Ir0_PIr_dPIrTr_PND_PDDr(k);
            
        end
        
        % calculate Ts to Rs movement from 0 to u
        flux_Ts_dQ_Rs(1:k) = flux_Ts(1:k).*flip(dPTs_PND_PDDs(1:k))';
        
        % calculate Tr to Rr movement from 0 to u
        flux_Tr_dQ_Rr(1:k) = flux_Tr(1:k).*flip(dPTr_PND_PDDr(1:k))';
        
        % integrate Ts to Rs movement from 0 to u
        int_flux_Ts_dQ_Rs(k) = trapz(tspan(1:k), flux_Ts_dQ_Rs(1:k));
        
        % integrate Tr to Rr movement from 0 to u
        int_flux_Tr_dQ_Rr(k) = trapz(tspan(1:k), flux_Tr_dQ_Rr(1:k));
        
        if k==j
            
            % flux of Rs at t_j
            flux_Rs(k) = int_flux_Is_dQ_Rs(k) + Is0_dPIs_PIsTs_PND_PDDs(k)...
                 + int_flux_Ts_dQ_Rs(k) + Ts0_dPTs_PND_PDDs(k)...
                 - lambdaR_Rst(k);
        
            % flux of Rr at t_j
            flux_Rr(k) = int_flux_Ir_dQ_Rr(k) + Ir0_dPIr_PIrTr_PND_PDDr(k)...
                + int_flux_Tr_dQ_Rr(k) + Tr0_dPTr_PND_PDDr(k);
        
        end

        % calculate Rs to Sh movement from 0 to u
        flux_Rs_dQ_Sh(1:k) = flux_Rs(1:k).*flip(dPRs_PND(1:k))';
        
        % calculate Rr to Sh movement from 0 to u
        flux_Rr_dQ_Sh(1:k) = flux_Rr(1:k).*flip(dPRr_PND(1:k))';
        
        % integrate Rs to Sh movement from 0 to u
        int_flux_Rs_dQ_Sh(k) = trapz(tspan(1:k), flux_Rs_dQ_Sh(1:k));
        
        % integrate Rr to Sh movement from 0 to u
        int_flux_Rr_dQ_Sh(k) = trapz(tspan(1:k), flux_Rr_dQ_Sh(1:k));
        
    end
    
    % flux of Sh from 0 to t_j
    flux_Sh(1:j) = flux_Sh_noR(1:j) ...
        + int_flux_Rs_dQ_Sh(1:j) + Rs0_dPRs_PND(1:j)' ...
        + int_flux_Rr_dQ_Sh(1:j) + Rr0_dPRr_PND(1:j)';
    
    %% multiply fluxes by survivals from 0 to t_j
    
    % multiply Sh flux by survivals from 0 to t_j
    flux_Sh_Q(1:j) = flux_Sh(1:j).*flip(PND(2:j+1))';

    % multiply Is flux by survivals from 0 to t_j
    flux_Is_Q(1:j) = flux_Is(1:j).*flip(PIs_PIsTs_PND_PDDs(2:j+1))';
    
    % multiply Ir flux by survivals from 0 to t_j
    flux_Ir_Q(1:j) = flux_Ir(1:j).*flip(PIr_PIrTr_PND_PDDr(2:j+1))';

    % multiply Ts flux by survivals from 0 to t_j
    flux_Ts_Q(1:j) = flux_Ts(1:j).*flip(PTs_PND_PDDs(2:j+1))';
    
    % multiply Tr flux by survivals from 0 to t_j
    flux_Tr_Q(1:j) = flux_Tr(1:j).*flip(PTr_PND_PDDr(2:j+1))';
    
    % multiply Rs flux by survivals from 0 to t_j
    flux_Rs_Q(1:j) = flux_Rs(1:j).*flip(PRs_PND(2:j+1))';
    
    % multiply Rr flux by survivals from 0 to t_j
    flux_Rr_Q(1:j) = flux_Rr(1:j).*flip(PRr_PND(2:j+1))';
    
    %% calculate humans Sh, Is, Ir, Ts, Tr, Rs, Rr at jth timepoint
    
    % calculate next Sh (integrate flux_Q, add initial S population)
    Sht(j+1) = integral_func(j, flux_Sh_Q(1:j), tspan(1:j), dt) + Sh0_PND(j+1);

    % calculate next Is (integrate flux_Q, add initial Is population)
    Ist(j+1) = integral_func(j, flux_Is_Q(1:j), tspan(1:j), dt) + Is0_PIs_PIsTs_PND_PDDs(j+1);
    
    % calculate next Ir (integrate flux_Q, add initial Ir population)
    Irt(j+1) = integral_func(j, flux_Ir_Q(1:j), tspan(1:j), dt) + Ir0_PIr_PIrTr_PND_PDDr(j+1);

    % calculate next Ts (integrate flux_Q, add initial Rs population)
    Tst(j+1) = integral_func(j, flux_Ts_Q(1:j), tspan(1:j), dt) + Ts0_PTs_PND_PDDs(j+1);
    
    % calculate next Tr (integrate flux_Q, add initial Rs population)
    Trt(j+1) = integral_func(j, flux_Tr_Q(1:j), tspan(1:j), dt) + Tr0_PTr_PND_PDDr(j+1);
    
    % calculate next Rs (integrate flux_Q, add initial Rs population)
    Rst(j+1) = integral_func(j, flux_Rs_Q(1:j), tspan(1:j), dt) + Rs0_PRs_PND(j+1);
    
    % calculate next Rr (integrate flux_Q, add initial Rs population)
    Rrt(j+1) = integral_func(j, flux_Rr_Q(1:j), tspan(1:j), dt) + Rr0_PRr_PND(j+1);
    
    %% calculate vectors Sv, Ms, Mr at jth timepoint
    
    % calculate next Sv 
    flux_Sv_Q(1:j) = flux_Sv(1:j).*flip(PV(2:j+1))';
    Svt(j+1) = integral_func(j, flux_Sv_Q(1:j), tspan(1:j), dt) + Sv0_PV(j+1);

    % calculate next Ms
    flux_Ms_Q(1:j) = flux_Ms(1:j).*flip(PV(2:j+1))';
    Mst(j+1) = integral_func(j, flux_Ms_Q(1:j), tspan(1:j), dt) + Ms0_PV(j+1);

    % calculate next Mr 
    flux_Mr_Q(1:j) = flux_Mr(1:j).*flip(PV(2:j+1))';
    Mrt(j+1) = integral_func(j, flux_Mr_Q(1:j), tspan(1:j), dt) + Mr0_PV(j+1);
    
    %% calculate total populations
    
    % calculate human population
    Nht(j+1) = Sht(j+1)+Ist(j+1)+Irt(j+1)+Tst(j+1)+Trt(j+1)+Rst(j+1)+Rrt(j+1);

    % calculate vector population
    Nvt(j+1) = Svt(j+1)+Mst(j+1)+Mrt(j+1);
    
end
