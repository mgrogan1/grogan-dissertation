
%tic %start timer

%Sv'Ms'Mr'Sh'Is'Ir'Tsk'Trk'Rs'Rr'

format long
close all
clear

% load data
load('Data/test3_2strain_dt_-2_tf_10_DFE_EXP.mat');

% choose tf

start_t = 1;%20/dt + 1;
end_t = (tf-t0)/dt;
marker_dt = floor(end_t/20);

interesting_t = t(start_t:end_t)/tc;

% choose colormap
%colors=colormap(cool(15));
%colors=colormap(prism(6));
colors=colormap(hsv(15));
        
%% plot 

subplot(1,2,1)
hold on

%susceptible H
%p(1) = plot(interesting_t,Sht(start_t:end_t,1),'linewidth',2);
%p(1).Color=colors(11,:);

%s-infected H
p(2) = plot(interesting_t,Ist(start_t:end_t,1),'linewidth',2);
p(2).Color=colors(1,:);

%r-infected H
p(3) = plot(interesting_t,Irt(start_t:end_t,1),'--','linewidth',2);
p(3).Color=colors(1,:);

%s-treated H
p(4) = plot(interesting_t,Tst(start_t:end_t,1),'linewidth',2);
p(4).Color=colors(13,:);

%r-treated H
p(5) = plot(interesting_t,Trt(start_t:end_t,1),':','linewidth',2);
p(5).Color=colors(13,:);

%s-recovered H
p(6) = plot(interesting_t,Rst(start_t:end_t,1),'linewidth',2);
p(6).Color=colors(9,:);

%r-recovered H
p(7) = plot(interesting_t,Rrt(start_t:end_t,1),'-^','MarkerIndices',1:marker_dt:length(interesting_t),'linewidth',2);
p(7).Color=colors(9,:);

%legend & labels
%legend('$S_h$', '$I_s$', '$I_r$', '$T_s$', '$T_r$', '$R_s$', '$R_r$','Interpreter','latex','fontsize',15, 'Location','northeast')
legend('$I_s$', '$I_r$', '$T_s$', '$T_r$', '$R_s$', '$R_r$','Interpreter','latex','fontsize',15, 'Location','northeast')
title(sprintf('Host'),'fontsize',15)
xlabel('time (days)','fontsize',15)
ylabel('population size','fontsize', 15)
xlim([start_t*dt,end_t*dt/tc])

subplot(1,2,2)
hold on

%susceptible V
%p(8) = plot(interesting_t,Svt(start_t:end_t,1),'linewidth',2);
%p(8).Color=colors(11,:);

%s-infected V
p(9) = plot(interesting_t,Mst(start_t:end_t,1),'linewidth',2);
p(9).Color=colors(1,:);

%r-infected V
p(10) = plot(interesting_t,Mrt(start_t:end_t,1),'--','linewidth',2);
p(10).Color=colors(1,:);

%legend & labels
%legend('$S_v$', '$M_s$', '$M_r$','Interpreter','latex','fontsize',15, 'Location','northeast')
legend('$M_s$', '$M_r$','Interpreter','latex','fontsize',15, 'Location','northeast')
title(sprintf('Vector'),'fontsize',15)
xlabel('time (days)','fontsize',15)
ylabel('population size','fontsize', 15)
xlim([start_t*dt,end_t*dt/tc])

% main title
%sgtitle(strcat('\bf{Model Simulation ( }$',equilibrium, '$--', distributions,'{ )}'),'fontsize',20, 'interpreter', 'latex')
sgtitle(strcat('\bf{Model Simulation ( }',equilibrium, '--', distributions,'{ )}'),'fontsize',20, 'interpreter', 'latex')


%% names

%data name
dataname_pretty= strcat(name, '_pretty', '.mat');

%figure name 
figname_petty = strcat(name,'_pretty','.fig');
figname_pretty_JPG = strcat(name,'_pretty','.jpg');

%% save data

save([pwd strcat('/Data/',dataname_pretty)]);

%% save figures 

%save figures in .fig and .jpg 
savefig(figure(1), [pwd strcat('/FiguresFIG/',figname_petty)]);
saveas(figure(1), [pwd strcat('/FiguresJPG/',figname_pretty_JPG)]);

%toc %stop timer