%% intialize Sh, Is, Ir, Ts, Tr, Rs, Rr, Sv, Ms, Mr storage 
% (each entry defined for a fixed t)

Sht = zeros(length(tspan),1);
Ist = zeros(length(tspan),1);
Irt = zeros(length(tspan),1);
Tst = zeros(length(tspan),1);
Trt = zeros(length(tspan),1);
Rst = zeros(length(tspan),1);
Rrt = zeros(length(tspan),1);
Svt = zeros(length(tspan),1);
Mst = zeros(length(tspan),1);
Mrt = zeros(length(tspan),1);
Nht = zeros(length(tspan),1);
Nvt = zeros(length(tspan),1);

%% add initial conditions to Sh, Is, Ir, Ts, Tr, Rs, Rr, Sv, Ms, Mr storage

Sht(1) = Sh0;
Ist(1) = Is0;
Irt(1) = Ir0;
Tst(1) = Ts0;
Trt(1) = Tr0;
Rst(1) = Rs0;
Rrt(1) = Rr0;
Svt(1) = Sv0;
Mst(1) = Ms0;
Mrt(1) = Mr0;
Nht(1) = Nh0;
Nvt(1) = Nv0;

%% initialize important quantities 

%% birth rates

% birth rate for constant human population
LambdaH = LambdaH0*ones(length(tspan), 1);

% birth rate for constant vector population
LambdaV = LambdaV0*ones(length(tspan), 1);

%% forces of infection

% force of s-infection humans
lambdaS = zeros(length(tspan), 1);

% force of r-infection humans
lambdaR = zeros(length(tspan), 1);

% force of s-infection vectors
upsilonS = zeros(length(tspan), 1);

% force of r-infection vectors
upsilonR = zeros(length(tspan), 1);

%% transmission terms

% s transmission = lambdaS*St from Sh
lambdaS_Sht = zeros(length(tspan),1);

% r transmission = lambdaR*St from Sh
lambdaR_Sht = zeros(length(tspan),1);

% r-transmission = lambdaR*Ist from Is
lambdaR_Ist = zeros(length(tspan),1);

% r-transmission = lambdaR*Tst from Ts
lambdaR_Tst = zeros(length(tspan),1);

% r-transmission = lambdaR*Rst from Rs
lambdaR_Rst = zeros(length(tspan),1);

% s-transmission from Sv
upsilonS_Svt = zeros(length(tspan),1);

% r-transmission from Sv
upsilonR_Svt = zeros(length(tspan),1);

%% flux terms

% Sh
flux_Sh = zeros(length(tspan), 1);

% Is
flux_Is = zeros(length(tspan), 1);

% Ts
flux_Ts = zeros(length(tspan), 1);

% Rs
flux_Rs = zeros(length(tspan), 1);

% Ir
flux_Ir = zeros(length(tspan), 1);

% Tr
flux_Tr = zeros(length(tspan), 1);

% Rr
flux_Rr = zeros(length(tspan), 1);

% Sv
flux_Sv = zeros(length(tspan), 1);

% Ms
flux_Ms = zeros(length(tspan), 1);

% Mr
flux_Mr = zeros(length(tspan), 1);


%% other flux terms 

% Sh flux w/out recovery terms = birth - transmission for Sh = LambdaH -
% lambdaS*Sht - lambdaR*Sht
flux_Sh_noR = zeros(length(tspan), 1);


%% flux terms times survival functions, Q

% Sh
flux_Sh_Q = zeros(length(tspan), 1);

% Is
flux_Is_Q = zeros(length(tspan), 1);

% Ts
flux_Ts_Q = zeros(length(tspan), 1);

% Rs
flux_Rs_Q = zeros(length(tspan), 1);

% Ir
flux_Ir_Q = zeros(length(tspan), 1);

% Tr
flux_Tr_Q = zeros(length(tspan), 1);

% Rr
flux_Rr_Q = zeros(length(tspan), 1);

% Sv
flux_Sv_Q = zeros(length(tspan), 1);

% Ms
flux_Ms_Q = zeros(length(tspan), 1);

% Mr
flux_Mr_Q = zeros(length(tspan), 1);

%% flux terms times survival function derivativs, dQ

% for Is to Ts
flux_Is_dQ_Ts = zeros(length(tspan), 1);

% for Is to Rs
flux_Is_dQ_Rs = zeros(length(tspan), 1);

% for Ts to Rs
flux_Ts_dQ_Rs = zeros(length(tspan), 1);

% for Ir to Tr
flux_Ir_dQ_Tr = zeros(length(tspan), 1);

% for Ir to Rr
flux_Ir_dQ_Rr = zeros(length(tspan), 1);

% for Tr to Rr
flux_Tr_dQ_Rr = zeros(length(tspan), 1);

% for Rs to Sh
flux_Rs_dQ_Sh = zeros(length(tspan), 1);

% for Rr to Sh
flux_Rr_dQ_Sh = zeros(length(tspan), 1);

%% integrated flux_dQ terms

% for Is to Ts
int_flux_Is_dQ_Ts = zeros(length(tspan), 1);

% for Is to Rs
int_flux_Is_dQ_Rs = zeros(length(tspan), 1);

% for Ts to Rs
int_flux_Ts_dQ_Rs = zeros(length(tspan), 1);

% for Ir to Tr
int_flux_Ir_dQ_Tr = zeros(length(tspan), 1);

% for Ir to Rr
int_flux_Ir_dQ_Rr = zeros(length(tspan), 1);

% for Tr to Rr
int_flux_Tr_dQ_Rr = zeros(length(tspan), 1);

% for Rs to Sh
int_flux_Rs_dQ_Sh = zeros(length(tspan), 1);

% for Rr to Sh
int_flux_Rr_dQ_Sh = zeros(length(tspan), 1);
