function dp = Survival_Func_Deriv(distribution, mean, shape, t)

if strcmp(distribution,'exponential')
    
    dp = -mean*exp(-mean*t);
    
elseif strcmp(distribution,'gamma')
    
    dp = ((-shape*mean)*exp(-shape*mean*t)*(shape*mean*t)^(shape-1))/factorial(shape-1);
    
elseif strcmp(distribution,'gamma_fractional')
    
    scale = 1/(mean*shape);
    dp = -gampdf(t,shape,scale);    
    
elseif strcmp(distribution,'weibull')
    
    dp = -(mean*shape)*((mean*t)^(shape-1))*exp(-(t*mean)^shape);
    
elseif strcmp(distribution,'gompertz')
    
    dp = -(mean*shape)*exp(-shape*(exp(mean*t)-1)+mean*t);
    
elseif strcmp(distribution,'log-logistic')
    %
    % we will pass in standdard deviation in as shape
    
    stdd = shape;
    dp = -(1/8)*(stdd^3)*(-2 + cosh(stdd*(t-mean)))*(sech(1/2*stdd*(t-mean)))^4;
    
end

end
