%% plot data

maxt = 1;
timelimit = (length(tspan) - 1)/maxt + 1;

%% Difference between integrals and ODEs

Sh_DIFF = Sht-z(:,1);
Is_DIFF = Ist-z(:,2);
Ir_DIFF = Irt-z(:,3);
Ts_DIFF = Tst-z(:,4);
Tr_DIFF = Trt-z(:,5);
Rs_DIFF = Rst-z(:,6);
Rr_DIFF = Rrt-z(:,7);
Sv_DIFF = Svt-z(:,8);
Ms_DIFF = Mst-z(:,9);
Mr_DIFF = Mrt-z(:,10);

%% Percent Difference between integrals and ODEs
eps = 0.0;
PerSh_DIFF = (Sht-z(:,1))./(abs(z(:,1))+eps)*100;
PerIs_DIFF = (Ist-z(:,2))./(abs(z(:,2))+eps)*100;
PerIr_DIFF = (Irt-z(:,3))./(abs(z(:,3))+eps)*100;
PerTs_DIFF = (Tst-z(:,4))./(abs(z(:,4))+eps)*100;
PerTr_DIFF = (Trt-z(:,5))./(abs(z(:,5))+eps)*100;
PerRs_DIFF = (Rst-z(:,6))./(abs(z(:,6))+eps)*100;
PerRr_DIFF = (Rrt-z(:,7))./(abs(z(:,7))+eps)*100;
PerSv_DIFF = (Svt-z(:,8))./(abs(z(:,8))+eps)*100;
PerMs_DIFF = (Mst-z(:,9))./(abs(z(:,9))+eps)*100;
PerMr_DIFF = (Mrt-z(:,10))./(abs(z(:,10))+eps)*100;

%% Combined values

combinedHUMANS = [Sht;Ist;Irt;Tst;Trt;Rst;Rrt;z(:,1);z(:,2);z(:,3);z(:,4);z(:,5);z(:,6);z(:,7)];
combinedVECTORS = [Svt;Mst;Mrt;z(:,8);z(:,9);z(:,10)];
combinedHUMANS_noS = [Ist;Irt;Tst;Trt;Rst;Rrt;z(:,2);z(:,3);z(:,4);z(:,5);z(:,6);z(:,7)];
combinedVECTORS_noS = [Mst;Mrt;z(:,9);z(:,10)];
%combinedHUMANS_DIFF = [Sh_DIFF;Is_DIFF;Ir_DIFF;Ts_DIFF;Tr_DIFF;Rs_DIFF;Rr_DIFF];
combinedHUMANS_DIFF = [Sh_DIFF(64:end);Is_DIFF(64:end);Ir_DIFF(64:end);Ts_DIFF(64:end);Tr_DIFF(64:end);Rs_DIFF(64:end);Rr_DIFF(64:end)];
combinedVECTORS_DIFF = [Sv_DIFF;Ms_DIFF;Mr_DIFF];
%PERcombinedHUMANS_DIFF = [PerSh_DIFF;PerIs_DIFF;PerIr_DIFF;PerTs_DIFF;PerTr_DIFF;PerRs_DIFF;PerRr_DIFF];
PERcombinedHUMANS_DIFF = [PerSh_DIFF(64:end);PerIs_DIFF(64:end);PerIr_DIFF(64:end);PerTs_DIFF(64:end);PerTr_DIFF(64:end);PerRs_DIFF(64:end);PerRr_DIFF(64:end)];
PERcombinedVECTORS_DIFF = [PerSv_DIFF;PerMs_DIFF;PerMr_DIFF];

%% Mins/Maxs/Percents

minOUTPUTh = min(combinedHUMANS_noS);
maxOUTPUTh = max(combinedHUMANS_noS);
minOUTPUTv = min(combinedVECTORS_noS);
maxOUTPUTv = max(combinedVECTORS_noS);
min_DIFFh = min(combinedHUMANS_DIFF);
max_DIFFh = max(combinedHUMANS_DIFF);
min_DIFFv = min(combinedVECTORS_DIFF);
max_DIFFv = max(combinedVECTORS_DIFF);
PERmin_DIFFh = min(PERcombinedHUMANS_DIFF);
PERmax_DIFFh = max(PERcombinedHUMANS_DIFF);
PERmin_DIFFv = min(PERcombinedVECTORS_DIFF);
PERmax_DIFFv = max(PERcombinedVECTORS_DIFF);

%% choose to plot difference or percent difference:
    
ShtDIFF = Sh_DIFF;
IstDIFF = Is_DIFF;
IrtDIFF = Ir_DIFF;
TstDIFF = Ts_DIFF;
TrtDIFF = Tr_DIFF;
RstDIFF = Rs_DIFF;
RrtDIFF = Rr_DIFF;
SvtDIFF = Sv_DIFF;
MstDIFF = Ms_DIFF;
MrtDIFF = Mr_DIFF;

minDIFFh = min_DIFFh;
maxDIFFh = max_DIFFh;
minDIFFv = min_DIFFv;
maxDIFFv = max_DIFFv;

PerShtDIFF = PerSh_DIFF;
PerIstDIFF = PerIs_DIFF;
PerIrtDIFF = PerIr_DIFF;
PerTstDIFF = PerTs_DIFF;
PerTrtDIFF = PerTr_DIFF;
PerRstDIFF = PerRs_DIFF;
PerRrtDIFF = PerRr_DIFF;
PerSvtDIFF = PerSv_DIFF;
PerMstDIFF = PerMs_DIFF;
PerMrtDIFF = PerMr_DIFF;

PERminDIFFh = PERmin_DIFFh;
PERmaxDIFFh = PERmax_DIFFh;
PERminDIFFv = PERmin_DIFFv;
PERmaxDIFFv = PERmax_DIFFv;

%% HUMANS

figure('Name',strcat(name,'_H'),'NumberTitle','off')

%Sh Integral
subplot(3,7,1)
plot(tspan(1:timelimit)'/tc, Sht(1:timelimit), 'LineWidth',2)
%title('Sh Integral')
title('$S_h$', 'Interpreter','latex','fontsize',20)
ylabel('Integral Solutions', 'fontsize',15)
axis([t0, (tf/tc)/maxt, min([Sht(1:timelimit);z(1:timelimit,1)]), max([Sht(1:timelimit);z(1:timelimit,1)])])

%Is Integral
subplot(3,7,2)
plot(tspan(1:timelimit)'/tc, Ist(1:timelimit), 'LineWidth',2)
title('$I_s$', 'Interpreter','latex', 'fontsize',20)
axis([t0, (tf/tc)/maxt, minOUTPUTh, maxOUTPUTh])

%Ir Integral
subplot(3,7,3)
plot(tspan(1:timelimit)'/tc, Irt(1:timelimit), 'LineWidth',2)
title('$I_r$', 'Interpreter','latex', 'fontsize',20)
axis([t0, (tf/tc)/maxt, minOUTPUTh, maxOUTPUTh])

%Ts Integral
subplot(3,7,4)
plot(tspan(1:timelimit)'/tc, Tst(1:timelimit), 'LineWidth',2)
title('$T_s$', 'Interpreter','latex', 'fontsize',20)
axis([t0, (tf/tc)/maxt, minOUTPUTh, maxOUTPUTh])

%Tr Integral
subplot(3,7,5)
plot(tspan(1:timelimit)'/tc, Trt(1:timelimit), 'LineWidth',2)
title('$T_r$', 'Interpreter','latex', 'fontsize',20)
axis([t0, (tf/tc)/maxt, minOUTPUTh, maxOUTPUTh])

%Rs Integral
subplot(3,7,6)
plot(tspan(1:timelimit)'/tc, Rst(1:timelimit), 'LineWidth',2)
title('$R_s$', 'Interpreter','latex', 'fontsize',20)
axis([t0, (tf/tc)/maxt, minOUTPUTh, maxOUTPUTh])

%Rr Integral
subplot(3,7,7)
plot(tspan(1:timelimit)'/tc, Rrt(1:timelimit), 'LineWidth',2)
title('$R_r$', 'Interpreter','latex', 'fontsize',20)
axis([t0, (tf/tc)/maxt, minOUTPUTh, maxOUTPUTh])

%Sh ODE
subplot(3,7,8)
plot(t(1:timelimit)/tc, z((1:timelimit),1), 'LineWidth',2)
%title('$S_h$', 'Interpreter','latex')
ylabel('ODE Solutions','fontsize',15)
axis([t0, (tf/tc)/maxt, min([Sht(1:timelimit);z(1:timelimit,1)]), max([Sht(1:timelimit);z(1:timelimit,1)])])

%Is ODE
subplot(3,7,9)
plot(t(1:timelimit)/tc, z((1:timelimit),2), 'LineWidth',2)
%title('$I_s$', 'Interpreter','latex')
axis([t0, (tf/tc)/maxt, minOUTPUTh, maxOUTPUTh])

%Ir ODE
subplot(3,7,10)
plot(t(1:timelimit)/tc, z((1:timelimit),3), 'LineWidth',2)
%title('$I_r$', 'Interpreter','latex')
axis([t0, (tf/tc)/maxt, minOUTPUTh, maxOUTPUTh])

%Ts ODE
subplot(3,7,11)
plot(t(1:timelimit)/tc, z((1:timelimit),4), 'LineWidth',2)
%title('$T_s$', 'Interpreter','latex')
axis([t0, (tf/tc)/maxt, minOUTPUTh, maxOUTPUTh])

%Tr ODE
subplot(3,7,12)
plot(t(1:timelimit)/tc, z((1:timelimit),5), 'LineWidth',2)
%title('$T_r$', 'Interpreter','latex')
axis([t0, (tf/tc)/maxt, minOUTPUTh, maxOUTPUTh])

%Rs ODE
subplot(3,7,13)
plot(t(1:timelimit)/tc, z((1:timelimit),6), 'LineWidth',2)
%title('$R_s$', 'Interpreter','latex')
axis([t0, (tf/tc)/maxt, minOUTPUTh, maxOUTPUTh])

%Rr ODE
subplot(3,7,14)
plot(t(1:timelimit)/tc, z((1:timelimit),7), 'LineWidth',2)
%title('$R_r$', 'Interpreter','latex')
axis([t0, (tf/tc)/maxt, minOUTPUTh, maxOUTPUTh])

% %Sh DIfference
% subplot(4,7,15)
% plot(tspan'/tc, ShtDIFF)
% %title('$S_h$', 'Interpreter','latex')
% axis([t0, tf/tc, minDIFFh, maxDIFFh])
% 
% %Is DIfference
% subplot(4,7,16)
% plot(tspan'/tc, IstDIFF)
% %title('$I_s$', 'Interpreter','latex')
% axis([t0, tf/tc, minDIFFh, maxDIFFh])
% 
% %Ir DIfference
% subplot(4,7,17)
% plot(tspan'/tc, IrtDIFF)
% %title('$I_r$', 'Interpreter','latex')
% axis([t0, tf/tc, minDIFFh, maxDIFFh])
% 
% %Ts DIfference
% subplot(4,7,18)
% plot(tspan'/tc, TstDIFF)
% %title('Ts Diff')
% axis([t0, tf/tc, minDIFFh, maxDIFFh])
% 
% %Tr DIfference
% subplot(4,7,19)
% plot(tspan'/tc, TrtDIFF)
% %title('Tr Diff')
% axis([t0, tf/tc, minDIFFh, maxDIFFh])
% 
% %Rs DIfference
% subplot(4,7,20)
% plot(tspan'/tc, RstDIFF)
% %title('Rs Diff')
% axis([t0, tf/tc, minDIFFh, maxDIFFh])
% 
% %Rr DIfference
% subplot(4,7,21)
% plot(tspan'/tc, RrtDIFF)
% %title('Rr Diff')
% axis([t0, tf/tc, minDIFFh, maxDIFFh])

%Sh % DIfference
subplot(3,7,15)
plot(tspan(1:timelimit)'/tc, PerShtDIFF(1:timelimit), 'LineWidth',2)
%title('Sh \% Diff')
ylabel('\% Difference','fontsize',15)
axis([t0, (tf/tc)/maxt, PERminDIFFh, PERmaxDIFFh])

%Is % DIfference
subplot(3,7,16)
plot(tspan(1:timelimit)'/tc, PerIstDIFF(1:timelimit), 'LineWidth',2)
%title('Is \% Diff')
axis([t0, (tf/tc)/maxt, PERminDIFFh, PERmaxDIFFh])

%Ir % DIfference
subplot(3,7,17)
plot(tspan(1:timelimit)'/tc, PerIrtDIFF(1:timelimit), 'LineWidth',2)
%title('Ir \% Diff')
axis([t0, (tf/tc)/maxt, PERminDIFFh, PERmaxDIFFh])

%Ts % DIfference
subplot(3,7,18)
plot(tspan(1:timelimit)'/tc, PerTstDIFF(1:timelimit), 'LineWidth',2)
%title('Ts \% Diff')
axis([t0, (tf/tc)/maxt, PERminDIFFh, PERmaxDIFFh])

%Tr % DIfference
subplot(3,7,19)
plot(tspan(1:timelimit)'/tc, PerTrtDIFF(1:timelimit), 'LineWidth',2)
%title('Tr \% Diff')
axis([t0, (tf/tc)/maxt, PERminDIFFh, PERmaxDIFFh])

%Rs % DIfference
subplot(3,7,20)
plot(tspan(1:timelimit)'/tc, PerRstDIFF(1:timelimit), 'LineWidth',2)
%title('Rs \% Diff')
axis([t0, (tf/tc)/maxt, PERminDIFFh, PERmaxDIFFh])

%Rr % DIfference
subplot(3,7,21)
plot(tspan(1:timelimit)'/tc, PerRrtDIFF(1:timelimit), 'LineWidth',2)
%title('Rr \% Diff')
axis([t0, (tf/tc)/maxt, PERminDIFFh, PERmaxDIFFh])

%% VECTORS

figure('Name',strcat(name,'_V'),'NumberTitle','off')

%Sv Integral
subplot(3,3,1)
% plot(tspan'/tc, Svt)
% title('Sv Integral')
% axis([t0, tf/tc, minOUTPUTv, maxOUTPUTv])
plot(tspan(1:timelimit)'/tc, Svt(1:timelimit), 'LineWidth',2)
title('$S_v$', 'Interpreter','latex','fontsize',20)
ylabel('Integral Solutions', 'fontsize',12)
axis([t0, (tf/tc)/maxt, min([Svt(1:timelimit);z(1:timelimit,8)]), max([Svt(1:timelimit);z(1:timelimit,8)])])


%Ms Integral
subplot(3,3,2)
% plot(tspan'/tc, Mst)
%title('Ms Integral')
% axis([t0, tf/tc, minOUTPUTv, maxOUTPUTv])
plot(tspan(1:timelimit)'/tc, Mst(1:timelimit), 'LineWidth',2)
title('$M_s$', 'Interpreter','latex','fontsize',20)
axis([t0, (tf/tc)/maxt, minOUTPUTv, maxOUTPUTv])

%Mr Integral
subplot(3,3,3)
% plot(tspan'/tc, Mrt)
% title('Mr Integral')
% axis([t0, tf/tc, minOUTPUTv, maxOUTPUTv])
plot(tspan(1:timelimit)'/tc, Mrt(1:timelimit), 'LineWidth',2)
title('$M_r$', 'Interpreter','latex','fontsize',20)
axis([t0, (tf/tc)/maxt, minOUTPUTv, maxOUTPUTv])

%Sv ODE
subplot(3,3,4)
% plot(t/tc, z(:,8))
% title('Sv ODE')
% axis([t0, tf/tc, minOUTPUTv, maxOUTPUTv])
plot(tspan(1:timelimit)'/tc, z(1:timelimit,8), 'LineWidth',2)
%title('$S_v$', 'Interpreter','latex','fontsize',20)
ylabel('ODE Solutions', 'fontsize',12)
axis([t0, (tf/tc)/maxt, min([Svt(1:timelimit);z(1:timelimit,8)]), max([Svt(1:timelimit);z(1:timelimit,8)])])


%Ms ODE
subplot(3,3,5)
plot(t/tc, z(:,9))
% title('Ms ODE')
% axis([t0, tf/tc, minOUTPUTv, maxOUTPUTv])
plot(tspan(1:timelimit)'/tc, z(1:timelimit,9), 'LineWidth',2)
%title('$M_s$', 'Interpreter','latex','fontsize',20)
axis([t0, (tf/tc)/maxt, minOUTPUTv, maxOUTPUTv])


%Mr ODE
subplot(3,3,6)
% plot(t/tc, z(:,10))
% title('Mr ODE')
% axis([t0, tf/tc, minOUTPUTv, maxOUTPUTv])
plot(tspan(1:timelimit)'/tc, z(1:timelimit,10), 'LineWidth',2)
%title('$M_r$', 'Interpreter','latex','fontsize',20)
axis([t0, (tf/tc)/maxt, minOUTPUTv, maxOUTPUTv])


% %Sv Difference
% subplot(4,3,7)
% plot(tspan'/tc, SvtDIFF)
% title('Sv Diff')
% axis([t0, tf/tc, minDIFFv, maxDIFFv])
% 
% %Ms Difference
% subplot(4,3,8)
% plot(tspan'/tc, MstDIFF)
% title('Ms Diff')
% axis([t0, tf/tc, minDIFFv, maxDIFFv])
% 
% %Mr Difference
% subplot(4,3,9)
% plot(tspan'/tc, MrtDIFF)
% title('Mr Diff')
% axis([t0, tf/tc, minDIFFv, maxDIFFv])

%Sv Percent Difference
subplot(3,3,7)
% plot(tspan'/tc, PerSvtDIFF)
% title('Sv \% Diff')
% axis([t0, tf/tc, PERminDIFFv, PERmaxDIFFv])
plot(tspan(1:timelimit)'/tc, PerSvtDIFF(1:timelimit), 'LineWidth',2)
%title('Sh \% Diff')
ylabel('\% Difference','fontsize',12)
axis([t0, (tf/tc)/maxt, PERminDIFFv, PERmaxDIFFv])

%Ms Percent Difference
subplot(3,3,8)
% plot(tspan'/tc, PerMstDIFF)
% title('Ms \% Diff')
% axis([t0, tf/tc, PERminDIFFv, PERmaxDIFFv])
plot(tspan(1:timelimit)'/tc, PerMstDIFF(1:timelimit), 'LineWidth',2)
%title('Ms \% Diff')
axis([t0, (tf/tc)/maxt, PERminDIFFv, PERmaxDIFFv])


%Mr Percent Difference
subplot(3,3,9)
% plot(tspan'/tc, PerMrtDIFF)
% title('Mr \% Diff')
% axis([t0, tf/tc, PERminDIFFv, PERmaxDIFFv])
plot(tspan(1:timelimit)'/tc, PerMrtDIFF(1:timelimit), 'LineWidth',2)
%title('Mr \% Diff')
axis([t0, (tf/tc)/maxt, PERminDIFFv, PERmaxDIFFv])
