%% This is an outline for the code to compute and simulate the 2-strain
%% SITR integral equation model for vector-borne diseases. 

%% main.m
% Main file to run the code 
% Defines desired time-vector, parameter sets, and distributions
% Calls the following files in this order:
%   1. load_params_distr_initials;
%   2. compute_ODE;
%   3. load_survival_func_2strains;
%   4. initialize_storage;
%   5. calculate_second_timepoint;
%   6. calculate_other_timepoints;
%   7. compute_R_invasion_nums;
%   8. plot_data;
%   9. save_data_figures;

%% 1. load_params_distr_initials.m
% loads parameter set
% defines name for data and figure storage
% defines survival function distributions and shapes
% defines initial conditions

%% 2. compute_ODE.m
% stores parameters into par (object) storage
% computes the ODE solution (compare w/ exp distributions in integrals)
% uses ShIsIrTsTrRsRrSvMsMr_func.m for ODE

%% 3. load_survival_func_2strains.m
% creates survival function using Survival_Func.m
% creates derivative of survival function using Survival_Func_Deriv.m 
% evaluates and stores survival functions and derivatives at all timepoints
% multiplies related survival function values for a given class
% multiplies stored survival functions with relevant initial conditions

%% 4. initialize_storage.m
% intializes storage for all classes in model
% stores initial conditints into first storage slot
% initializes the following important quantities:
%   birth rates
%   forces of infection
%   transmission terms
%   other flux terms
%   integrated terms

%% 5. calculate_second_timepoint.m
% calculates integrals at second timepoints using left rectangles 
% (trapz won't work with only one known value at the first timepoint)

%% 6. calculate_other_timepoints.m
% calculates integrals at all other timepoints using integral_func.m
% (combination of trapz and left rectangles)

%% 7. compute_R_invasion_nums;
% computes the reproduction numbers and invasion numbers for each strain

%% 8. plot_data.m
% calculates difference between ODE solution and integral solution
% calculates percent difference between ODE solution and integral solution
% combines all human classes and all vector classes into two matrices
% (also combines human and vectors differences and percent differences)
% computes max/min outputs, differences, and percent differences
% plots human integrals versus human ODEs with human differences
% plots vector integrals versus vector ODEs with vector differences

%% 9. save_data_figures.m
% stores data name
% stores .fig and .jpg plot names
% saves data in 'Data' subfolders
% saves .fig and .jpg plots in 'FiguresFIG' and 'FiguresJPG' subfolders

