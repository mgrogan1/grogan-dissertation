%% calculate Sh, Is, Ir, Ts, Tr, Rs, Rr, Sv, Ms, Mr at second timepoint - special case for trapz (j=1)

%% birth rates (constant set in parameters, but can change here if desired)

% birth rate for constant human population
%LambdaH(1) = muH*Nht(1) + deltaS*(Ist(1) + Tst(1)) + deltaR*(Irt(1)+Trt(1));

% birth rate for constant vector population
%LambdaV(j) = muV*Nvt(j);

%% forces of infection

% nonconstant s-force of infection human
lambdaS(1) = betaH*Mst(1)/Nht(1);

% nonconstant r-force of infection humans
lambdaR(1) = kappaH*betaH*Mrt(1)/Nht(1);

% nonconstant s-force of infection vector
upsilonS(1) = betaV*(Ist(1)+psiS*Tst(1))/Nht(1);

% nonconstant r-force of infection vector 
upsilonR(1) = kappaV*betaV*(Irt(1)+psiR*Trt(1))/Nht(1);

%% transmission terms

% s-transmission from Sh
lambdaS_Sht(1) = lambdaS(1)*Sht(1);

% r-transmission from Sh
lambdaR_Sht(1) = lambdaR(1)*Sht(1);

% r-transmission from Is
lambdaR_Ist(1) = lambdaR(1)*Ist(1);

% r-transmission from Ts (scaled)
lambdaR_Tst(1) = lambdaR(1)*Tst(1);

% r-transmission from Rs
lambdaR_Rst(1) = lambdaR(1)*Rst(1);

% s-transmission from Sv
upsilonS_Svt(1) = upsilonS(1)*Svt(1);

% r-transmission from Sv
upsilonR_Svt(1) = upsilonR(1)*Svt(1);

%% flux terms

% transmission for Is, Sh s-infections minus r-infection
flux_Is(1) = lambdaS_Sht(1) - lambdaR_Ist(1);

% transmission for Ir, S r-infections plus Is r-infections
flux_Ir(1) = lambdaR_Sht(1) + lambdaR_Ist(1) + lambdaR_Tst(1) + lambdaR_Rst(1);

% birth - transmission for Sv
flux_Sv(1) = LambdaV(1) - upsilonS_Svt(1) - upsilonR_Svt(1);

% transmission for Ms
flux_Ms(1) = upsilonS_Svt(1);

% transmission for Mr
flux_Mr(1) = upsilonR_Svt(1);


%% other flux terms

% Sh flux w/out recovery terms = birth - transmission for Sh = LambdaH -
% lambdaS*Sht - lambdaR*Sht
flux_Sh_noR(1) = LambdaH(1) - lambdaS_Sht(1) - lambdaR_Sht(1);

%% calculates initial movements

% calculate initial Is movement to Ts (for Ts equation)
flux_Is_dQ_Ts(1) = flux_Is(1).*flip(PIs_dPIsTs_PND_PDDs(1));

% calculate initial Ir movement to Tr (for Ts equation)
flux_Ir_dQ_Tr(1) = flux_Ir(1).*flip(PIr_dPIrTr_PND_PDDr(1));

% integrate initial Is movement to Ts (for Ts equation) using left
% rectangle
int_flux_Is_dQ_Ts(1) = flux_Is_dQ_Ts(1)*dt;

% integrate initial Ir movement to Tr (for Tr equation) using left
% rectangle
int_flux_Ir_dQ_Tr(1) = flux_Ir_dQ_Tr(1)*dt;

% calculate initial Ts flux
flux_Ts(1) = int_flux_Is_dQ_Ts(1) + Is0_PIs_dPIsTs_PND_PDDs(1) - lambdaR_Tst(1);

% calculate initial Tr flux
flux_Tr(1) = int_flux_Ir_dQ_Tr(1) + Ir0_PIr_dPIrTr_PND_PDDr(1);

% calculate initial Is movement to Rs (for Rs equation)
flux_Is_dQ_Rs(1) = flux_Is(1).*flip(dPIs_PIsTs_PND_PDDs(1));

% calculate initial Ir movement to Rr (for Rr equation)
flux_Ir_dQ_Rr(1) = flux_Ir(1).*flip(dPIr_PIrTr_PND_PDDr(1));

% integrate initial Is movement to Rs (for Rs equation) using left
% rectangle
int_flux_Is_dQ_Rs(1) = flux_Is_dQ_Rs(1)*dt;

% integrate initial Ir movement to Rr (for Rr equation) using left
% rectangle
int_flux_Ir_dQ_Rr(1) = flux_Ir_dQ_Rr(1)*dt;

% calculate initial Rs flux
flux_Rs(1) = int_flux_Is_dQ_Rs(1) + Is0_dPIs_PIsTs_PND_PDDs(1) - lambdaR_Rst(1);

% calculate initial Rr flux
flux_Rr(1) = int_flux_Ir_dQ_Rr(1) + Ir0_dPIr_PIrTr_PND_PDDr(1);

% calculate initial Rs movement to Sh (for Sh equation)
flux_Rs_dQ_Sh(1) = flux_Rs(1).*flip(dPRs_PND(1));

% calculate initial Rr movement to Sh (for Sh equation)
flux_Rr_dQ_Sh(1) = flux_Rr(1).*flip(dPRr_PND(1));

% integrate initial Rs movement to Sh (for Sh equation) using left
% rectangle
int_flux_Rs_dQ_Sh(1) = flux_Rs_dQ_Sh(1)*dt;

% integrate initial Rr movement to Sh (for Sh equation) using left
% rectangle
int_flux_Rr_dQ_Sh(1) = flux_Rr_dQ_Sh(1)*dt;


%% moving initial populations
% calculate Is initials moving to Rs integrand, Is0_IsRs, from t0 to t1
Is0_IsRs = Is0_dPIs_PIsTs_PND_PDDs(1:2).*flip(PRs_PND(1:2));

% calculate Ir initials moving to Rr integrand, Ir0_IrRr, from t0 to t1
Ir0_IrRr = Ir0_dPIr_PIrTr_PND_PDDr(1:2).*flip(PRr_PND(1:2));

% calculate Is initials moving to Ts integrand, Is0_IsTs, from t0 to t1
Is0_IsTs = Is0_PIs_dPIsTs_PND_PDDs(1:2).*flip(PTs_PND_PDDs(1:2));

% calculate Ir initials moving to Tr integrand, Ir0_IrTr, from t0 to t1
Ir0_IrTr = Ir0_PIr_dPIrTr_PND_PDDr(1:2).*flip(PTr_PND_PDDr(1:2));

% calculate Ts initials moving to Rs integrand, Ts0_TsRs, from t0 to t1
Ts0_TsRs = Ts0_dPTs_PND_PDDs(1:2).*flip(PRs_PND(1:2));

% calculate Tr initials moving to Rr integrand, Tr0_TrRr, from t0 to t1
Tr0_TrRr = Tr0_dPTr_PND_PDDr(1:2).*flip(PRr_PND(1:2));

% sum Is and Ts initals moving to Rs
Is0_Ts0_Rs = Is0_IsRs + Ts0_TsRs;

% sum Ir and Tr initals moving to Rr
Ir0_Tr0_Rr = Ir0_IrRr + Tr0_TrRr;

% calculate Rs initials moving to S integrand, Rs0_RsS, from t0 to t1
Rs0_RsSh = Rs0_dPRs_PND(1:2).*flip(PND(1:2));

% calculate Rr initials moving to S integrand, Rr0_RrS, from t0 to t1
Rr0_RrSh = Rr0_dPRr_PND(1:2).*flip(PND(1:2));


%% calculate other flux terms

% flux of Sh 
flux_Sh(1) = flux_Sh_noR(1) + trapz(tspan(1:2), Rs0_RsSh) + trapz(tspan(1:2), Rr0_RrSh);


%% calculate flux times Q

% calculate Sh integrand, g, from 0 to t_j
flux_Sh_Q(1) = flux_Sh(1).*flip(PND(2));

% calculate Is integrand, fs, from t_0 to t_1
flux_Is_Q(1) = flux_Is(1).*flip(PIs_PIsTs_PND_PDDs(2));

% calculate Ir integrand, fr, from t_0 to t_1
flux_Ir_Q(1) = flux_Ir(1).*flip(PIr_PIrTr_PND_PDDr(2));

%% calculate humans Sh, Is, Ir, Ts, Tr, Rs, Rr at second timepoint (j=2)

% calculate next Sh (integrate g with left rectangle, add initial Sh
% population)
Sht(2) = flux_Sh_Q(1)*dt + Sh0_PND(2);

% calculate next Is (integrate fs with left rectangle, add initial Is
% population)
Ist(2) = flux_Is_Q(1)*dt + Is0_PIs_PIsTs_PND_PDDs(2);

% calculate next Ir (integrate fr with left rectangle, add initial Ir
% population)
Irt(2) = flux_Ir_Q(1)*dt + Ir0_PIr_PIrTr_PND_PDDr(2);

%calculate next Ts (integrate hIsTs with left rectangle, integrate initial
%Is population, add initial Ts population)
Tst(2) = trapz(tspan(1:2), Is0_IsTs) - lambdaR_Tst(1)*dt + Ts0_PTs_PND_PDDs(2);

%calculate next Tr (integrate hIrTr with left rectangle, integrate initial
%Ir population, add initial Tr population)
Trt(2) = trapz(tspan(1:2), Ir0_IrTr) + Tr0_PTr_PND_PDDr(2);

%calculate next Rs (integrate h with left rectangle, integrate initial Is
%population, add initial Rs population)
Rst(2) = trapz(tspan(1:2), Is0_Ts0_Rs) - lambdaR_Rst(1)*dt + Rs0_PRs_PND(2);

%calculate next Rr (integrate h with left rectangle, integrate initial Ir
%population, add initial Rr population)
Rrt(2) = trapz(tspan(1:2), Ir0_Tr0_Rr) + Rr0_PRr_PND(2);

%% calculate vectors Sv, Ms, Mr at second timepoint (j=2)

% calculate next Sv 
flux_Sv_Q(1) = flux_Sv(1).*flip(PV(2));
Svt(2) = flux_Sv_Q(1)*dt + Sv0_PV(2);

% calculate next Ms 
flux_Ms_Q(1) = flux_Ms(1).*flip(PV(2));
Mst(2) = flux_Ms_Q(1)*dt + Ms0_PV(2);

% calculate next Mr 
flux_Mr_Q(1) = flux_Mr(1).*flip(PV(2));
Mrt(2) = flux_Mr_Q(1)*dt + Mr0_PV(2);

%% calculate total populations

% calculate human population
Nht(2) = Sht(2)+Ist(2)+Irt(2)+Tst(2)+Trt(2)+Rst(2)+Rrt(2);

% calculate vector population
Nvt(2) = Svt(2)+Mst(2)+Mrt(2);
