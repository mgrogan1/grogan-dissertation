
%tic %start timer

%Sv'Ms'Mr'Sh'Is'Ir'Tsk'Trk'Rs'Rr'

%format long
%close all
%clear

% load data
%load('Data/1strain_dt_0_tf_200_EE_AIM2020_testshapeless1.mat');

% choose tf

start_t = 1;%20/dt;
end_t = (tf-t0)/dt;

interesting_t = tspan(start_t:end_t);

% choose colormap
%colors=colormap(cool(15));
%colors=colormap(prism(6));
colors=colormap(hsv(15));
        
%% 'gamma distributions in 1 strain model' 

%figure('Name',name)%,'NumberTitle','off')

subplot(1,2,1)
hold on

%susceptible H
p(1) = plot(interesting_t,Sht(start_t:end_t,1),'linewidth',4);
p(1).Color=colors(11,:);

%infected H
p(2) = plot(interesting_t,Ist(start_t:end_t,1),'--','linewidth',4);
p(2).Color=colors(1,:);

%treated H
p(3) = plot(interesting_t,Tst(start_t:end_t,1),':','linewidth',4);
p(3).Color=colors(13,:);

%recovered H
p(4) = plot(interesting_t,Rst(start_t:end_t,1),'-o','MarkerIndices',1:150:length(interesting_t),'linewidth',4);
p(4).Color=colors(9,:);

%legend & labels
%'$\hat{\psi}$','Interpreter','latex'
legend('$S$', '$I$', '$T$', '$R$','Interpreter','latex','fontsize',15, 'Location','northeast')
title(sprintf('Host'),'fontsize',15)
xlabel('time (days)','fontsize',15)
ylabel('population size','fontsize', 15)
xlim([start_t*dt,end_t*dt])

subplot(1,2,2)
hold on
%susceptible V
p(5) = plot(interesting_t,Svt(start_t:end_t,1),'linewidth',4);
p(5).Color=colors(11,:);

%infected V
p(6) = plot(interesting_t,Mst(start_t:end_t,1),'--','linewidth',4);
p(6).Color=colors(1,:);

%legend & labels
legend('$S_v$', '$I_v$','Interpreter','latex','fontsize',15, 'Location','east')
title(sprintf('Vector'),'fontsize',15)
xlabel('time (days)','fontsize',15)
ylabel('population size','fontsize', 15)
xlim([start_t*dt,end_t*dt])

% main title
sgtitle(strcat('\bf{Model Simulation ( }',equilibrium,' )'),'fontsize',20)

%% names

%data name
dataname_pretty= strcat(name, '_pretty', '.mat');

%figure name 
figname_petty = strcat(name,'_pretty','.fig');
figname_pretty_JPG = strcat(name,'_pretty','.jpg');

%% save data

save([pwd strcat('/Data/',dataname_pretty)]);

%% save figures 

%save figures in .fig and .jpg 
savefig(figure(1), [pwd strcat('/FiguresFIG/',figname_petty)]);
saveas(figure(1), [pwd strcat('/FiguresJPG/',figname_pretty_JPG)]);

%toc %stop timer