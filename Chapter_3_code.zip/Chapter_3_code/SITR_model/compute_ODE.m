%% Compare with ODE

% store parameters into par object
par.a = a;
par.alphaS = alphaS;
par.alphaR = alphaR;
par.betaH = betaH;
par.betaV = betaV;
par.kappaH = kappaH;
par.kappaV = kappaV;
par.psiS = psiS;
par.psiR = psiR;
%par.phi = phi;
par.deltaS = deltaS;
par.deltaR = deltaR;
par.gammaS = gammaS;
par.gammaR = gammaR;
par.muH = muH;
par.muV = muV;
par.omegaS = omegaS;
par.omegaR = omegaR;
par.LambdaH0 = LambdaH0;
par.LambdaV0 = LambdaV0;

% compute the ODE using ShIsIrTsTrRsRrSvMsMr_func
%options = odeset('NonNegative',1:length(ShIsIrTsTrRsRrSvMsMr0));
[t,z] = ode45(@ShIsIrTsTrRsRrSvMsMr_func, tspan, ShIsIrTsTrRsRrSvMsMr0', [], par);
