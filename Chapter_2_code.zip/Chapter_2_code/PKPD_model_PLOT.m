
tic %start timer

%Sv'Ms'Mr'Sh'Is'Ir'Tsk'Trk'Rs'Rr'

clear 
close all

%% set inputs
n=3;
psi_dir = 'decreasing';
phi_dir = 'increasing';

%% load parameters
Parameter_settings_LHS

%Parameters, from Parameter_Settings
par.n = n;
par.muH = muH;
par.muV = muV;
par.lambdaH = lambdaH/Nh0;
par.lambdaV = lambdaV/Nv0;
par.deltaS = deltaS;
par.deltaR = deltaR;
par.betaH = betaH; 
par.betaV = betaV;
par.kappaH = kappaH; 
par.kappaV = kappaV;
par.a = a;
par.alpha = alpha;
par.omegaS = omegaS; 
par.omegaR = omegaR;
par.sigmaS = sigmaS;
par.sigmaR = sigmaR; 
par.psiS0 = psiS0; 
par.psiR0 = psiR0;
par.phi0 = phi0;

% % INITIAL CONDITION FOR THE ODE MODEL
% Nv0 = lambdaV/muV;
% Ms0 = 0.005*Nv0; % 0.5% of population
% Mr0 = 0.005*Nv0;
% Sv0 = lambdaV/muV-(Ms0+Mr0); %
% 
% Nh0 = lambdaH/muH;
% Is0 = 0.05*Nh0;% 5% of population
% Ir0 = 0.05*Nh0;
% Sh0 = lambdaH/muH - (Is0+Ir0); %
% Ts0 = zeros(n,1);
% Tr0 = zeros(n,1);
% Rs0 = 0;
% Rr0 = 0;
% 
% y0 = [Sv0/Nv0; Ms0/Nv0; Mr0/Nv0; Sh0/Nh0; Is0/Nh0; Ir0/Nh0; Ts0/Nh0; Tr0/Nh0; Rs0/Nh0; Rr0/Nh0];
% 

    
options=odeset('NonNegative',1:3+3+2*n+2);
[t, y] = ode45(@PKPD_model_func,tspan,y0,options,par); 

mycolors = colormap(parula(length(y0)));

%infected 
figure(1)
hold on
for i=5:6
plot(t(1:end),y(1:end,i),'LineWidth',2.0, 'Color',mycolors(i,:));
end
legend(y_var_labels(5:6))

%treated
figure(2)
hold on
for i=7:length(y0)-2
plot(t(1:end),y(1:end,i),'LineWidth',2.0, 'Color',mycolors(i,:));
end
legend(y_var_labels(7:length(y0)-2))

% LambdaV_vec = linspace(1*(par.lambdaH/par.muH)*par.muV, 10*(par.lambdaH/par.muH)*par.muV, 10);
% LambdaV_vec_label = string();
% 
% LambdaH_vec = linspace(2.24e3,5.08e3, 10);
% LambdaH_vec_label = string();
% 
%mycolors = colormap(jet(length(y0)));
% 
% 
% for i = 1:length(LambdaH_vec)
% 
% %par.lambdaV = LambdaV_vec(i);
% %LambdaV_vec_label(i) = strcat('LambdaV = ', num2str(LambdaV_vec(i)));
% 
% par.lambdaH = LambdaH_vec(i);
% LambdaH_vec_label(i) = strcat('LambdaH = ', num2str(LambdaH_vec(i)));
% 
% [t,z] = ode45(@PKPD_model_func,tspan,z0,[],par);
% 
% figure(1)
% hold on
% for i=5:length(y0)-2
% plot(t(1:end),y(1:end,i),'LineWidth',2.0, 'Color',mycolors(i,:));
% end
%legend(y_var_labels(5:length(y0)-2))
%
%
% colormap jet
% xlabel('days');
% ylabel('s-infections');
%legend(LambdaH_vec_label);

 toc %stop timer


%maybe run out to so many days to try to estimate boundary equilibria