%% This script will compute the SSE of the PKPD model using baseline parameters
%% Everything here will be in terms of I_s

%% Only INPUT is which root for Is cubic to choose, options: ZERO, MINUS, PLUS

%Is_root = 'ZERO';

%% First upload the baseline parameter set, then compute useful parameter groupings

% The following set uploads all the same baseline parameters used in the LHS code 
Parameter_settings_LHS;

%deltaS=0;

%% Loop through values of betaH within appropriate range (LHS range)

betaHtest = linspace(0.1,0.9,100);
betaHtest_labels = strings(1,length(betaHtest));
for k = 1:length(betaHtest)
     betaHtest_labels(k) = sprintf('betaH_{%d}',k);
end

SSE = zeros(length(betaHtest),5+n);

for j=1:length(betaHtest)
    j;
    betaH = betaHtest(j);

% Compute transmissions terms with DFE (appear in Reproduction numbers)
hs = betaH/muV;
vs = (betaV*lambdaV*muH)/(lambdaH*muV);

% Compute compartment time parameters
cs = a + deltaS + muH + sigmaS;

c = zeros(1,n);
cprod = zeros(1,n);
alphaprod = zeros(1,n);

for k=1:n
    c(k) = alpha(k) + deltaS + muH;
    cprod(k) = 1/prod(c(1:k));
    %first entry in alphaprod is 1 due to the empty product (shifted 1
    %from cprod)
    alphaprod(k) = prod(alpha(1:k-1));
end

% Compute useful groupings 

% b1-b3 should increase
b1 = 1 + a*((alphaprod.*cprod)*psiS0');
b2 = 1 + a*((alphaprod*cprod'));
b3 = b2 + sigmaS/(omegaS + muH);

Qs = (betaV*b1*muH)/(muV*b2*deltaS);

% Compute Reproduction number
R0s2 = hs*vs*b1/cs;

%% Determine I_s
% We have determined Is to be a cubic, with one zero root. So we have 3
% possible cases for evaluating the system

% options for switch are 'IsZERO', 'IsMINUS', 'IsPLUS' 
switch Is_root
    
    case 'ZERO'
        
        Is_SSE = 0;
        
    case 'MINUS'
        
        %compute coefficients for AsIs^2 + BsIs + Cs = 0
        As = -cs*b2*deltaS*muV*(betaV*b1*muH - b2*deltaS*muV);
        Bs = cs*muV*lambdaH*(betaV*b1*muH - b2*deltaS*muV) - cs*b2*deltaS*muV^2*lambdaH +betaV*betaH*b1*lambdaV*muH*(b2*deltaS +b3*muH);
        Cs = cs*muV^2*lambdaH^2-betaV*betaH*b1*lambdaV*muH*lambdaH;
        
%         As = cs*b2^2*deltaS^2*muV^2*(1-Qs);
%         Bs = cs*b2*deltaS*lambdaH*muV^2*((R0s2-1)+(((muH*b3*R0s2)/(deltaS*b2)) + Qs - 1));
%         Cs = cs*lambdaH^2*muV^2*(1-R0s2);
        
        %plug into quadratic equation with negative square root
        Is_SSE = (-Bs - sqrt(Bs^2 - 4*As*Cs))/(2*As);
        
    case 'PLUS'
        
        %compute coefficients for AsIs^2 + BsIs + Cs = 0
        As = -cs*b2*deltaS*muV*(betaV*b1*muH - b2*deltaS*muV);
        Bs = cs*muV*lambdaH*(betaV*b1*muH - b2*deltaS*muV) - cs*b2*deltaS*muV^2*lambdaH +betaV*betaH*b1*lambdaV*muH*(b2*deltaS +b3*muH);
        Cs = cs*muV^2*lambdaH^2-betaV*betaH*b1*lambdaV*muH*lambdaH;
        
        %plug into quadratic equation with negative square root
        Is_SSE = (-Bs + sqrt(Bs^2 - 4*As*Cs))/(2*As);
        
        
end




%% Evaluate other compartments with I_s

Sh_SSE = (lambdaH/muH) - ((b2*deltaS/muH)+b3)*Is_SSE;

% Make Ts equations for general n

Ts_SSE = zeros(1,n);

for k=1:n
    Ts_SSE(k) = (a*alphaprod(k)/cprod(k))*Is_SSE;
end

Ts1_SSE = (a/c(1))*Is_SSE;

Ts2_SSE = (a*alpha(1)/c(1)*c(2))*Is_SSE;

Ts3_SSE = (a*alpha(1)*alpha(2)/c(1)*c(2)*c(3))*Is_SSE;

Ts_SSE = [Ts1_SSE, Ts2_SSE, Ts3_SSE];


Rs_SSE = (sigmaS/(omegaS + muH))*Is_SSE;

Sv_SSE = (lambdaV*(lambdaH - (b2*deltaS*Is_SSE)))/((lambdaH*muV)+((betaV*b1*muH) - (b2*deltaS*muV))*Is_SSE);

Ms_SSE = (betaV*b1/muV)*(lambdaV*muH)/((lambdaH*muV)+((betaV*b1*muH) - (b2*deltaS*muV))*Is_SSE)*Is_SSE;

Nh_SSE = Sh_SSE + Is_SSE + sum(Ts_SSE) + Rs_SSE;
%Nh_SSE_compare = (lambdaH/muH)-(b2*deltaS/muH)*Is_SSE
%Nh_SSE = lambdaH/muH;

Nv_SSE = Sv_SSE + Ms_SSE;
%Nv_SSE_compare = lambdaV/muV;

% SSE vector, note this is not the order in the LHS code
SSE(j,:) = [Sv_SSE/Nv_SSE, Ms_SSE/Nv_SSE, Sh_SSE/Nh_SSE, Is_SSE/Nh_SSE, Ts_SSE/Nh_SSE, Rs_SSE/Nh_SSE];

%group(j) = lambdaH - (b2*deltaS*Is_SSE);
%group2(j) = lambdaH*muV*((betaV*b1*muH) - (b2*deltaS*muV))*Is_SSE;

end

%SSE

%group;
%group2;

figure(1)
hold on
for i=1:size(SSE, 2)
    %figure(i);
    plot(betaHtest,SSE(:,i));%,'b','linewidth',3);
end