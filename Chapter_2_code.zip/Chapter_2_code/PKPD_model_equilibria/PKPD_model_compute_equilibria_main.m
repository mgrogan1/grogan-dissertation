%% This script will be the main file for computing the sensitive strain and 
%% resistant strain boundary equilibria. There are three types of inputs from 
%% which to choose: 'sensitive' versus 'resistant' strain and within each 
%% you can choose three types of roots for the Infected class: 'ZERO',
%% 'MINUS', or 'PLUS' corresponding to the roots of the cubic equation for 
%% the Infected class. You can also choose to use the baseline parameters
%% or very betaH

clear all
close all

format long

% choose 'sensitive' or 'resistant' strain
strain = 'sensitive';
n = 3;

% choose 'ZERO', 'MINUS', 'PLUS' root
I_root = 'PLUS';

% choose 'baseline' betaH or 'vary' betaH
type = 'baseline';

%choose direction of phi and psi
psi_dir = 'decreasing';
phi_dir = 'increasing';

switch strain
    
    case 'sensitive'
        Is_root = I_root;
               
        if strcmp(type,'baseline')
            PKPD_model_Compute_SSE_baseline;
        else
            PKPD_model_Compute_SSE_vary_betaH;
            betaH = betaHtest;
        end
        
%         fprintf('The sensitive strain equilibria with')
%         betaH
%         fprintf('is')
%         SSE
        
    case 'resistant'
        Ir_root = I_root;
               
        if strcmp(type,'baseline')
            PKPD_model_Compute_RSE_baseline;
        else
            PKPD_model_Compute_RSE_vary_betaH;
            betaH = betaHtest;
        end
        
%         fprintf('The resistant strain equilibria with');
%         betaH
%         fprintf('is')
%         RSE
end

    