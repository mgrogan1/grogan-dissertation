%% This script will compute the RSE of the PKPD model using baseline parameters
%% Everything here will be in terms of I_r

%% Only INPUT is which root for Ir cubic to choose, options: ZERO, MINUS, PLUS

%Ir_root = 'PLUS';

%% First upload the baseline parameter set, then compute useful parameter groupings

% The following set uploads all the same baseline parameters used in the LHS code 
Parameter_settings_LHS;

%% Loop through values of betaH within appropriate range (LHS range)

betaHtest = linspace(0.1,0.9,100);
betaHtest_labels = strings(1,length(betaHtest));
for k = 1:length(betaHtest)
     betaHtest_labels(k) = sprintf('betaH_{%d}',k);
end

RSE = zeros(length(betaHtest),5+n);

for j=1:length(betaHtest)
    j;
    betaH = betaHtest(j);

% Compute transmissions terms with DFE (appear in Reproduction numbers)
hr = kappaH*betaH/muV;
vr = kappaV*(betaV*lambdaV*muH)/(lambdaH*muV);

% Compute compartment time parameters
dr = a + deltaR + muH + sigmaR;

d = zeros(1,n);
dprod = zeros(1,n);
alphaprod = zeros(1,n);

for k=1:n
    d(k) = alpha(k) + deltaR + muH;
    dprod(k) = 1/prod(d(1:k));
    %first entry in alphaprod is 1 due to the empty product (shifted 1
    %from dprod)
    alphaprod(k) = prod(alpha(1:k-1));
end

% Compute useful groupings 

% b1-b3 should increase
g1 = 1 + a*((alphaprod.*dprod)*psiR0');
g2 = 1 + a*((alphaprod*dprod'));
g3 = g2 + sigmaR/(omegaR + muH);

Qr = (kappaV*betaV*g1*muH)/(muV*g2*deltaR);

% Compute Reproduction number
R0r2 = hr*vr*g1/dr;

%% Determine I_r
% We have determined Is to be a cubic, with one zero root. So we have 3
% possible cases for evaluating the system

% option for switch is the input at top of script: 'IrZERO', 'IrMINUS', 'IrPLUS' 
switch Ir_root
    
    case 'ZERO'
        
        Ir_RSE = 0;
        
    case 'MINUS'
        
        %compute coefficients for ArIr^2 + BrIr + Cr = 0
        
        Ar = -dr*g2*deltaR*muV*(kappaV*betaV*g1*muH - g2*deltaR*muV);
        Br = dr*muV*lambdaH*(kappaV*betaV*g1*muH - g2*deltaR*muV) - dr*g2*deltaR*muV^2*lambdaH + kappaV*betaV*kappaH*betaH*g1*lambdaV*muH*(g2*deltaR +g3*muH);
        Cr = dr*muV^2*lambdaH^2-kappaV*betaV*kappaH*betaH*g1*lambdaV*muH*lambdaH;
        
%         Ar = dr*g2^2*deltaR^2*muV^2*(1-Qr);
%         Br = dr*g2^2*deltaR*lambdaH*muV^2*((R0r2-1)+(((muH*g3*R0r2)/(deltaR*g2)) + Qr - 1));
%         Cr = dr*lambdaH^2*muV^2*(1-R0r2);
        
        %plug into quadratic equation with negative square root
        Ir_RSE = (-Br - sqrt(Br^2 - 4*Ar*Cr))/(2*Ar);
        
    case 'PLUS'
        
        %compute coefficients for AsIs^2 + BsIs + Cs = 0
        Ar = -dr*g2*deltaR*muV*(kappaV*betaV*g1*muH - g2*deltaR*muV);
        Br = dr*muV*lambdaH*(kappaV*betaV*g1*muH - g2*deltaR*muV) - dr*g2*deltaR*muV^2*lambdaH + kappaV*betaV*kappaH*betaH*g1*lambdaV*muH*(g2*deltaR +g3*muH);
        Cr = dr*muV^2*lambdaH^2-kappaV*betaV*kappaH*betaH*g1*lambdaV*muH*lambdaH;
        
        %plug into quadratic equation with negative square root
        Ir_RSE = (-Br + sqrt(Br^2 - 4*Ar*Cr))/(2*Ar);
        
        
end




%% Evaluate other compartments with I_s

Sh_RSE = (lambdaH/muH) - ((g2*deltaR/muH)+g3)*Ir_RSE;

% Make Ts equations for general n

Tr_RSE = zeros(1,n);

for k=1:n
    Tr_RSE(k) = (a*alphaprod(k)/dprod(k))*Ir_RSE;
end

Tr1_RSE = (a/d(1))*Ir_RSE;

Tr2_RSE = (a*alpha(1)/d(1)*d(2))*Ir_RSE;

Tr3_RSE = (a*alpha(1)*alpha(2)/d(1)*d(2)*d(3))*Ir_RSE;

Tr_RSE = [Tr1_RSE, Tr2_RSE, Tr3_RSE];


Rr_RSE = (sigmaR/(omegaR + muH))*Ir_RSE;

Sv_RSE = (lambdaV*(lambdaH - (g2*deltaR*Ir_RSE)))/((lambdaH*muV)+((kappaV*betaV*g1*muH) - (g2*deltaR*muV))*Ir_RSE);

Mr_RSE = (kappaV*betaV*g1/muV)*(lambdaV*muH)/((lambdaH*muV)+((kappaV*betaV*g1*muH) - (g2*deltaR*muV))*Ir_RSE)*Ir_RSE;

Nh_RSE = Sh_RSE + Ir_RSE + sum(Tr_RSE) + Rr_RSE;

Nv_RSE = Sv_RSE + Mr_RSE;

% RSE vector, note this is not the order in the LHS code
RSE(j,:) = [Sv_RSE/Nv_RSE, Mr_RSE/Nv_RSE, Sh_RSE/Nh_RSE, Ir_RSE/Nh_RSE, Tr_RSE/Nh_RSE, Rr_RSE/Nh_RSE];

end

%RSE

figure(1)
hold on
for i=1:size(RSE, 2)
    %figure(i);
    plot(betaHtest,RSE(:,i));%,'b','linewidth',3);
end