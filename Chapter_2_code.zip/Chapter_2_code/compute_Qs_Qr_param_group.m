%% compute parameters Q_s and Q_r from analysis of PKPD model equilibrium

clear 
close all

%% set inputs
n=3;
psi_dir = 'decreasing';
phi_dir = 'increasing';

%% load parameters
Parameter_settings_LHS

%% calculate Qs

c = zeros(1,n);
alphaprod = zeros(1,n);
cprod = zeros(1,n);

for k=1:n
    c(k) = alpha(k) + deltaS + muH;
    alphaprod(k) = prod(alpha(1:k-1));
    cprod(k) = 1/prod(c(1:k));
end

b1 = 1 + a*((alphaprod.*cprod)*psiS0');
b2 = 1 + a*(alphaprod*cprod');

Qs = (betaV*b1*muH)/(muV*b2*deltaS);

%% calculate Qr

d = zeros(1,n);
alphaprodR = zeros(1,n);
dprod = zeros(1,n);

for k=1:n
    d(k) = alpha(k) + deltaR + muH;
    alphaprodR(k) = prod(alpha(1:k-1));
    dprod(k) = 1/prod(d(1:k));
end

g1 = 1 + a*((alphaprodR.*dprod)*psiR0');
g2 = 1 + a*(alphaprodR*dprod');

Qr = (kappaV*betaV*g1*muH)/(muV*g2*deltaR);


