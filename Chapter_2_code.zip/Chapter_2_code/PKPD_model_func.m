%function MALARIA_func_val = MALARIA_func(t,x,par)
function dydt = PKPD_model_func(t,y,par)
%x = column vector = [Sv Ms Mr Sh Is Ir Tsk Trk Rs Rr]'

%Parameters
n = par.n; %number of treated compartments
lambdaH = par.lambdaH; 
lambdaV = par.lambdaV; 
muH = par.muH; 
muV = par.muV; 
deltaS = par.deltaS; 
deltaR = par.deltaR; 
betaH = par.betaH; 
betaV = par.betaV; 
kappaH = par.kappaH; 
kappaV = par.kappaV; 
a = par.a;
alpha = par.alpha; %vector
omegaS = par.omegaS; 
omegaR = par.omegaR;
sigmaS = par.sigmaS;
sigmaR = par.sigmaR; 
psiS = par.psiS0; %vector
psiR = par.psiR0; %vector
phi = par.phi0; %vector


% %MALARIA_func_val = zeros(8+2n,1); % Sv'Ms'Mr'Sh'Is'Ir'Tsk'Trk'Rs'Rr' column vector
% 
% MALARIA_func_val(1,1) = lambdaV - betaV*x(1)*(x(5)+psiS*x(7:2:8+2*n-3)+kappaV*(x(6)...
%     +psiR*x(8:2:8+2*n-2)))/sum(x(4:8+2*n))-muV*x(1); %S_v equation
% MALARIA_func_val(2,1) = betaV*x(1)*(x(5)+psiS*x(7:2:8+2*n-3))/sum(x(4:8+2*n))-muV*x(2); %M_s equation
% MALARIA_func_val(3,1) = betaV*kappaV*x(1)*(x(6)+psiR*x(8:2:8+2*n-2))/sum(x(4:8+2*n))-muV*x(3); %M_r equations
% 
% MALARIA_func_val(4,1) = lambdaH-betaH*x(4)*(x(2) + kappaH*x(3))/(sum(x(4:8+2*n)))...
%     +omegaS*x(8+2*n-1)+omegaR*x(8+2*n)+alpha(n)*(x(3+3+2*n-1)+x(3+3+2*n))-muH*x(4); %S_h' equation
% MALARIA_func_val(5,1) = betaH*(x(4)*x(2)-kappaH*x(5)*x(3))/(sum(x(4:8+2*n)))...
%     -(a+sigmaS+deltaS+muH)*x(5); %I_s' equation
% MALARIA_func_val(6,1) = betaH*kappaH*x(3)*(x(4)+x(5)+x(8+2*n-1))/(sum(x(4:8+2*n)))...
%     -(a+sigmaR+deltaR+muH)*x(6); %I_r equation
% MALARIA_func_val(7,1) = a*x(5)-(alpha(1)+deltaS+muH)*x(7)...
%     -betaH*kappaH*phi(1)*x(3)*x(7)/(sum(x(4:8+2*n))); %Ts1 equation
% MALARIA_func_val(8,1) = a*x(6)-(alpha(1)+deltaR+muH)*x(8)...
%     +betaH*kappaH*phi(1)*x(3)*x(7)/(sum(x(4:8+2*n))); %Tr1 equation
% 
% for k=2:2:2*n-2
% MALARIA_func_val(k+7,1) = alpha(k/2)*x(k+6)-(alpha(k/2+1)+deltaS+muH)*x(k+7)...
%     -betaH*kappaH*phi(k/2+1)*x(3)*x(k+7)/(sum(x(4:8+2*n))); %Tsk equations
% MALARIA_func_val(k+8,1) = alpha(k/2)*x(k+7)-(alpha(k/2+1)+deltaR+muH)*x(k+8)...
%     +betaH*kappaH*phi(k/2+1)*x(3)*x(k+7)/(sum(x(4:8+2*n))); %Trk equations
% end
% 
% MALARIA_func_val(8+2*n-1,1) = sigmaS*x(5)-(omegaS...
%     +betaH*kappaH*x(3)/(sum(x(4:8+2*n)))+muH)*x(8+2*n-1); %R_s equation
% MALARIA_func_val(8+2*n,1) = sigmaR*x(5)-(omegaR+muH)*x(8+2*n); %R_r equation
% 
% %t

% [Sv] 
A1 = lambdaV - betaV*y(1)*(y(5)+psiS*y(6+1:6+n)+kappaV*(y(6)...
    +psiR*y(6+n+1:6+2*n)))/sum(y(4:6+2*n+2))-muV*y(1); %Sv equation

% [Ms] 
A2 = betaV*y(1)*(y(5)+psiS*y(6+1:6+n))/sum(y(4:6+2*n+2))-muV*y(2); %M_s equation

% [Mr]
A3 = betaV*kappaV*y(1)*(y(6)+psiR*y(6+n+1:6+2*n))/sum(y(4:6+2*n+2))-muV*y(3); %M_r equation

% [Sh]
A4 = lambdaH-betaH*y(4)*(y(2) + kappaH*y(3))/(sum(y(4:6+2*n+2)))...
    +omegaS*y(6+2*n+1)+omegaR*y(6+2*n+2)+alpha(n)*(y(6+n)+y(6+2*n))-muH*y(4); %S_h' equation

% [Is]
A5 = betaH*(y(4)*y(2)-kappaH*y(5)*y(3))/(sum(y(4:6+2*n+2)))...
    -(a+sigmaS+deltaS+muH)*y(5); %I_s' equation

% [Ir]
A6 = betaH*kappaH*y(3)*(y(4)+y(5)+y(6+2*n+1))/(sum(y(4:6+2*n+2)))...
    -(a+sigmaR+deltaR+muH)*y(6); %I_r equation

% [Ts1] 
A7 = a*y(5)-(alpha(1)+deltaS+muH)*y(6+1)...
    -betaH*kappaH*phi(1)*y(3)*y(6+1)/(sum(y(4:6+2*n+2))); %Ts1 equation


% [Ts2...Tsn]
A8=zeros(n-1,1);
for k=2:n
A8(k-1,1) = alpha(k-1)*y(6+k-1)-(alpha(k)+deltaS+muH)*y(6+k)...
    -betaH*kappaH*phi(k)*y(3)*y(6+k)/(sum(y(4:6+2*n+2))); %Tsk equations
end

% [Tr1]
A9 = a*y(6)-(alpha(1)+deltaR+muH)*y(6+n+1)...
    +betaH*kappaH*phi(1)*y(3)*y(6+1)/(sum(y(4:6+2*n+2))); %Tr1 equation

% [Tr2...Trn]
A10=zeros(n-1,1);
for k=2:n
A10(k-1,1) = alpha(k-1)*y(6+n+k-1)-(alpha(k)+deltaR+muH)*y(6+n+k)...
    +betaH*kappaH*phi(k)*y(3)*y(6+k)/(sum(y(4:6+2*n+2))); %Trk equations
end

% [Rs]
A11 = sigmaS*y(5)-(omegaS...
    +betaH*kappaH*y(3)/(sum(y(4:6+2*n+2)))+muH)*y(6+2*n+1); %R_s equation

% [Rr]
A12 = sigmaR*y(6)-(omegaR+muH)*y(6+2*n+2); %R_r equation

dydt = [A1; A2; A3; A4; A5; A6; A7; A8; A9; A10; A11; A12];

end