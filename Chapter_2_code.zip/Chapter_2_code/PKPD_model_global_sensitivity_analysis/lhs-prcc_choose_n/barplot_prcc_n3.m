% CALCULATE/PLOT PRCC %set alpha (last argument in PRCC) = 1

% Set latex interpreter
close all
set(0,'defaulttextInterpreter','latex')
threshold = 0.1;

%options for switch are 'Infected', 'Treated', 'Sum', and 'RepNum'

switch 'Treated'
    
    case 'Infected'
        %Calculate PRCC:
        [prccIs_d sign sign_label]=PRCC(LHSmatrix,Is_lhs,1:length(time_points),PRCC_var,1);
        [prccIr_d sign sign_label]=PRCC(LHSmatrix,Ir_lhs,1:length(time_points),PRCC_var,1);
        
        %get rid of dummy variable
        prccIs = prccIs_d(1:length(prccIs_d)-1);
        prccIr = prccIr_d(1:length(prccIr_d)-1);
        
        %find indices above threshold
        prccIs_ind_above = abs(prccIs)>=0.1;
        prccIr_ind_above = abs(prccIr)>=0.1;
        prccI_ind_above = (prccIs_ind_above + prccIr_ind_above)>=1;
        
        %find indices below threshold
        prccI_ind_below = prccI_ind_above==0;
        
        %extract variable names
        PRCC_var_th_above = PRCC_var(prccI_ind_above);
        PRCC_var_th_below = PRCC_var(prccI_ind_below);
        
        %extract Is and Ir prcc above threshold
        plot_prccIs_above = prccIs(prccI_ind_above);
        plot_prccIr_above = prccIr(prccI_ind_above);
        
        %extract Is and Ir prcc below threshold
        plot_prccIs_below = prccIs(prccI_ind_below);
        plot_prccIr_below = prccIr(prccI_ind_below);
        
        %         j=0;
        %         PRCC_var_th = string(1);
        %         plot_prccIs = zeros(1);
        %         plot_prccIr = zeros(1);
        %
        %         for i = 1:length(prccIs)
        %             if abs(prccIs(i))>=threshold || abs(prccIr(i))>=threshold
        %                 %i
        %                 j=j+1;
        %                 %j
        %                 PRCC_var_th(j) = PRCC_var(i);
        %                 plot_prccIs(j) = prccIs(i);
        %                 plot_prccIr(j) = prccIr(i);
        %             end
        %         end
        %%Scatter Plot PRCC
        %         PRCC_PLOT(LHSmatrix,Is_lhs,1,PRCC_var,y_var_labels(5))
        %         PRCC_PLOT(LHSmatrix,Ir_lhs,1,PRCC_var,y_var_labels(6))
        
        %%Bar Plot PRCC
        figure('Name','prcc')
        colors=colormap(cool(2));
        
        %plot above threshold
        subplot(1,2,1);
        h = barh([plot_prccIs_above(1,:);plot_prccIr_above(1,:)]',1);
        h(1).FaceColor = colors(1,:);
        h(2).FaceColor = colors(2,:);
        %legend/label
        title('prcc greater than 0.1')
        legend('I_s', 'I_r','fontsize',20)
        yticks(1:1:length(PRCC_var_th_above))
        yticklabels(PRCC_var_th_above)
        ax = get(gca, 'YTickLabel');
        set(gca,'YTickLabel',ax,'fontsize',18)
        ylabel('parameters','fontsize', 20)
        xlabel('prcc','fontsize',20)
        
        %plot below threshold
        subplot(1,2,2);
        h = barh([plot_prccIs_below(1,:);plot_prccIr_below(1,:)]',1);
        h(1).FaceColor = colors(1,:);
        h(2).FaceColor = colors(2,:);
        %legend/label
        title('prcc less than 0.1')
        legend('I_s', 'I_r','fontsize',20)
        yticks(1:1:length(PRCC_var_th_below))
        yticklabels(PRCC_var_th_below)
        ax = get(gca, 'YTickLabel');
        set(gca,'YTickLabel',ax,'fontsize',18)
        %ylabel('parameters','fontsize', 20)
        xlabel('prcc','fontsize',20)
        
        % dataname_pretty = strcat(name,'_pretty.mat');
        
        %figure name - Is, Ir
        fignameI_pretty = strcat(name,'_PRCC_I_pretty','.fig');
        fignameI_JPG_pretty = strcat(name,'_PRCC_I_pretty','.jpg');
        
        %         %figure name - Ts, Tr
        %         fignameT = strcat(name,'_PRCC_T','.fig');
        %         fignameT_JPG = strcat(name,'_PRCC_T','.jpg');
        
        %save data
        % save Model_LHS.mat;
        % save([pwd strcat('/data/',dataname_pretty)]);
        
        %save I fig and jpg
        savefig(figure(1), [pwd strcat('/figures/FIG/',fignameI_pretty)]);
        saveas(figure(1), [pwd strcat('/figures/JPG/',fignameI_JPG_pretty)]);
        
        % %% save T fig and jpg
        % savefig(figure(2000), [pwd strcat('/figures/FIG/',fignameT)]);
        % saveas(figure(2000), [pwd strcat('/figures/JPG/',fignameT_JPG)]);

        
    case 'Treated'
        %%Calculate PRCC
        [prccTs1_d sign sign_label]=PRCC(LHSmatrix,Ts_lhs(1,:,1),1:length(time_points),PRCC_var,1);
        [prccTs2_d sign sign_label]=PRCC(LHSmatrix,Ts_lhs(1,:,2),1:length(time_points),PRCC_var,1);
        [prccTs3_d sign sign_label]=PRCC(LHSmatrix,Ts_lhs(1,:,3),1:length(time_points),PRCC_var,1);
        [prccTr1_d sign sign_label]=PRCC(LHSmatrix,Tr_lhs(1,:,1),1:length(time_points),PRCC_var,1);
        [prccTr2_d sign sign_label]=PRCC(LHSmatrix,Tr_lhs(1,:,2),1:length(time_points),PRCC_var,1);
        [prccTr3_d sign sign_label]=PRCC(LHSmatrix,Tr_lhs(1,:,3),1:length(time_points),PRCC_var,1);
        
        %get rid of dummy variable
        prccTs1 = prccTs1_d(1:length(prccTs1_d)-1);
        prccTs2 = prccTs2_d(1:length(prccTs2_d)-1);
        prccTs3 = prccTs3_d(1:length(prccTs3_d)-1);
        prccTr1 = prccTr1_d(1:length(prccTr1_d)-1);
        prccTr2 = prccTr2_d(1:length(prccTr2_d)-1);
        prccTr3 = prccTr3_d(1:length(prccTr3_d)-1);
        
        %find indices above threshold
        prccTs1_ind_above = abs(prccTs1)>=0.1;
        prccTs2_ind_above = abs(prccTs2)>=0.1;
        prccTs3_ind_above = abs(prccTs3)>=0.1;
        prccTr1_ind_above = abs(prccTr1)>=0.1;
        prccTr2_ind_above = abs(prccTr2)>=0.1;
        prccTr3_ind_above = abs(prccTr3)>=0.1;
        prccT_ind_above = (prccTs1_ind_above + prccTs2_ind_above + prccTs3_ind_above + ...
            prccTr1_ind_above + prccTr2_ind_above + prccTr3_ind_above)>=1;
        
        %find indices below threshold
        prccT_ind_below = prccT_ind_above==0;
        
        %extract variable names
        PRCC_var_th_above = PRCC_var(prccT_ind_above);
        PRCC_var_th_below = PRCC_var(prccT_ind_below);
        
        %extract Ts and Tr prcc above threshold
        plot_prccTs1_above = prccTs1(prccT_ind_above);
        plot_prccTs2_above = prccTs2(prccT_ind_above);
        plot_prccTs3_above = prccTs3(prccT_ind_above);
        plot_prccTr1_above = prccTr1(prccT_ind_above);
        plot_prccTr2_above = prccTr2(prccT_ind_above);
        plot_prccTr3_above = prccTr3(prccT_ind_above);
        
        %extract Ts and Tr prcc below threshold
        plot_prccTs1_below = prccTs1(prccT_ind_below);
        plot_prccTs2_below = prccTs2(prccT_ind_below);
        plot_prccTs3_below = prccTs3(prccT_ind_below);
        plot_prccTr1_below = prccTr1(prccT_ind_below);
        plot_prccTr2_below = prccTr2(prccT_ind_below);
        plot_prccTr3_below = prccTr3(prccT_ind_below);
        
%         j=0;
%         PRCC_var_th = string(1);
%         plot_prcc_s1 = zeros(1);
%         plot_prcc_s2 = zeros(1);
%         plot_prcc_s3 = zeros(1);
%         plot_prcc_r1 = zeros(1);
%         plot_prcc_r2 = zeros(1);
%         plot_prcc_r3 = zeros(1);
%         for i = 1:length(prccTs1)
%             if abs(prccTs1(i))>=threshold || abs(prccTs2(i))>=threshold || abs(prccTs3(i))>=threshold || ...
%                     abs(prccTr1(i))>=threshold || abs(prccTr2(i))>=threshold || abs(prccTr3(i))>=threshold
%                 i;
%                 j=j+1;
%                 j;
%                 PRCC_var_th(j) = PRCC_var(i);
%                 plot_prcc_s1(j) = prccTs1(i);
%                 plot_prcc_s2(j) = prccTs2(i);
%                 plot_prcc_s3(j) = prccTs3(i);
%                 plot_prcc_r1(j) = prccTr1(i);
%                 plot_prcc_r2(j) = prccTr2(i);
%                 plot_prcc_r3(j) = prccTr3(i);
%             end
%         end
        
        %%Scatter Plot PRCC
        %         PRCC_PLOT(LHSmatrix,Ts_lhs(1,:,1),1,PRCC_var,'$T_{s,1}$')
        %         PRCC_PLOT(LHSmatrix,Ts_lhs(1,:,2),1,PRCC_var,'$T_{s,2}$')
        %         PRCC_PLOT(LHSmatrix,Ts_lhs(1,:,3),1,PRCC_var,'$T_{s,3}$')
        %         PRCC_PLOT(LHSmatrix,Tr_lhs(1,:,1),1,PRCC_var,'$T_{r,1}$')
        %         PRCC_PLOT(LHSmatrix,Tr_lhs(1,:,2),1,PRCC_var,'$T_{r,2}$')
        %         PRCC_PLOT(LHSmatrix,Tr_lhs(1,:,3),1,PRCC_var,'$T_{r,3}$')
        
        figure('Name','prcc')
        %hs=barh([prccTs1(1,:);prccTs2(1,:);prccTs3(1,:)]');
        %hr=barh([prccTr1(1,:);prccTr2(1,:);prccTr3(1,:)]');
        
        % plot above threshold
        subplot(1,2,1)
        hsr=barh([plot_prccTs1_above(1,:);plot_prccTs2_above(1,:);plot_prccTs3_above(1,:);plot_prccTr1_above(1,:);plot_prccTr2_above(1,:);plot_prccTr3_above(1,:)]');
        colors=colormap(cool(2*n));
        for i=1:length(colors)
            %hs(i).FaceColor = colors(i,:);
            %hr(i).FaceColor = colors(i,:);
            hsr(i).FaceColor = colors(i,:);
        end
        %legend/label
        %legend('T_{s,1}', 'T_{s,2}', 'T_{s,3}','fontsize',18) %hs
        %legend('T_{r,1}', 'T_{r,2}', 'T_{r,3}','fontsize',18) %hr
        title('prcc greater than 0.1')
        legend('T_{s,1}', 'T_{s,2}', 'T_{s,3}','T_{r,1}', 'T_{r,2}', 'T_{r,3}','fontsize',18) %hsr
        yticks(1:1:length(PRCC_var_th_above))
        yticklabels(PRCC_var_th_above)
        ax = get(gca, 'YTickLabel');
        set(gca,'YTickLabel',ax,'fontsize',20)
        ylabel('parameters','fontsize', 18)
        xlabel('prcc','fontsize',18)
        
        % plot below threshold 
        subplot(1,2,2)
        hsr=barh([plot_prccTs1_below(1,:);plot_prccTs2_below(1,:);plot_prccTs3_below(1,:);plot_prccTr1_below(1,:);plot_prccTr2_below(1,:);plot_prccTr3_below(1,:)]');
        colors=colormap(cool(2*n));
        for i=1:length(colors)
            %hs(i).FaceColor = colors(i,:);
            %hr(i).FaceColor = colors(i,:);
            hsr(i).FaceColor = colors(i,:);
        end
        %legend/label
        %legend('T_{s,1}', 'T_{s,2}', 'T_{s,3}','fontsize',18) %hs
        %legend('T_{r,1}', 'T_{r,2}', 'T_{r,3}','fontsize',18) %hr
        title('prcc less than 0.1')
        legend('T_{s,1}', 'T_{s,2}', 'T_{s,3}','T_{r,1}', 'T_{r,2}', 'T_{r,3}','fontsize',18) %hsr
        yticks(1:1:length(PRCC_var_th_below))
        yticklabels(PRCC_var_th_below)
        ax = get(gca, 'YTickLabel');
        set(gca,'YTickLabel',ax,'fontsize',20)
        %ylabel('parameters','fontsize', 18)
        xlabel('prcc','fontsize',18)
        
        %figure name - Ts, Tr
        fignameT_pretty = strcat(name,'_PRCC_T_pretty','.fig');
        fignameT_JPG_pretty = strcat(name,'_PRCC_T_pretty','.jpg');
        
        %save T fig and jpg
        savefig(figure(1), [pwd strcat('/figures/FIG/',fignameT_pretty)]);
        saveas(figure(1), [pwd strcat('/figures/JPG/',fignameT_JPG_pretty)]);
        
        
    case 'Sum'
        %%Sum s and r classes
        sum_s = Ts_lhs(1,:,1) + Ts_lhs(1,:,2) + Ts_lhs(1,:,3);
        sum_r = Tr_lhs(1,:,1) + Tr_lhs(1,:,2) + Tr_lhs(1,:,3);
        [prccSum_s sign sign_label]=PRCC(LHSmatrix,sum_s,1:length(time_points),PRCC_var,1);
        [prccSum_r sign sign_label]=PRCC(LHSmatrix,sum_r,1:length(time_points),PRCC_var,1);
        j=0;
        PRCC_var_th = string(1);
        plot_prccSum_s = zeros(1);
        plot_prccSum_r = zeros(1);
        for i = 1:length(prccSum_s)
            if abs(prccSum_s(i))>=threshold || abs(prccSum_r(i))>=threshold
                %i
                j=j+1;
                %j
                PRCC_var_th(j) = PRCC_var(i);
                plot_prccSum_s(j) = prccSum_s(i);
                plot_prccSum_r(j) = prccSum_r(i);
            end
        end
        %%Scatter Plot PRCC
        %         PRCC_PLOT(LHSmatrix,sum_s,1,PRCC_var,'$Sum_s$')
        %         PRCC_PLOT(LHSmatrix,sum_r,1,PRCC_var,'$Sum_r$')
        figure('Name','prcc')
        colors=colormap(cool(2));
        h=barh([plot_prccSum_s(1,:);plot_prccSum_r(1,:)]',1);
        h(1).FaceColor = colors(1,:);
        h(2).FaceColor = colors(2,:);
        %legend/label
        legend('SumT_s', 'SumT_r','fontsize',20)
        yticks(1:1:length(PRCC_var_th))
        yticklabels(PRCC_var_th)
        ax = get(gca, 'YTickLabel');
        set(gca,'YTickLabel',ax,'fontsize',20)
        ylabel('parameters','fontsize', 20)
        xlabel('prcc','fontsize',20)
        
    case 'RepNum'
        %%Reproduction numbers
        [prccR0s2 sign sign_label]=PRCC(LHSmatrix,R0s2,1:length(time_points),PRCC_var,1);
        [prccR0r2 sign sign_label]=PRCC(LHSmatrix,R0r2,1:length(time_points),PRCC_var,1);
        j=0;
        PRCC_var_th = string(1);
        plot_prccR0s2 = zeros(1);
        plot_prccR0r2 = zeros(1);
        for i = 1:length(prccR0s2)
            if abs(prccR0s2(i))>=threshold || abs(prccR0r2(i))>=threshold
                %i
                j=j+1;
                %j
                PRCC_var_th(j) = PRCC_var(i);
                plot_prccR0s2(j) = prccR0s2(i);
                plot_prccR0r2(j) = prccR0r2(i);
            end
        end
        %%Scatter Plot PRCC
        %         PRCC_PLOT(LHSmatrix,R0s2,1,PRCC_var,'$R0_s^2$')
        %         PRCC_PLOT(LHSmatrix,R0r2,1,PRCC_var,'$R0_r^2$')
        figure('Name','prcc')
        colors=colormap(cool(2));
        h=barh([plot_prccR0s2(1,:);plot_prccR0r2(1,:)]',1); % do for reproduction numbers or invasion numbers
        h(1).FaceColor = colors(1,:);
        h(2).FaceColor = colors(2,:);
        %legend/label
        legend('R0_s^2', 'R0_r^2','fontsize',20)
        yticks(1:1:length(PRCC_var_th))
        yticklabels(PRCC_var_th)
        ax = get(gca, 'YTickLabel');
        set(gca,'YTickLabel',ax,'fontsize',20)
        ylabel('parameters','fontsize', 20)
        xlabel('prcc','fontsize',20)
end

