% run varying numbers of runs options for phi and psi

clear
close all

runs_vec = [100000];%[100, 1000, 10000, 100000];
distribution = 'unif';
n_vec = [1, 3, 5];
n = 3;
phi_dir_vec = {'increasing', 'decreasing'}; %default = increasing
psi_dir_vec = {'decreasing', 'increasing'}; %default = decreasing

for i=1:length(runs_vec)
    
    runs = runs_vec(i);
    
    for j=1:length(psi_dir_vec)
        
        psi_dir = psi_dir_vec{j}; %'decreasing'; %default = decreasing
        
        for k=1:length(phi_dir_vec)

            phi_dir = phi_dir_vec{k}; %'increasing'; %default = increasing
            
            fprintf('runs=%d\n', runs)
            disp(strcat('phi=', phi_dir))
            disp(strcat('psi=', psi_dir))
            
            % Run Model_LHS
            close all
            rng(0);
            Model_LHS;
            
        end
    end
end
