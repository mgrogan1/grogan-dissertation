%PLOT solution
close all

hold on

% options for switch are 'Infected' and 'Treated'
switch 'Treated'
    
    case 'Treated' 
        s_colors=colormap(cool(1+1*n));
        %s_colors=s_colors(1:5:length(s_colors),:);
        r_colors=s_colors;%colormap(hot(1+n));
        %r_colors=r_colors(1:5:length(r_colors),:);
        interesting_t = t(1:4000);
        %i=[5:6 7:6+n 6+n+1:6+2*n] %plot only infected classes
        % for i=[5 7:6+n] %color only s_infected classes
        % p = plot(interesting_t,modelSol(1:length(interesting_t),i),'linewidth',2);
        % i
        % p.Color=s_colors(i,:);
        % end

        %p = plot(interesting_t,modelSol(1:length(interesting_t),5:6),'linewidth',2);
        p = plot(interesting_t,modelSol(1:length(interesting_t),7:6+n),'linewidth',2);
        for i=1:n
        p(i).Color=s_colors(1+i,:);
        end

        % for i=[6 6+n+1:6+2*n] %color only r_infected classes
        % p = plot(interesting_t,modelSol(1:length(interesting_t),i),'linewidth',2);
        % p.Color=r_colors(i,:);
        % end

        %p = plot(interesting_t,modelSol(1:length(interesting_t),5:6),'-.','linewidth',2);
        p = plot(interesting_t,modelSol(1:length(interesting_t),6+n+1:6+2*n),'--','linewidth',2);
        for i=1:n
        p(i).Color=r_colors(1+i,:);
        end

        %legend(y_var_labels(5:6))
        %legend(y_var_labels([5:6 7:6+n 6+n+1:6+2*n]))
        %legend(y_var_labels([5 7:6+n 6 6+n+1:6+2*n]))
        %legend(y_var_labels([7:6+n 6+n+1:6+2*n]))
        title(sprintf('Baseline Parameters, n=%d',n),'fontsize',20)
        xlabel('time','fontsize',20)
        ylabel('population (proportion)','fontsize', 20)
        
    case 'Infected'
        s_colors=colormap(cool(3));
        r_colors=s_colors;
        interesting_t = t(1:4000);

        p = plot(interesting_t,modelSol(1:length(interesting_t),5),'linewidth',2);
        %for i=1:1
        p.Color=s_colors(2,:);
        %end

        p = plot(interesting_t,modelSol(1:length(interesting_t),6),'--','linewidth',2);
        %for i=1:1
        p.Color=r_colors(2,:);
        %end

        legend(y_var_labels(5:6),'fontsize',20)
        title(sprintf('Baseline Parameters, n=%d',n),'fontsize',20)
        xlabel('time','fontsize',20)
        ylabel('population (proportion)','fontsize', 20)
        
end