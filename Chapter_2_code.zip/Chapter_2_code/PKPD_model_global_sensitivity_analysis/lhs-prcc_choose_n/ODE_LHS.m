function dydt=ODE_LHS(t,y,LHSmatrix,x,runs,n,popSize)
%% PARAMETERS %%
%Parameter_settings_LHS;

% Nh0=LHSmatrix(x,3)/LHSmatrix(x,1);
% Nv0=LHSmatrix(x,4)/LHSmatrix(x,2);
Nh0=popSize(2);
Nv0=popSize(1);

%n=LHSmatrix(x,1);

muH=LHSmatrix(x,1);
muV=LHSmatrix(x,2);
lambdaH=LHSmatrix(x,3)/Nh0;
lambdaV=LHSmatrix(x,4)/Nv0;
deltaS=LHSmatrix(x,5);
deltaR=LHSmatrix(x,6);
betaH=LHSmatrix(x,7)*(Nv0/Nh0);
betaV=LHSmatrix(x,8);
kappaH=LHSmatrix(x,9);
kappaV=LHSmatrix(x,10);
a=LHSmatrix(x,11);

for i = 1:n
    alpha(i) = LHSmatrix(x,11+i);
end

omegaS=LHSmatrix(x,11+n+1);
omegaR=LHSmatrix(x,11+n+2);
sigmaS=LHSmatrix(x,11+n+3);
sigmaR=LHSmatrix(x,11+n+4);

for i = 1:n
    psiS(i) = LHSmatrix(x,11+n+4+i);
end

for i = 1:n
    psiR(i) = LHSmatrix(x,11+2*n+4+i);
end

for i = 1:n
    phi(i) = LHSmatrix(x,11+3*n+4+i);
end

dummy_LHS=LHSmatrix(x,11+4*n+4);


% [Sv] 
A1 = lambdaV - betaV*y(1)*(y(5)+psiS*y(6+1:6+n)+kappaV*(y(6)...
    +psiR*y(6+n+1:6+2*n)))/sum(y(4:6+2*n+2))-muV*y(1); %Sv equation

% [Ms] 
A2 = betaV*y(1)*(y(5)+psiS*y(6+1:6+n))/sum(y(4:6+2*n+2))-muV*y(2); %M_s equation

% [Mr]
A3 = betaV*kappaV*y(1)*(y(6)+psiR*y(6+n+1:6+2*n))/sum(y(4:6+2*n+2))-muV*y(3); %M_r equation

% [Sh]
A4 = lambdaH-betaH*y(4)*(y(2) + kappaH*y(3))/(sum(y(4:6+2*n+2)))...
    +omegaS*y(6+2*n+1)+omegaR*y(6+2*n+2)+alpha(n)*(y(6+n)+y(6+2*n))-muH*y(4); %S_h' equation

% [Is]
A5 = betaH*(y(4)*y(2)-kappaH*y(5)*y(3))/(sum(y(4:6+2*n+2)))...
    -(a+sigmaS+deltaS+muH)*y(5); %I_s' equation

% [Ir]
A6 = betaH*kappaH*y(3)*(y(4)+y(5)+y(6+2*n+1))/(sum(y(4:6+2*n+2)))...
    -(a+sigmaR+deltaR+muH)*y(6); %I_r equation

% [Ts1] 
A7 = a*y(5)-(alpha(1)+deltaS+muH)*y(6+1)...
    -betaH*kappaH*phi(1)*y(3)*y(6+1)/(sum(y(4:6+2*n+2))); %Ts1 equation


% [Ts2...Tsn]
A8=zeros(n-1,1);
for k=2:n
A8(k-1,1) = alpha(k-1)*y(6+k-1)-(alpha(k)+deltaS+muH)*y(6+k)...
    -betaH*kappaH*phi(k)*y(3)*y(6+k)/(sum(y(4:6+2*n+2))); %Tsk equations
end

% [Tr1]
A9 = a*y(6)-(alpha(1)+deltaR+muH)*y(6+n+1)...
    +betaH*kappaH*phi(1)*y(3)*y(6+1)/(sum(y(4:6+2*n+2))); %Tr1 equation

% [Tr2...Trn]
A10=zeros(n-1,1);
for k=2:n
A10(k-1,1) = alpha(k-1)*y(6+n+k-1)-(alpha(k)+deltaR+muH)*y(6+n+k)...
    +betaH*kappaH*phi(k)*y(3)*y(6+k)/(sum(y(4:6+2*n+2))); %Trk equations
end

% [Rs]
A11 = sigmaS*y(5)-(omegaS...
    +betaH*kappaH*y(3)/(sum(y(4:6+2*n+2)))+muH)*y(6+2*n+1); %R_s equation

% [Rr]
A12 = sigmaR*y(6)-(omegaR+muH)*y(6+2*n+2); %R_r equation

dydt = [A1; A2; A3; A4; A5; A6; A7; A8; A9; A10; A11; A12];