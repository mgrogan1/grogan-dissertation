%% The results should be compared to the PRCC results section in
%% Supplementary Material D and Table D.1 for different N (specified by
%% "runs" in the script below
clear all
close all

%% Sample size N
rng(0);
runs=3000;
distribution='unif';

%% LHS MATRIX  %%
Parameter_settings_LHS;

% betaVtest = linspace(0.0313,0.0927,10);
% betaVtest_labels = strings(1,length(betaVtest));
% for k = 1:length(betaVtest)
%     betaVtest_labels(k) = sprintf('betaV_{%d}',k);
% end

for j=1:1%length(betaVtest)
    %j
    %betaV = betaVtest(j)

switch distribution
    case 'unif'
        %n_LHS=LHS_Call(n, n, n, 0 ,runs,'unif'); % baseline = 3
        muH_LHS=LHS_Call(4.25e-5, muH, 4.791e-5, 0 ,runs,'unif'); % baseline = 4.43e-5
        muV_LHS=LHS_Call(1/21, muV, 1/7, 0, runs,'unif'); % baseline = 1/14
        lambdaH_LHS=LHS_Call(2.24e3,lambdaH,5.08e3, 0 ,runs,'unif'); % baseline = 3.55e3
        lambdaV_LHS=LHS_Call(1*(lambdaH/muH)*muV, lambdaV, 10*(lambdaH/muH)*muV, 0, runs,'unif'); 
        % low baseline = 1*(lambdaH/muH)/muV
        % high baseline = 3*(lambdaH/muH)/muV
        deltaS_LHS=LHS_Call(0.3/(1000*365) , deltaS , 0.6/(1000*365) , 0 , runs , 'unif');  % baseline = 0.4/(1000*365)
        deltaR_LHS=LHS_Call(0.3/(1000*365) , deltaR , 0.6/(1000*365) , 0 , runs , 'unif');
        betaH_LHS=LHS_Call(0.18,betaH,0.9, 0 ,runs,'unif'); % 0.1251 = low baseline, high baseline=0.5561,
        betaV_LHS=LHS_Call(0.03,betaV,0.2, 0 ,runs,'unif'); %0.0313 = low baseline, high baseline=0.0927 
        kappaH_LHS=LHS_Call(0.001,kappaH,0.999, 0 ,runs,'unif'); % baseline = 0.6
        kappaV_LHS=LHS_Call(0.001,kappaV,0.999, 0 ,runs,'unif'); % baseline = 0.6
        a_LHS=LHS_Call(1/10,a,1/3, 0 ,runs,'unif'); % baseline = 1/5

        alpha_LHS(:,1)=LHS_Call(1/(100/n),alpha(1),1/(1/n), 0 ,runs,'unif');
        for i = 2:n
        alpha_LHS(:,i)=LHS_Call(1/(100/n),alpha(i),1/(1/n), 0 ,runs,'unif'); % baseline = 1/52 divided over n compartments
        end
%         for i = 2:n
%         alpha_LHS(:,i)=LHS_Call(1/100,alpha(i),1-sum(alpha_LHS(:,1:i-1)), 0 ,runs,'unif'); % baseline = 1/52 divided over n compartments
%         end
%         alphas should sum to n*alpha(i)

        omegaS_LHS=LHS_Call(1/400,omegaS,1/10, 0 ,runs,'unif'); % baseline = 1/370
        omegaR_LHS=LHS_Call(1/400,omegaR,1/10, 0 ,runs,'unif');
        sigmaS_LHS=LHS_Call(1/365,sigmaS,1/28, 0 ,runs,'unif'); % baseline = 1/33
        sigmaR_LHS=LHS_Call(1/365,sigmaR,1/28, 0 ,runs,'unif');

%       Make psiS a decreasing function of k
        psiS_LHS(:,1)=LHS_Call(psiS(1),psiS(1),1, 0 ,runs,'unif');
        for i = 2:n-1
        psiS_LHS(:,i)=LHS_Call(psiS(i),psiS(i),psiS(i-1), 0 ,runs,'unif');
        end
        psiS_LHS(:,n)=LHS_Call(0.0001,psiS(n),psiS(n-1), 0 ,runs,'unif');
        
%       Make psiR a decreasing function of k
        psiR_LHS(:,1)=LHS_Call(psiR(1),psiR(1),1, 0 ,runs,'unif');
        for i = 2:n-1
        psiR_LHS(:,i)=LHS_Call(psiR(i),psiR(i),psiR(i-1), 0 ,runs,'unif');
        end
        psiR_LHS(:,n)=LHS_Call(0.0001,psiR(n),psiR(n-1), 0 ,runs,'unif');
        
%       Make phi an increasing function of k        
        phi_LHS(:,1)=LHS_Call(0.001,phi(1),phi(2),0,runs,'unif');
        for i=2:n-1
        phi_LHS(:,i)=LHS_Call(phi(i-1),phi(i),phi(i+1),0,runs,'unif');
        end
        phi_LHS(:,n)=LHS_Call(phi(n-1),phi(n),1,0,runs,'unif');
%         for i=1:n
%          phi_LHS(:,i)=LHS_Call(0,0,0,0,runs,'unif');
%         end

        dummy_LHS=LHS_Call(1,1,1e1, 0 ,runs,'unif'); % dummy parameter

    case 'norm'
        %change standard deviation to be some percentage of the mean
        n_LHS=LHS_Call(3, n, 3, 0 ,runs,'norm'); % baseline = 3
        muH_LHS=LHS_Call(4.25e-5, muH, 4.791e-5, 0 ,runs,'norm'); % baseline = 4.43e-5
        muV_LHS=LHS_Call(1/21, muV, 1/7, 0, runs,'norm'); % baseline = 1/14
        lambdaH_LHS=LHS_Call(2.24e3,lambdaH,5.08e3, 0 ,runs,'norm'); % baseline = 3.55e3
        lambdaV_LHS=LHS_Call(1*(lambdaH/muH)*muV, lambdaV, 10*(lambdaH/muH)*muV, 0, runs,'norm'); 
        % low baseline = 1*(lambdaH/muH)/muV
        % high baseline = 3*(lambdaH/muH)/muV
        deltaS_LHS=LHS_Call(0.3/(1000*365) , deltaS , 0.6/(1000*365) , 0 , runs , 'norm');  % baseline = 0.4/(1000*365)
        deltaR_LHS=LHS_Call(0.3/(1000*365) , deltaR , 0.6/(1000*365) , 0 , runs , 'norm');
        betaH_LHS=LHS_Call(0.18,betaH,0.9, 0 ,runs,'norm'); % 0.1251 = low baseline, high baseline=0.5561,
        betaV_LHS=LHS_Call(0.03,betaV,0.2, 0 ,runs,'norm'); %0.0313 = low baseline, high baseline=0.0927 
        kappaH_LHS=LHS_Call(0,kappaH,1, 0 ,runs,'norm'); % baseline = 0.6
        kappaV_LHS=LHS_Call(0,kappaV,1, 0 ,runs,'norm'); % baseline = 0.6
        a_LHS=LHS_Call(1/10,a,1/3, 0 ,runs,'norm'); % baseline = 1/5

        for i = 1:n
        alpha_LHS(:,i)=LHS_Call(1/(100/n),alpha(i),1/(1/n), 0 ,runs,'norm'); % baseline = 1/52 divided over n compartments
        end

        omegaS_LHS=LHS_Call(1/400,omegaS,1/10, 0 ,runs,'norm'); % baseline = 1/370
        omegaR_LHS=LHS_Call(1/400,omegaR,1/10, 0 ,runs,'norm');
        sigmaS_LHS=LHS_Call(1/365,sigmaS,1/28, 0 ,runs,'norm'); % baseline = 1/33
        sigmaR_LHS=LHS_Call(1/365,sigmaR,1/28, 0 ,runs,'norm');

        psiS_LHS(:,1)=LHS_Call(psiS(1),psiS(1),1, 0 ,runs,'norm');
        for i = 2:n-1
        psiS_LHS(:,i)=LHS_Call(psiS(i),psiS(i),psiS(i-1), 0 ,runs,'norm');
        end
        psiS_LHS(:,n)=LHS_Call(0.0001,psiS(n),psiS(n-1), 0 ,runs,'norm');
        
        psiR_LHS(:,1)=LHS_Call(psiR(1),psiR(1),1, 0 ,runs,'norm');
        for i = 2:n-1
        psiR_LHS(:,i)=LHS_Call(psiR(i),psiR(i),psiR(i-1), 0 ,runs,'norm');
        end
        psiR_LHS(:,n)=LHS_Call(0.0001,psiR(n),psiR(n-1), 0 ,runs,'norm');
        
        phi_LHS(:,1)=LHS_Call(0.0001,phi(1),phi(1),0,runs,'norm');
        for i=2:n-1
        phi_LHS(:,i)=LHS_Call(phi(i-1),phi(i),phi(i),0,runs,'norm');
        end
        phi_LHS(:,n)=LHS_Call(phi(n-1),phi(n),1,0,runs,'norm');

        dummy_LHS=LHS_Call(1,1,1e1, 0 ,runs,'norm'); % dummy parameter

end

%% LHS MATRIX and PARAMETER LABELS
LHSmatrix=[muH_LHS muV_LHS lambdaH_LHS lambdaV_LHS ...
            deltaS_LHS deltaR_LHS betaH_LHS betaV_LHS ...
            kappaH_LHS kappaV_LHS a_LHS alpha_LHS omegaS_LHS ...
            omegaR_LHS sigmaS_LHS sigmaR_LHS psiS_LHS psiR_LHS ...
            phi_LHS dummy_LHS];
        
% INITIAL CONDITION FOR THE ODE MODEL
Nv0 = lambdaV_LHS./muV_LHS;
Ms0 = 0.005*Nv0; % 0.5% of population
Mr0 = 0.005*Nv0; 
Sv0 = Nv0-(Ms0+Mr0); %

Nh0 = lambdaH_LHS./muH_LHS;
Is0 = 0.05*Nh0;% 5% of population
Ir0 = 0.05*Nh0;
Sh0 = Nh0 - (Is0+Ir0); %
Ts0 = zeros(n,1);
Tr0 = zeros(n,1);
Rs0 = 0;
Rr0 = 0;

y0 = [Sv0'./Nv0'; Ms0'./Nv0'; Mr0'./Nv0'; Sh0'./Nh0'; Is0'./Nh0'; ...
    Ir0'./Nh0'; Ts0*(1./Nh0)'; Tr0*(1./Nh0)'; Rs0'./Nh0'; Rr0'./Nh0'];

%store output to plot
modelSol=zeros(length(tspan), 6+2*n+2,runs);

for x=1:runs %Run solution x times choosing different values
    f=@ODE_LHS;
    x
    %LHSmatrix(x,:);
    options=odeset('NonNegative',1);
    [t,y]=ode15s(@(t,y)f(t,y,LHSmatrix,x,runs,n),tspan,y0(:,x),options);
    %figure(x);
    %plot(t,y);
    A=[t y]; % [time y]
    if length(y(:,1)) == length(tspan)
       modelSol(:,:,x) = y;
    end
    %% Save the outputs at ALL time points [tspan]
%     Anew=A;
%     Sv_lhs(:,x)=Anew(:,1);
%     Ms_lhs(:,x)=Anew(:,2);
%     Mr_lhs(:,x)=Anew(:,3);
%     Sh_lhs(:,x)=Anew(:,4);
%     Is_lhs(:,x)=Anew(:,5);
%     Ir_lhs(:,x)=Anew(:,6);
%     for i=1:n
%       Ts_lhs(:,x)=Anew(:,6+i);
%       Tr_lhs(:,x)=Anew(:,6+n+i);
%     end
%     Rs_lhs(:,x)=Anew(:,6+2*n+1);
%     Rr_lhs(:,x)=Anew(:,6+2*n+2);
    
    %% Save only the outputs at the time points of interest [time_points]:
    %% MORE EFFICIENT
    %Sv'Ms'Mr'Sh'Is'Ir'Tsk'Trk'Rs'Rr'
    
    Sv_lhs(:,x)=A(time_points+1,1);
    Ms_lhs(:,x)=A(time_points+1,2);
    Mr_lhs(:,x)=A(time_points+1,3);
    Sh_lhs(:,x)=A(time_points+1,4);
    Is_lhs(:,x)=A(time_points+1,5);
    Ir_lhs(:,x)=A(time_points+1,6);
    
    for i = 1:n
         Ts_lhs(:,x,i)=A(time_points+1,6+i); %%
         Tr_lhs(:,x,i)=A(time_points+1,6+n+i); %%fix 
    end
    
%     Ts1_lhs(:,x)=A(time_points+1,7); %%fix
%     Ts2_lhs(:,x)=A(time_points+1,8); %%fix
%     Ts3_lhs(:,x)=A(time_points+1,9); %%fix
%      
%     Tr1_lhs(:,x)=A(time_points+1,10); %%fix 
%     Tr2_lhs(:,x)=A(time_points+1,11); %%fix 
%     Tr3_lhs(:,x)=A(time_points+1,12); %%fix 
    
    Rs_lhs(:,x)=A(time_points+1,6+2*n+1);
    Rr_lhs(:,x)=A(time_points+1,6+2*n+2);
end
%% Save the workspace
save Model_LHS.mat;

%Check parameter distributions
% histogram(betaH_LHS)
% histogram(betaV_LHS)
% histogram(muV_LHS)
% histogram(lambdaV_LHS)
% histogram(lambdaH_LHS)

% CALCULATE PRCC
[prcc sign sign_label]=PRCC(LHSmatrix,Is_lhs,1:length(time_points),PRCC_var,1); 
%set alpha (last argument) = 1

%plot PRCC: 
set(groot, 'defaulttextinterpreter','latex')
PRCC_PLOT(LHSmatrix,Is_lhs,1,PRCC_var,y_var_labels(5))
figure(length(PRCC_var)+1)
bar(prcc(1,:)) % do for reproduction numbers or invasion numbers
xticks(1:1:length(PRCC_var))
xticklabels(PRCC_var)
ylabel('I_s')

% %PLOT solution
% %
%hold on
% %colors=colormap('jet');
% %colors=colors(:,:);%1:3:(6+2*n+2)*3,:);
%for i=[5]%:6 7:6+n 6+n+1:6+2*n] %plot only infected classes
%p = plot(t,modelSol(:,i,1),'linewidth',2);
% %p.Color=colors(i,:);
end
% 
%legend(['\' sprintf('betaV_{%d}',j)])%:6 7:6+n 6+n+1:6+2*n]))
% title('Baseline Parameters, n=3')
% xlabel('time')
% ylabel(

%end

% for j=1:length(betaVtest)
% legend(betaVtest_labels)%:6 7:6+n 6+n+1:6+2*n]))
% end
% title('Baseline Parameters, n=3')
% xlabel('time')
% ylabel('I_s')

