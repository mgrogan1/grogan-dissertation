% PARAMETER BASELINE VALUES

muH = 4.43*10^(-5); % = baseline, range = (4.25,4.791)*10^(-5)
muV = 1/14; % = baseline, range = (1/21, 1/7)
lambdaH = 3.55*10^3; % = baseline value, value range = (2.24*10^3, 5.08*10^3)
lambdaV = 3*(lambdaH/muH)*muV; %low baseline = 1*Nh*muV, high baseline =3*Nh*muV, range = (1-10)*Nh/muV
%assume for now that we are at equilibrium and set Nh = lambdaH/muH
deltaS = 0.4/(1000*365); %=baseline, range = (0.3/(1000*365), 0.6/(1000*365))
deltaR = 0.4/(1000*365); %set equal for sensitive and resistant strains for now
betaH = 0.5561; %0.1251 = low baseline, high baseline=0.5561, range =(0.18, 0.9)
betaV = 0.0927; %0.0313 = low baseline, high baseline=0.0927, range =(0.03, 0.2)
kappaH = 0.6; % = low baseline, high baseline=0.6, range=(0,1)
kappaV = 0.6; % = low baseline, high baseline=0.6, range=(0,1)
a = 1/5; %individuals becoming treated per unit time
%1/a in IPT paper?, baseline = 5days, range = (3,10).

%alphaMin = 1/52;
%alphaMax = 1;
%alpha = linspace(alphaMin,alphaMax,n);
alpha = 1/(52/n)*ones(1,n); %set equal values for now
%alpha = alpha; %dependent on drug halflives, shoulds sum to total treated time
%1/rs in IPT paper?, baseline = 52, no range

omegaS = 1/370; %baseline, no range
omegaR = 1/370; %set equal for sensitive and resistant strains for now
sigmaS = 1/33; %=baseline, range = (1/365,1/28)
sigmaR = 1/33; %set equal for sensitive and resistant strains for now

m=n+1; %generate n equally spaced intervals in linspace

psiSMin = 0.000001;
psiSMax = 1;

psiRMin = 0.000001;
psiRMax = 1;

switch psi_dir
    case 'decreasing' %default
        psiS = sort(linspace(psiSMin,psiSMax,m),'descend');
        psiS0_endpts = sort(linspace(psiSMin,psiSMax,m+1),'descend');
        psiS0 = psiS0_endpts(2:m);
        %psiS_ave = sum(psiS)/n; %between 0 and 1, decreasing with k
        psiR = sort(linspace(psiRMin,psiRMax,m+1),'descend');
        psiR0_endpts = sort(linspace(psiRMin,psiRMax,m+1),'descend');
        psiR0 = psiR0_endpts(2:m);
        %psiR_ave= sum(psiR)/n; %between 0 and 1, decreasing with k
        
    case 'increasing'
        psiS = sort(linspace(psiSMin,psiSMax,m),'ascend');
        %psiS_ave = sum(psiS)/n; %between 0 and 1, decreasing with k
        psiR = sort(linspace(psiRMin,psiRMax,m),'ascend');
        %psiR_ave= sum(psiR)/n; %between 0 and 1, decreasing with k
end

phiMin = 0.000001;
phiMax = 1;

switch phi_dir
    case 'increasing' %default
        %phi=zeros(n); %between 0 and 1, increasing with k
        phi = sort(linspace(phiMin,phiMax,m),'ascend');
        phi0_endpts = sort(linspace(phiMin,phiMax,m+1),'ascend');
        phi0 = phi0_endpts(2:m);
        %phi_ave = sum(phi)/n;
        
    case 'decreasing'
        %phi=zeros(n); %between 0 and 1, increasing with k
        phi = sort(linspace(phiMin,phiMax,m),'descend');
        %phi_ave = sum(phi)/n;
end

dummy=1;

% Parameter Labels
PRCC_var=strings(1,11+4*n+5);


PRCC_var(1:11)={'\mu_h', '\mu_v', '\Lambda_h', '\Lambda_v', '\delta_s', ...
    '\delta_r', '\beta_{h}', '\beta_{v}', '\kappa_h', '\kappa_v', 'a'};

for i = 1:n
    PRCC_var(11+i)={['\' sprintf('alpha_{%d}',i)]};
end

PRCC_var(11+n+1:11+n+4)={'\omega_s', '\omega_r', '\sigma_s', '\sigma_r'};

for i = 1:n
    PRCC_var(11+n+4+i)={['\' sprintf('Psi_{s,%d}',i)]};
end

for i=1:n
    PRCC_var(11+2*n+4+i)={['\' sprintf('Psi_{r,%d}',i)]};
end

for i = 1:n
    PRCC_var(11+3*n+4+i)={['\' sprintf('varphi_{%d}',i)]};
end

PRCC_var(11+4*n+4+1)={'dummy'};

%% TIME SPAN OF THE SIMULATION
t_end=1000; % length of the simulations
tspan=(0:0.1:t_end);   % time points where the output is calculated
time_points=length(tspan); % time points of interest for the US analysis
%time_points=[10, 100, 1000]; % time points of interest for the US analysis

% INITIAL CONDITION FOR THE ODE MODEL
Nv0 = lambdaV/muV;
Ms0 = 0.005*Nv0; % 0.5% of population
Mr0 = 0.005*Nv0;
Sv0 = lambdaV/muV-(Ms0+Mr0); %

Nh0 = lambdaH/muH;
Is0 = 0.05*Nh0;% 5% of population
Ir0 = 0.05*Nh0;
Sh0 = lambdaH/muH - (Is0+Ir0); %
Ts0 = zeros(n,1);
Tr0 = zeros(n,1);
Rs0 = 0;
Rr0 = 0;

y0 = [Sv0/Nv0; Ms0/Nv0; Mr0/Nv0; Sh0/Nh0; Is0/Nh0; Ir0/Nh0; Ts0/Nh0; Tr0/Nh0; Rs0/Nh0; Rr0/Nh0];

% Variables Labels, Put $ around for latex reader?
y_var_labels = strings(6+2*n+2,1);
y_var_labels(1,1) = 'S_v';
y_var_labels(2,1) = 'M_s';
y_var_labels(3,1) = 'M_r';
y_var_labels(4,1) = 'S_h';
y_var_labels(5,1) = 'I_s';
y_var_labels(6,1) = 'I_r';

for k = 1:n
    y_var_labels(6+k,1) = sprintf('T_{s,%d}',k);
end
for k = 1:n
    y_var_labels(6+n+k,1) = sprintf('T_{r,%d}',k);
end

y_var_labels(6+2*n+1,1) = 'R_s';
y_var_labels(6+2*n+2,1) = 'R_r';
