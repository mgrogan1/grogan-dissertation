 
tic %start timer

%Sv'Ms'Mr'Sh'Is'Ir'Tsk'Trk'Rs'Rr'

format long
%close all
%clear all
%clc

load('Model_LHS_3000runs_3n_NOn_LHS.mat');

%Parameters, cite original sources, for now from IPT paper from Olivia
R0s2=zeros(1,runs);
R0r2=zeros(1,runs);

for i=1:runs
i

%par.n = LHSmatrix(i,1); %baseline 3 for now
par.muH = LHSmatrix(i,1); % = baseline, range = (4.25,4.791)*10^(-5) 
par.muV = LHSmatrix(i,2); % = baseline, range = (1/21, 1/7) 
par.lambdaH = LHSmatrix(i,3); % = baseline value, value range = (2.24*10^3, 5.08*10^3)
par.lambdaV = LHSmatrix(i,4); %high baseline = 3*Nh/muV, low baseline =1*Nh/muV, range = (1-10)*Nh/muV
%assume for now that we are at equilibrium and set Nh = lambdaH/muH
par.deltaS = LHSmatrix(i,5); %=baseline, range = (0.3/(1000*365), 0.6/(1000*365))
par.deltaR = LHSmatrix(i,6); %set equal for sensitive and resistant strains for now
par.betaH = LHSmatrix(i,7); % = low baseline, high baseline=0.5561, range =(0.18, 0.9)
par.betaV = LHSmatrix(i,8); % = low baseline, high baseline=0.0927, range =(0.03, 0.2)
par.kappaH = LHSmatrix(i,9); % = low baseline, high baseline=0.6, range=(0,1)
par.kappaV = LHSmatrix(i,10); % = low baseline, high baseline=0.6, range=(0,1)
par.a = LHSmatrix(i,11); %individuals becoming treated per unit time 
%1/a in IPT paper?, baseline = 5days, range = (3,10).

%alphaMin = 1/52;
%alphaMax = 1;
%alpha = linspace(alphaMin,alphaMax,par.n);
for k=1:n
    alpha(k) = LHSmatrix(i,11+k); 
end

par.alpha = alpha; %dependent on drug halflives, shoulds sum to total treated time
%rs in IPT paper?, baseline = 1/52, no range

par.omegaS = LHSmatrix(i,11+n+1); %baseline, no range
par.omegaR = LHSmatrix(i,11+n+2); %set equal for sensitive and resistant strains for now
par.sigmaS = LHSmatrix(i,11+n+3); %=baseline, range = (1/365,1/28)
par.sigmaR = LHSmatrix(i,11+n+4); %set equal for sensitive and resistant strains for now

for k=1:n
    psiS(k) = LHSmatrix(i,11+n+4+k);
end
par.psiS = psiS; %between 0 and 1, decreasing with k

for k=1:n
    psiR(k) = LHSmatrix(i,11+2*n+4+k);
end
par.psiR = psiR;

for k=1:n
    phi(k) = LHSmatrix(i,11+3*n+4+k);
end
par.phi = phi;

%Compute R0_s^2 (sensitive strain R0, plug in DFE)
hs = (par.betaH*par.lambdaH/par.muH)/(par.lambdaH/par.muH + par.lambdaV/par.muV);
vs = (par.betaV*par.lambdaV/par.muV)/(par.lambdaH/par.muH + par.lambdaV/par.muV);
cs = par.a + par.deltaS + par.muH + par.sigmaS;

c = zeros(1,n);
alphaprod = zeros(1,n);
cprod = zeros(1,n);

for k=1:n
    c(k) = par.alpha(k) + par.deltaS + par.muH;
    alphaprod(k) = prod(par.alpha(1:k-1));
    cprod(k) = 1/prod(c(1:k));
end

R0s2(i) = (hs*vs/(par.muV*cs))*(1 + par.a*((alphaprod.*cprod)*par.psiS'));

%Compute R0r^2 (resistant strain R0,plug in DFE)
hr = par.kappaH*hs;
vr = par.kappaV*vs;
dr = par.a + par.deltaR + par.muH + par.sigmaR;

d = zeros(1,n);
alphaprodR = zeros(1,n);
dprod = zeros(1,n);

for k=1:n
    d(k) = par.alpha(k) + par.deltaR + par.muH;
    alphaprodR(k) = prod(par.alpha(1:k-1));
    dprod(k) = 1/prod(d(1:k));
end

R0r2(i) = (hr*vr/(par.muV*dr))*(1 + par.a*((alphaprodR.*dprod)*par.psiR'));



%solve ODE SIR model
%tspan = t0:h:tF;
%[t,z] = ode15s(@ODE_LHS,tspan,y0(:,i),[],par);

%plot things
%hold all
%hold on

%plot(t,z(:,5),'r'); %sensitive human infections
%plot(t,z(:,6),'b'); %resistant human infections

%plot(par.deltaS,R0s2(i),'. b');
%plot(par.deltaR,R0r2(i), '- r');

end

%plot(deltaS_LHS,R0s2,'. b');

%xlabel('\mu_h');
%ylabel('R0_s^2');

%legend('I_s','I_r');


 toc %stop timer


%maybe run out to so many days to try to estimate boundary equilibria